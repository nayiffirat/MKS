import { createMultiPagePdf } from '../utils/pdfHelper';

// ... imports ...
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { dbService } from '../services/db';
import { Farmer, Pesticide, Prescription, PesticideCategory, VisitLog, AppNotification } from '../types';
import { useAppViewModel } from '../context/AppContext';
import { safeStringify } from '../utils/json';
import { Check, Plus, Trash2, FileOutput, Share2, FileText, Calendar, MapPin, X, User, Loader2, Search, FlaskConical, MessageCircle, Edit2, AlertCircle, ArrowLeft, Printer, Package, Download, MessageSquare, RefreshCw, AlertTriangle, Camera, Barcode, TrendingUp, Star, Lightbulb, ChevronRight, CreditCard, Wallet, Landmark, Sprout, Wheat, Sparkles } from 'lucide-react';
import BarcodeScanner from './BarcodeScanner';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';
import { formatCurrency, getCurrencySymbol } from '../utils/currency';
import { ConfirmationModal } from './ConfirmationModal';
import { ListSkeleton } from './Skeleton';
import { EmptyState } from './EmptyState';
import { RealisticStamp } from './RealisticStamp';
import { turkishMatchesAny } from '../utils/search';

const POPULAR_CROPS = [
  'Pamuk', 'Buğday', 'Mısır', 'Ayçiçeği', 'Domates', 'Biber', 'Patlıcan', 
  'Hıyar (Salatalık)', 'Karpuz', 'Kavun', 'Üzüm (Bağ)', 'Zeytin', 'Fındık', 
  'Arpa', 'Çeltik (Pirinç)', 'Patates', 'Soğan', 'Sarımsak', 'Şeker Pancarı', 
  'Yonca', 'Ceviz', 'Badem', 'Narenciye', 'Elma', 'Kiraz', 'Çilek', 
  'Kayısı', 'Şeftali', 'Antep Fıstığı', 'Nohut', 'Mercimek', 'Fasulye', 'Soya', 'Kanola'
];

interface PrescriptionFormProps {
    onBack: () => void;
    initialFarmerId?: string;
    initialPrescriptionId?: string;
}

export const PrescriptionForm: React.FC<PrescriptionFormProps> = ({ onBack, initialFarmerId, initialPrescriptionId }) => {
    const { 
        userProfile, 
        refreshStats, 
        updateUserProfile,
        prescriptions: contextPrescriptions,
        togglePrescriptionStatus,
        softDeletePrescription,
        farmers: contextFarmers,
        inventory: contextInventory,
        plants: contextPlants,
        showToast,
        hapticFeedback,
        activeTeamMember,
        teamMembers,
        t,
        accounts,
        addTransaction,
        deleteTransaction,
        transactions,
        payments,
        addPayment,
        updatePayment,
        deletePayment
    } = useAppViewModel();
    const isSales = activeTeamMember?.role === 'SALES';
    const farmerLabel = 'Çiftçi';
    const farmerPluralLabel = 'Çiftçiler';
    const prescriptionLabel = 'Fatura';

    const canEditPrescription = !isSales;
    const canCreatePrescription = canEditPrescription;
    const [viewMode, setViewMode] = useState<'LIST' | 'FORM' | 'DETAIL'>(initialFarmerId ? 'FORM' : 'LIST');
    
    // Sub-navigation sync
    useEffect(() => {
        const handlePop = (e: PopStateEvent) => {
            const state = e.state;
            if (state?.view === 'PRESCRIPTIONS') {
                if (state.subView) {
                    setViewMode(state.subView);
                    if (state.step) {
                        setStep(state.step);
                    } else {
                        setStep(initialFarmerId ? 2 : 1);
                    }
                    if (state.subView === 'DETAIL' && state.detailId) {
                        const target = contextPrescriptions.find(p => p.id === state.detailId);
                        if (target) setDetailPrescription(target);
                    }
                } else {
                    setViewMode('LIST');
                    setDetailPrescription(null);
                    setEditingId(null);
                    setStep(1);
                }
            }
        };
        window.addEventListener('popstate', handlePop);
        return () => window.removeEventListener('popstate', handlePop);
    }, [contextPrescriptions, initialFarmerId]);

    const handleEditPayment = (payment: any) => {
        setEditingPayment(payment);
        setPaymentAmount(payment.amount.toString());
        setPaymentNote(payment.note || '');
        setSelectedAccountId(payment.accountId || '');
        setPaymentMethod(payment.method);
        setSelectedPaymentFarmerId(payment.farmerId);
        setPaymentDate(payment.dueDate || payment.date.split('T')[0]);
        setIsPaymentModalOpen(true);
    };

    const handleDeletePayment = async (id: string) => {
        setConfirmModal({
            isOpen: true,
            title: 'Ödeme Kaydı Silinecek',
            message: 'Bu ödeme kaydını silmek istediğinize emin misiniz?',
            onConfirm: async () => {
                await deletePayment(id);
                showToast('Ödeme kaydı silindi', 'success');
            }
        });
    };

    const handleSendReceiptButton = async (payment: any) => {
        hapticFeedback('medium');
        const farmer = farmerMap[payment.farmerId];
        const farmerName = farmer?.fullName || 'Sayın Müşterimiz';
        const dateStr = new Date(payment.date).toLocaleDateString('tr-TR');
        const amountStr = formatCurrency(payment.amount, userProfile?.currency || 'TRY');
        const paymentTypeStr = payment.method === 'CHECK' ? 'Çek' : 
                            payment.method === 'TEDYE' ? 'Tediye' : 'Nakit/Diğer';
                            
        setIsProcessingPdf(true);
        try {
            const container = document.createElement('div');
            container.style.position = 'absolute';
            container.style.left = '-9999px';
            container.style.top = '0';
            container.innerHTML = `
                <div id="receipt-print-${payment.id}" style="width: 400px; padding: 40px; background: white; color: #1c1917; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
                    <div style="text-align: center; margin-bottom: 30px;">
                        <h2 style="margin: 0; font-size: 26px; font-weight: 900; color: #064e3b; text-transform: uppercase;">${userProfile?.companyName || 'ZİRAİ OTOMASYON'}</h2>
                        <p style="margin: 5px 0 0; font-size: 14px; font-weight: 600; color: #57534e; letter-spacing: 2px;">TAHSİLAT MAKBUZU</p>
                    </div>
                    <div style="border-top: 2px dashed #d6d3d1; margin: 20px 0;"></div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 15px;">
                        <span style="color: #78716c; font-weight: 600;">Tarih:</span>
                        <strong style="color: #292524;">${dateStr}</strong>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 15px;">
                        <span style="color: #78716c; font-weight: 600;">Müşteri:</span>
                        <strong style="color: #292524;">${farmerName}</strong>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 15px;">
                        <span style="color: #78716c; font-weight: 600;">Ödeme:</span>
                        <strong style="color: #292524;">${paymentTypeStr}</strong>
                    </div>
                    ${payment.dueDate ? `
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 15px;">
                        <span style="color: #78716c; font-weight: 600;">Vade:</span>
                        <strong style="color: #292524;">${new Date(payment.dueDate).toLocaleDateString('tr-TR')}</strong>
                    </div>` : ''}
                    ${payment.note ? `
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 15px;">
                        <span style="color: #78716c; font-weight: 600;">Not:</span>
                        <strong style="color: #292524;">${payment.note}</strong>
                    </div>` : ''}
                    <div style="border-top: 2px dashed #d6d3d1; margin: 20px 0;"></div>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                        <span style="font-weight: 900; font-size: 18px; color: #292524;">TUTAR:</span>
                        <strong style="font-size: 28px; color: #059669;">${amountStr}</strong>
                    </div>
                    <div style="text-align: center; margin-top: 40px; font-size: 12px; font-weight: 600; color: #a8a29e;">
                        Bizi tercih ettiğiniz için teşekkür ederiz.
                    </div>
                </div>
            `;
            document.body.appendChild(container);
            
            const elementToCapture = container.firstElementChild as HTMLElement;
            const canvas = await html2canvas(elementToCapture, {
                scale: 2, 
                backgroundColor: '#ffffff',
                useCORS: true,
                logging: false
            });
            
            document.body.removeChild(container);
            
            const pdf = createMultiPagePdf(canvas);
            const pdfBlob = pdf.output('blob');
            
            const charMap: {[key: string]: string} = {'Ğ':'G','ğ':'g','Ü':'U','ü':'u','Ş':'S','ş':'s','İ':'I','ı':'i','Ö':'O','ö':'o','Ç':'C','ç':'c'};
            const safeName = farmerName
                .replace(/[ĞğÜüŞşİıÖöÇç]/g, match => charMap[match])
                .replace(/[^a-zA-Z0-9]/g, '_')
                .replace(/_+/g, '_')
                .replace(/^_|_$/g, '');
            const fileName = `${safeName}_Tahsilat_Makbuzu.pdf`;
            
            const fallbackToWhatsApp = (phone?: string, text?: string) => {
                const encodedMessage = encodeURIComponent(text || '');
                let phoneParam = '';
                if (phone) {
                    let cleanPhone = phone.replace(/[^0-9]/g, '');
                    if (cleanPhone.length === 10) {
                        cleanPhone = '90' + cleanPhone;
                    }
                    phoneParam = cleanPhone.replace('+', '');
                }
                const whatsappUrl = phoneParam 
                    ? `https://wa.me/${phoneParam}?text=${encodedMessage}` 
                    : `https://wa.me/?text=${encodedMessage}`;
                window.open(whatsappUrl, '_blank');
            };

            const file = new File([pdfBlob], fileName, { type: 'application/pdf' });
            let message = `Merhaba ${farmerName},\nTahsilat makbuzunuz ektedir.\n\nTutar: ${amountStr}\nBizi tercih ettiğiniz için teşekkür ederiz.\n${userProfile?.companyName || 'Zirai Otomasyon'}`;
            const shareData = {
                files: [file],
                title: 'Tahsilat Makbuzu',
                text: message
            };
            
            if (navigator.canShare && navigator.canShare(shareData)) {
                try {
                    await navigator.share(shareData);
                } catch (shareError) {
                    console.log('Share canceled or failed', shareError);
                    fallbackToWhatsApp(farmer?.phoneNumber, message);
                }
            } else {
                pdf.save(fileName);
                fallbackToWhatsApp(farmer?.phoneNumber, message);
            }
        } catch (e) {
            console.error('PDF Error:', e);
            showToast('Makbuz oluşturulamadı', 'error');
        } finally {
            setIsProcessingPdf(false);
        }
    };

    const changeViewMode = (mode: 'LIST' | 'FORM' | 'DETAIL', detailId?: string, replace = false) => {
        if (mode === viewMode) return;
        
        if (mode === 'LIST') {
            if (window.history.state?.subView) {
                window.history.back();
            } else {
                setViewMode('LIST');
                setDetailPrescription(null);
                setEditingId(null);
            }
        } else {
            const initialStep = (mode === 'FORM' && initialFarmerId) ? 2 : 1;
            const state = { ...window.history.state, subView: mode, detailId, step: initialStep };
            if (replace) {
                window.history.replaceState(state, '');
            } else {
                window.history.pushState(state, '');
            }
            setViewMode(mode);
            setStep(initialStep);
        }
    };

    const handleScan = (barcode: string) => {
        // Play success tone
        try {
            const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.1);
            gain.gain.setValueAtTime(0.5, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
            osc.start(ctx.currentTime);
            osc.stop(ctx.currentTime + 0.1);
            if (window.navigator?.vibrate) window.navigator.vibrate(50);
        } catch (e) {}

        // Search in inventory first
        const invItem = contextInventory.find(item => item.barcode === barcode);
        if (invItem) {
            const p = pesticides.find(pest => pest.id === invItem.pesticideId);
            if (p) {
                addItem(p);
                showToast(`${p.name} listeye eklendi`, 'success');
                return;
            }
        }
        
        // Search in pesticides if not found in inventory or if inventory item pesticide not found
        const pesticide = pesticides.find(p => p.barcode === barcode);
        if (pesticide) {
            addItem(pesticide);
            showToast(`${pesticide.name} listeye eklendi`, 'success');
        } else {
            // Play error tone
            try {
                const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(200, ctx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.2);
                gain.gain.setValueAtTime(0.5, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
                osc.start(ctx.currentTime);
                osc.stop(ctx.currentTime + 0.2);
                if (window.navigator?.vibrate) window.navigator.vibrate([100, 50, 100]);
            } catch (e) {}

            showToast("Barkod bulunamadı: " + barcode, 'error');
        }
    };

    const [isSavingPrescription, setIsSavingPrescription] = useState(false);
    const isSavingPrescriptionRef = useRef(false);

    const changeStep = (newStep: number) => {
        if (newStep === step) return;
        if (newStep > 1 && !selectedFarmer) {
            showToast("Lütfen önce bir müşteri seçiniz.", 'error');
            hapticFeedback('error');
            setStep(1);
            return;
        }
        if (newStep > 2 && (!selectedCrop || !selectedCrop.trim())) {
            showToast("Lütfen satışı yapılan mahsulü (ürünü) seçiniz.", 'error');
            hapticFeedback('error');
            setStep(2);
            return;
        }
        if (newStep > 3 && selectedItems.length === 0) {
            showToast("Lütfen en az bir ürün ekleyiniz.", 'error');
            hapticFeedback('error');
            setStep(3);
            return;
        }
        window.history.pushState({ ...window.history.state, step: newStep }, '');
        setStep(newStep);
    };
    
    const [farmerMap, setFarmerMap] = useState<Record<string, Farmer>>({});

    const [step, setStep] = useState(1);
    const [isScanning, setIsScanning] = useState(false);
    const [farmers, setFarmers] = useState<Farmer[]>([]);
    const [pesticides, setPesticides] = useState<Pesticide[]>([]);
    
    const [selectedFarmer, setSelectedFarmer] = useState<Farmer | null>(null);
    const [selectedFieldId, setSelectedFieldId] = useState('');
    const [selectedFieldIds, setSelectedFieldIds] = useState<string[]>([]);
    const [selectedPlantId, setSelectedPlantId] = useState('');
    const [selectedCrop, setSelectedCrop] = useState('');
    const [cropSearchTerm, setCropSearchTerm] = useState('');
    const [customCropInput, setCustomCropInput] = useState('');
    const [farmerSearchTerm, setFarmerSearchTerm] = useState('');
    const [pesticideSearchTerm, setPesticideSearchTerm] = useState('');
    const [prescriptionSearchTerm, setPrescriptionSearchTerm] = useState('');
    
    // Updated state to include quantity and price
    const [selectedItems, setSelectedItems] = useState<{pesticide: Pesticide, dosage: string, quantity: string, unitPrice?: string, totalPrice?: number, buyingPrice?: number}[]>([]);
    const [showPrices, setShowPrices] = useState(true);
    const [customPrescriptionNo, setCustomPrescriptionNo] = useState('');
    const [prescriptionPriceType, setPrescriptionPriceType] = useState<'CASH' | 'TERM'>('TERM');
    const [prescriptionAccountId, setPrescriptionAccountId] = useState<string>('');
    const [prescriptionDiscount, setPrescriptionDiscount] = useState<string>('');
    const [prescriptionDueDate, setPrescriptionDueDate] = useState('');
    const [isManualDueDate, setIsManualDueDate] = useState(false);
    const [prescriptionType, setPrescriptionType] = useState<'SALE' | 'RETURN'>('SALE');
    
    const currentPrescriptionLabel = prescriptionType === 'RETURN' ? 'İade Faturası' : 'Satış Faturası';
    
    // Recommendations State
    const [recommendedIds, setRecommendedIds] = useState<string[]>(() => {
        const saved = localStorage.getItem('mks_crm_recommended_pesticides_' + userProfile?.id);
        return saved ? JSON.parse(saved) : [];
    });
    const [showRecommendations, setShowRecommendations] = useState(false);

    useEffect(() => {
        if (userProfile?.id) {
            localStorage.setItem('mks_crm_recommended_pesticides_' + userProfile?.id, safeStringify(recommendedIds));
        }
    }, [recommendedIds, userProfile?.id]);

    const toggleRecommendation = (id: string, e?: React.MouseEvent) => {
        if (e) e.stopPropagation();
        setRecommendedIds(prev => 
            prev.includes(id) ? prev.filter(pid => pid !== id) : [...prev, id]
        );
    };
    
    // Detail View State
    const [detailPrescription, setDetailPrescription] = useState<Prescription | null>(null);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [prescriptionToDelete, setPrescriptionToDelete] = useState<string | null>(null);
    const [confirmModal, setConfirmModal] = useState<{
        isOpen: boolean;
        title: string;
        message: string;
        onConfirm: () => void;
        variant?: 'danger' | 'warning' | 'info';
    }>({
        isOpen: false,
        title: '',
        message: '',
        onConfirm: () => {}
    });

    // Edit Mode State
    const [editingId, setEditingId] = useState<string | null>(null);
    const [showProfitId, setShowProfitId] = useState<string | null>(null);
    const [hasInitializedEdit, setHasInitializedEdit] = useState(false);
    const [hasInitializedFarmer, setHasInitializedFarmer] = useState(false);
    
    const [filterMode, setFilterMode] = useState<'ALL' | 'PROCESSED' | 'UNPROCESSED' | 'PAYMENTS'>('ALL');
    const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
    const [paymentAmount, setPaymentAmount] = useState('');
    const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'CHECK' | 'TEDYE'>('CASH');
    const [selectedAccountId, setSelectedAccountId] = useState('');
    const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
    const [paymentNote, setPaymentNote] = useState('');
    const [isSavingPayment, setIsSavingPayment] = useState(false);
    const [selectedPaymentFarmerId, setSelectedPaymentFarmerId] = useState('');
    const [editingPayment, setEditingPayment] = useState<any>(null);
    
    const [isProcessingPdf, setIsProcessingPdf] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const receiptRef = useRef<HTMLDivElement>(null);

    const [isReportModalOpen, setIsReportModalOpen] = useState(false);
    const [reportStartDate, setReportStartDate] = useState<string>(format(new Date(new Date().getFullYear(), new Date().getMonth(), 1), 'yyyy-MM-dd'));
    const [reportEndDate, setReportEndDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
    const [reportTypeSelection, setReportTypeSelection] = useState<'SUMMARY' | 'DETAILED'>('SUMMARY');
    const [isGeneratingReport, setIsGeneratingReport] = useState(false);

    useEffect(() => {
        loadData();
    }, []);

    useEffect(() => {
        if (initialFarmerId && !hasInitializedFarmer && farmers.length > 0) {
            const preSelected = farmers.find(farm => farm.id === initialFarmerId);
            if (preSelected) {
                setSelectedFarmer(preSelected);
                setStep(2);
                setHasInitializedFarmer(true);
                // Ensure history state is correct for initial step 2
                if (window.history.state?.view === 'PRESCRIPTIONS' && !window.history.state.step) {
                    window.history.replaceState({ ...window.history.state, step: 2 }, '');
                }
            }
        }
    }, [initialFarmerId, farmers, hasInitializedFarmer]);

    useEffect(() => {
        if (initialPrescriptionId && !hasInitializedEdit && contextPrescriptions.length > 0 && pesticides.length > 0) {
            const p = contextPrescriptions.find(presc => presc.id === initialPrescriptionId);
            if (p) {
                handleEdit(null as any, p);
                setHasInitializedEdit(true);
            }
        }
    }, [initialPrescriptionId, contextPrescriptions, pesticides, hasInitializedEdit]);

    // Derive available crops for farmer and global catalog
    const farmerCrops = useMemo(() => {
        if (!selectedFarmer) return [];
        const set = new Set<string>();
        if (selectedFarmer.fields) {
            selectedFarmer.fields.forEach(f => {
                if (f.crop && f.crop.trim()) set.add(f.crop.trim());
            });
        }
        contextPrescriptions.forEach(p => {
            if (p.farmerId === selectedFarmer.id) {
                const c = (p.crop || p.cropName || contextPlants.find(pl => pl.id === p.plantId)?.name)?.trim();
                if (c) set.add(c);
            }
        });
        return Array.from(set).sort((a, b) => a.localeCompare(b, 'tr'));
    }, [selectedFarmer, contextPrescriptions, contextPlants]);

    const allAvailableCrops = useMemo<string[]>(() => {
        const set = new Set<string>();
        POPULAR_CROPS.forEach((c: string) => set.add(c));
        contextPlants.forEach(p => {
            if (p.name && p.name.trim()) set.add(p.name.trim());
        });
        farmerCrops.forEach((c: string) => set.add(c));
        return Array.from(set).sort((a: string, b: string) => a.localeCompare(b, 'tr'));
    }, [contextPlants, farmerCrops]);

    const filteredCropsList = useMemo<string[]>(() => {
        if (!cropSearchTerm.trim()) return allAvailableCrops;
        const term = cropSearchTerm.trim().toLowerCase();
        return allAvailableCrops.filter((c: string) => c.toLowerCase().includes(term));
    }, [allAvailableCrops, cropSearchTerm]);

    useEffect(() => {
        if (!selectedFarmer || prescriptionPriceType !== 'TERM' || isManualDueDate) {
            if (prescriptionPriceType !== 'TERM') {
                setPrescriptionDueDate('');
            }
            return;
        }

        // 1. Use selected plant or selected crop for calculation if available
        const plant = contextPlants.find(p => p.id === selectedPlantId || p.name.toLowerCase() === selectedCrop.toLowerCase());
        if (plant && plant.maturityDate) {
            const [month, day] = plant.maturityDate.split('-').map(Number);
            if (!isNaN(month) && !isNaN(day)) {
                const now = new Date();
                let year = now.getFullYear();
                
                const targetDate = new Date(year, month - 1, day);
                if (targetDate < now) {
                    const diffDays = (now.getTime() - targetDate.getTime()) / (1000 * 3600 * 24);
                    if (diffDays > 30) {
                        year += 1;
                    }
                }
                
                const calculatedDate = new Date(year, month - 1, day);
                setPrescriptionDueDate(format(calculatedDate, 'yyyy-MM-dd'));
                return;
            }
        }
        
        // 2. Check selectedCrop directly or field crop
        const cropLower = (selectedCrop || (selectedFarmer.fields?.find(f => f.id === selectedFieldId)?.crop) || '').toLocaleLowerCase('tr-TR');
        if (cropLower) {
            const currentYear = new Date().getFullYear();
            let targetMonth = 11; // Aralık (December)
            let targetDay = 31;

            if (cropLower.includes('arpa')) {
                targetMonth = 5; // Haziran (June)
                targetDay = 1;
            } else if (cropLower.includes('buğday') || cropLower.includes('bugday')) {
                targetMonth = 5; // Haziran
                targetDay = 15;
            } else if (cropLower.includes('pamuk')) {
                targetMonth = 10; // Kasım (November)
                targetDay = 1;
            } else if (cropLower.includes('mısır') || cropLower.includes('misir')) {
                targetMonth = 10; // Kasım
                targetDay = 15;
            } else if (cropLower.includes('ayçiçek') || cropLower.includes('aycicek')) {
                targetMonth = 8; // Eylül
                targetDay = 15;
            } else if (cropLower.includes('üzüm') || cropLower.includes('uzum')) {
                targetMonth = 9; // Ekim
                targetDay = 15;
            }

            const calculatedDate = new Date(currentYear, targetMonth, targetDay);
            setPrescriptionDueDate(format(calculatedDate, 'yyyy-MM-dd'));
            return;
        }

        setPrescriptionDueDate('');
    }, [selectedFieldId, selectedFarmer, prescriptionPriceType, selectedPlantId, selectedCrop, contextPlants]);

    const loadData = async () => {
        setIsLoading(true);
        try {
            const [fListRaw, pestList] = await Promise.all([
                dbService.getFarmers(),
                dbService.getPesticides()
            ]);
            const fList = fListRaw.filter(f => !f.deletedAt);

            setFarmers(fList);
            setPesticides(pestList);

            const fMap: Record<string, Farmer> = {};
            fListRaw.forEach(f => { fMap[f.id] = f; });
            setFarmerMap(fMap);
        } finally {
            setIsLoading(false);
        }
    };

    const handleBackFromForm = () => {
        if (step > 1 && !initialFarmerId) {
            window.history.back();
        } else if (initialFarmerId) {
            onBack(); 
        } else {
            changeViewMode('LIST');
            resetForm();
        }
    };

    const resetForm = (type: 'SALE' | 'RETURN' = 'SALE') => {
        setStep(1);
        setSelectedFarmer(null);
        setFarmerSearchTerm('');
        setPesticideSearchTerm('');
        setSelectedItems([]);
        setSelectedFieldId('');
        setSelectedFieldIds([]);
        setSelectedPlantId('');
        setSelectedCrop('');
        setCropSearchTerm('');
        setCustomCropInput('');
        setDetailPrescription(null);
        setIsProcessingPdf(false);
        setEditingId(null);
        setHasInitializedEdit(false);
        setHasInitializedFarmer(false);
        setShowPrices(true);
        setCustomPrescriptionNo('');
        setPrescriptionPriceType('TERM');
        setPrescriptionAccountId(accounts.find(a => a.type === 'CASH')?.id || accounts[0]?.id || '');
        setPrescriptionDueDate('');
        setIsManualDueDate(false);
        setPrescriptionType(type);
    };

    const addItem = (pesticide: Pesticide) => {
        setSelectedItems(prevItems => {
            const existingItem = prevItems.find(i => i.pesticide.id === pesticide.id);
            if (existingItem) {
                // Increment quantity if already exists
                const currentQty = parseFloat(existingItem.quantity.replace(',', '.')) || 0;
                const newQty = currentQty + 1;
                const price = parseFloat(existingItem.unitPrice || '0') || 0;
                
                return prevItems.map(i => 
                    i.pesticide.id === pesticide.id 
                        ? { ...i, quantity: newQty.toString(), totalPrice: newQty * price }
                        : i
                );
            } else {
                // Find inventory item to get selling price
                const inventoryItem = contextInventory.find(inv => inv.pesticideId === pesticide.id);
                let sellingPrice = '';
                let initialPrice = 0;
                let costPrice = 0;
                
                if (inventoryItem) {
                    if (prescriptionPriceType === 'CASH' && inventoryItem.cashPrice) {
                        sellingPrice = inventoryItem.cashPrice.toString();
                        initialPrice = inventoryItem.cashPrice;
                    } else {
                        sellingPrice = inventoryItem.sellingPrice.toString();
                        initialPrice = inventoryItem.sellingPrice;
                    }
                    costPrice = inventoryItem.buyingPrice || 0;
                }

                // Initialize quantity as '1'
                const initialQty = 1;
                
                return [...prevItems, { 
                    pesticide, 
                    dosage: pesticide.defaultDosage, 
                    quantity: initialQty.toString(), 
                    unitPrice: sellingPrice, 
                    totalPrice: initialQty * initialPrice,
                    buyingPrice: costPrice
                }];
            }
        });
        setPesticideSearchTerm(''); // Seçimden sonra aramayı temizle
    };

    const removeItem = (id: string) => {
        setSelectedItems(selectedItems.filter(i => i.pesticide.id !== id));
    };

    const updateDosage = (id: string, newDosage: string) => {
        setSelectedItems(selectedItems.map(i => i.pesticide.id === id ? { ...i, dosage: newDosage } : i));
    };

    const updateQuantity = (id: string, newQuantity: string) => {
        setSelectedItems(selectedItems.map(i => {
            if (i.pesticide.id === id) {
                const qty = parseFloat(newQuantity.replace(',', '.')) || 0;
                const price = parseFloat((i.unitPrice || '0').replace(',', '.')) || 0;
                return { ...i, quantity: newQuantity, totalPrice: qty * price };
            }
            return i;
        }));
    };

    const updatePrice = (id: string, newPrice: string) => {
        setSelectedItems(selectedItems.map(i => {
            if (i.pesticide.id === id) {
                const qty = parseFloat((i.quantity || '0').replace(',', '.')) || 0;
                const price = parseFloat(newPrice.replace(',', '.')) || 0;
                return { ...i, unitPrice: newPrice, totalPrice: qty * price };
            }
            return i;
        }));
    };

    const handlePriceTypeChange = (newType: 'CASH' | 'TERM') => {
        setPrescriptionPriceType(newType);
        setSelectedItems(selectedItems.map(i => {
            const invItem = contextInventory.find(inv => inv.pesticideId === i.pesticide.id);
            let newPrice = i.unitPrice;
            if (invItem) {
                if (newType === 'CASH' && invItem.cashPrice) {
                    newPrice = invItem.cashPrice.toString();
                } else {
                    newPrice = invItem.sellingPrice.toString();
                }
            }
            const qty = parseFloat(i.quantity.replace(',', '.')) || 0;
            const price = parseFloat(newPrice || '0') || 0;
            return { ...i, unitPrice: newPrice, totalPrice: qty * price };
        }));
    };

    const handleDelete = async (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        setPrescriptionToDelete(id);
        setIsDeleteModalOpen(true);
    };

    const confirmDelete = async () => {
        if (!prescriptionToDelete) return;
        await softDeletePrescription(prescriptionToDelete);
        await loadData();
        showToast(`${prescriptionLabel} ${t('toast.movedToTrash') || 'çöp kutusuna taşındı'}`, 'info');
        hapticFeedback('medium');
        if (viewMode === 'DETAIL') {
            changeViewMode('LIST');
            setDetailPrescription(null);
        }
        setPrescriptionToDelete(null);
    };

    const handleEdit = (e: React.MouseEvent | null, p: Prescription) => {
        if (e) e.stopPropagation();
        
        const farmer = farmerMap[p.farmerId];
        if (farmer) {
            setSelectedFarmer(farmer);
            setSelectedFieldId(p.fieldId || '');
            setSelectedFieldIds(p.fieldIds || (p.fieldId ? [p.fieldId] : []));
            setSelectedPlantId(p.plantId || '');
            const cropVal = p.crop || p.cropName || (contextPlants.find(pl => pl.id === p.plantId)?.name) || (p.fieldId ? farmer?.fields?.find(f => f.id === p.fieldId)?.crop : '') || '';
            setSelectedCrop(cropVal);
        }

        // Reconstruct Pesticide objects from stored items
        const reconstructedItems = p.items.map(item => {
            const libraryPesticide = pesticides.find(pest => pest.id === item.pesticideId);
            const basePesticide = libraryPesticide || {
                id: item.pesticideId,
                name: item.pesticideName,
                activeIngredient: 'Bilinmiyor',
                defaultDosage: item.dosage,
                category: PesticideCategory.OTHER,
                description: 'Kütüphaneden silinmiş ilaç'
            } as Pesticide;

            return { 
                pesticide: basePesticide, 
                dosage: item.dosage,
                quantity: item.quantity || '', // Map existing quantity or default to empty
                unitPrice: item.unitPrice ? item.unitPrice.toString() : '',
                totalPrice: item.totalPrice || 0,
                buyingPrice: item.buyingPrice
            };
        });

        // Eğer en az bir üründe fiyat varsa, fiyat modunu aç
        if (reconstructedItems.some(i => i.unitPrice)) {
            setShowPrices(true);
        } else {
            setShowPrices(false);
        }

        setCustomPrescriptionNo(p.prescriptionNo || '');
        setPrescriptionPriceType(p.priceType || 'TERM');
        const existingTx = transactions.find(t => t.relatedId === p.id);
        setPrescriptionAccountId(p.accountId || existingTx?.accountId || accounts.find(a => a.type === 'CASH')?.id || accounts[0]?.id || '');
        setPrescriptionType(p.type || 'SALE');
        if (p.dueDate) {
            setPrescriptionDueDate(p.dueDate.split('T')[0]);
            setIsManualDueDate(true);
        } else {
            setPrescriptionDueDate('');
            setIsManualDueDate(false);
        }
        setSelectedItems(reconstructedItems);
        setEditingId(p.id);
        changeViewMode('FORM');
        setStep(2); // Set step without pushing again since changeViewMode already pushed
        window.history.replaceState({ ...window.history.state, step: 2 }, '');
    };

    const handleViewDetail = (p: Prescription) => {
        setDetailPrescription(p);
        const farmer = farmerMap[p.farmerId];
        if (farmer) setSelectedFarmer(farmer);
        changeViewMode('DETAIL', p.id);
    };

    const toggleProcessed = async (e: React.MouseEvent, p: Prescription) => {
        e.stopPropagation();
        
        try {
            const updated = await togglePrescriptionStatus(p.id);
            showToast(p.isProcessed ? `${prescriptionLabel} işlenmedi olarak işaretlendi` : `${prescriptionLabel} işlendi olarak işaretlendi`, 'success');
            hapticFeedback('success');
            
            // If we are in detail view, update the detail state as well
            if (detailPrescription && detailPrescription.id === p.id && updated) {
                setDetailPrescription(updated);
            }
        } catch (error) {
            console.error("Toggle processed error:", error);
            showToast("Durum güncellenirken bir hata oluştu.", 'error');
            hapticFeedback('error');
        }
    };

    const handleStatusChange = async (e: React.MouseEvent, p: Prescription, newStatus: 'PENDING' | 'APPROVED' | 'DELIVERED' | 'INVOICED') => {
        e.stopPropagation();
        
        setConfirmModal({
            isOpen: true,
            title: 'Durum Değiştirilecek',
            message: `Sipariş durumunu '${newStatus}' olarak değiştirmek istiyor musunuz?`,
            variant: 'info',
            onConfirm: async () => {
                try {
                    const updatedPrescription = { 
                        ...p, 
                        status: newStatus,
                        deliveredById: newStatus === 'DELIVERED' ? (activeTeamMember?.id || p.deliveredById) : p.deliveredById
                    };
                    await dbService.updatePrescription(updatedPrescription);
                    await refreshStats();
                    
                    // Update context by triggering a refresh or manual state update
                    // For now, updating local detail state
                    if (detailPrescription && detailPrescription.id === p.id) {
                        setDetailPrescription(updatedPrescription);
                    }
                    showToast(`Sipariş durumu güncellendi`, 'success');
                    hapticFeedback('success');
                } catch (error) {
                    console.error("Error updating status:", error);
                    showToast("İşlem sırasında bir hata oluştu", 'error');
                    hapticFeedback('error');
                }
            }
        });
    };

    const handleSave = async () => {
        if (isSavingPrescription || isSavingPrescriptionRef.current) return;
        if (!selectedFarmer) {
            showToast("Lütfen önce bir müşteri seçiniz.", 'error');
            setStep(1);
            return;
        }
        if (!selectedCrop || !selectedCrop.trim()) {
            showToast("Zorunlu alan: Lütfen satışı yapılan mahsulü seçiniz!", 'error');
            hapticFeedback('error');
            setStep(2);
            return;
        }
        if (selectedItems.length === 0) {
            showToast("Lütfen faturaya en az bir ürün ekleyiniz!", 'error');
            hapticFeedback('error');
            setStep(3);
            return;
        }

        isSavingPrescriptionRef.current = true;
        setIsSavingPrescription(true);

        try {
            const items = selectedItems.map(i => ({
                pesticideId: i.pesticide.id,
                pesticideName: i.pesticide.name,
                dosage: i.dosage,
                quantity: i.quantity ? i.quantity.replace(',', '.') : '', // Save standardized quantity
                unitPrice: i.unitPrice ? parseFloat(i.unitPrice.replace(',', '.')) : undefined,
                totalPrice: i.totalPrice,
                buyingPrice: i.buyingPrice
            }));

            const initialTotal = items.reduce((acc, item) => acc + (item.totalPrice || 0), 0);
            const discountValue = parseFloat(prescriptionDiscount.replace(',', '.')) || 0;
            const totalAmount = Math.max(0, initialTotal - discountValue);
            
            if (editingId) {
                // Update existing
                const original = contextPrescriptions.find(p => p.id === editingId);
                if (!original) return;

                // If it was already processed, revert old inventory first
                if (original.isInventoryProcessed) {
                    await dbService.revertInventory(original);
                }

                const updatedPrescription: Prescription = {
                    ...original,
                    farmerId: selectedFarmer.id,
                    fieldId: selectedFieldIds.length === 1 ? selectedFieldIds[0] : (selectedFieldId || undefined),
                    fieldIds: selectedFieldIds,
                    plantId: selectedPlantId || undefined,
                    crop: selectedCrop.trim() || undefined,
                    cropName: selectedCrop.trim() || undefined,
                    engineerName: userProfile.fullName || original.engineerName,
                    prescriptionNo: customPrescriptionNo.trim() || original.prescriptionNo,
                    items: items,
                    totalAmount: totalAmount > 0 ? (prescriptionType === 'RETURN' ? -totalAmount : totalAmount) : undefined,
                    discountAmount: discountValue > 0 ? discountValue : undefined,
                    priceType: prescriptionPriceType,
                    type: prescriptionType,
                    dueDate: prescriptionPriceType === 'TERM' && prescriptionDueDate ? new Date(prescriptionDueDate).toISOString() : undefined,
                    accountId: prescriptionPriceType === 'CASH' ? (prescriptionAccountId || accounts.find(a => a.type === 'CASH')?.id || accounts[0]?.id) : undefined,
                    isProcessed: original.isProcessed,
                    isInventoryProcessed: false // Reset this so it can be re-processed
                };

                await dbService.updatePrescription(updatedPrescription);
                
                // Re-process with new items unconditionally
                await dbService.processInventory(updatedPrescription);

                const targetAccount = updatedPrescription.accountId ? accounts.find(a => a.id === updatedPrescription.accountId) : (accounts.find(a => a.type === 'CASH') || accounts[0]);
                const oldTx = transactions.find(t => t.relatedId === updatedPrescription.id);

                if (updatedPrescription.priceType === 'CASH' && targetAccount) {
                    if (oldTx) {
                        await dbService.updateTransaction({
                            ...oldTx,
                            accountId: targetAccount.id,
                            type: updatedPrescription.type === 'RETURN' ? 'EXPENSE' : 'INCOME',
                            amount: Math.abs(updatedPrescription.totalAmount || 0),
                            date: updatedPrescription.date,
                            description: updatedPrescription.type === 'RETURN' ? 'Peşin İade Kasadan Çıkış' : 'Peşin Satış Tahsilatı',
                            category: 'Satış/İade',
                            partyName: selectedFarmer?.fullName,
                            partyType: 'FARMER',
                            partyId: selectedFarmer?.id
                        });
                    } else {
                        await addTransaction({
                            accountId: targetAccount.id,
                            type: updatedPrescription.type === 'RETURN' ? 'EXPENSE' : 'INCOME',
                            amount: Math.abs(updatedPrescription.totalAmount || 0),
                            date: updatedPrescription.date,
                            description: updatedPrescription.type === 'RETURN' ? 'Peşin İade Kasadan Çıkış' : 'Peşin Satış Tahsilatı',
                            category: 'Satış/İade',
                            relatedId: updatedPrescription.id,
                            partyName: selectedFarmer?.fullName,
                            partyType: 'FARMER',
                            partyId: selectedFarmer?.id
                        });
                    }
                } else if (oldTx) {
                    await deleteTransaction(oldTx.id);
                }

                await refreshStats();

                const finalUpdated = { ...updatedPrescription, isInventoryProcessed: true };
                setDetailPrescription(finalUpdated);
                changeViewMode('DETAIL', finalUpdated.id);
            } else {
                // Create new
                const targetAccId = prescriptionAccountId || accounts.find(a => a.type === 'CASH')?.id || accounts[0]?.id;
                const newPrescription: Prescription = {
                    id: crypto.randomUUID(),
                    farmerId: selectedFarmer.id,
                    fieldId: selectedFieldIds.length === 1 ? selectedFieldIds[0] : (selectedFieldId || undefined),
                    fieldIds: selectedFieldIds,
                    plantId: selectedPlantId || undefined,
                    crop: selectedCrop.trim() || undefined,
                    cropName: selectedCrop.trim() || undefined,
                    date: new Date().toISOString(),
                    prescriptionNo: customPrescriptionNo.trim() || `REC-${new Date().getFullYear()}-${Math.floor(Math.random() * 1000)}`,
                    engineerName: userProfile.fullName || 'Ziraat Mühendisi',
                    items: items,
                    isOfficial: true,
                    isProcessed: true,
                    isInventoryProcessed: false,
                    totalAmount: totalAmount > 0 ? (prescriptionType === 'RETURN' ? -totalAmount : totalAmount) : undefined,
                    discountAmount: discountValue > 0 ? discountValue : undefined,
                    priceType: prescriptionPriceType,
                    type: prescriptionType,
                    dueDate: prescriptionPriceType === 'TERM' && prescriptionDueDate ? new Date(prescriptionDueDate).toISOString() : undefined,
                    accountId: prescriptionPriceType === 'CASH' ? targetAccId : undefined,
                    status: undefined,
                    createdById: activeTeamMember?.id
                };

                await dbService.addPrescription(newPrescription);
                await dbService.processInventory(newPrescription);

                if (newPrescription.priceType === 'CASH' && targetAccId) {
                    const existingTx = transactions.find(t => t.relatedId === newPrescription.id);
                    if (!existingTx) {
                        await addTransaction({
                            accountId: targetAccId,
                            type: newPrescription.type === 'RETURN' ? 'EXPENSE' : 'INCOME',
                            amount: Math.abs(newPrescription.totalAmount || 0),
                            date: newPrescription.date,
                            description: newPrescription.type === 'RETURN' ? 'Peşin İade Kasadan Çıkış' : 'Peşin Satış Tahsilatı',
                            category: 'Satış/İade',
                            relatedId: newPrescription.id,
                            partyName: selectedFarmer?.fullName,
                            partyType: 'FARMER',
                            partyId: selectedFarmer?.id
                        });
                    }
                }
                
                const currentTypeLabel = newPrescription.type === 'RETURN' ? 'İade Faturası' : 'Satış Faturası';
                
                // Create a visit log entry automatically
                const newVisit: VisitLog = {
                    id: crypto.randomUUID(),
                    farmerId: selectedFarmer.id,
                    fieldId: selectedFieldIds.length > 0 ? selectedFieldIds[0] : (selectedFieldId || undefined),
                    date: new Date().toISOString(),
                    note: `${currentTypeLabel} işlendi (${newPrescription.prescriptionNo})`,
                    village: selectedFarmer.village
                };
                await dbService.addVisit(newVisit);
                
                // Add a notification
                const newNotification: AppNotification = {
                    id: crypto.randomUUID(),
                    type: 'SUCCESS',
                    title: `${currentTypeLabel} ve Reçete Kaydı`,
                    message: `${selectedFarmer.fullName} için ${currentTypeLabel.toLowerCase()} işlendi ve ziyaret kaydı oluşturuldu.`,
                    date: new Date().toISOString(),
                    isRead: false
                };
                await dbService.addNotification(newNotification);
                
                const finalNew = { ...newPrescription, isInventoryProcessed: true };
                setDetailPrescription(finalNew);
                changeViewMode('DETAIL', finalNew.id, true);
            }

            await loadData();
            await refreshStats();
            showToast(`${currentPrescriptionLabel} başarıyla kaydedildi`, 'success');
            hapticFeedback('success');
        } catch (error) {
            console.error("Save prescription error:", error);
            showToast("Kayıt sırasında bir hata oluştu", 'error');
            hapticFeedback('error');
        } finally {
            isSavingPrescriptionRef.current = false;
            setIsSavingPrescription(false);
        }
    };

    const handleWhatsAppText = (targetPrescription: Prescription, targetFarmer: Farmer) => {
        const farmer = farmerMap[targetPrescription.farmerId];
        const typeLabel = targetPrescription.type === 'RETURN' ? 'İADE FATURASI' : 'ZİRAİ FATURA';
        let text = `*${typeLabel}*\n`;
        text += `Sayın *${targetFarmer.fullName}*,\n\n`;
        
        const fIds = targetPrescription.fieldIds || (targetPrescription.fieldId ? [targetPrescription.fieldId] : []);
        if (fIds.length > 0 && farmer?.fields) {
            const names = fIds.map(id => farmer.fields.find(f => f.id === id)?.name).filter(Boolean);
            if (names.length > 0) {
                text += `Araziler: ${names.join(', ')}\n`;
            }
        }

        text += `Tarih: ${new Date(targetPrescription.date).toLocaleDateString('tr-TR')}\n`;
        text += `Fatura No: ${targetPrescription.prescriptionNo}\n\n`;
        
        const hasPrices = targetPrescription.items.some(item => item.unitPrice && item.unitPrice > 0);

        if (hasPrices) {
            text += `*Ürün Listesi:*\n`;
            targetPrescription.items.forEach(item => {
                const qty = item.quantity ? item.quantity.toString().replace(/^-/, '').replace(',', '.') : '1';
                const price = item.unitPrice || 0;
                const total = Math.abs(item.totalPrice || (parseFloat(qty) * price) || 0);
                
                text += `- ${item.pesticideName}: ${qty} Adet x ${formatCurrency(price, userProfile?.currency || 'TRY')} = *${formatCurrency(total, userProfile?.currency || 'TRY')}*\n`;
            });
            
            if (targetPrescription.totalAmount) {
                if (targetPrescription.discountAmount && targetPrescription.discountAmount > 0) {
                    text += `\nAra Toplam: ${formatCurrency(targetPrescription.totalAmount + targetPrescription.discountAmount, userProfile?.currency || 'TRY')}\n`;
                    text += `İskonto (İndirim): -${formatCurrency(targetPrescription.discountAmount, userProfile?.currency || 'TRY')}\n`;
                }
                text += `\n*ÖDENECEK TUTAR: ${formatCurrency(targetPrescription.totalAmount, userProfile?.currency || 'TRY')}*\n`;
            }
        } else {
            text += `*Kullanılacak İlaçlar:*\n`;
            targetPrescription.items.forEach(item => {
                text += `- ${item.pesticideName}: *${item.dosage}*`;
                if (item.quantity) text += ` (${item.quantity} Adet)`;
                text += `\n`;
            });
        }
        
        text += `\nGeçmiş olsun.\n${targetPrescription.engineerName}`;
        
        const url = `https://wa.me/${targetFarmer.phoneNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(text)}`;
        window.open(url, '_blank');
    };

    const handlePdfAction = async (action: 'SHARE' | 'DOWNLOAD', targetPrescription?: Prescription, targetFarmer?: Farmer) => {
        if (!receiptRef.current) return;
        setIsProcessingPdf(true);

        const currentPrescription = targetPrescription || detailPrescription;
        const currentFarmer = targetFarmer || selectedFarmer;

        if (!currentPrescription || !currentFarmer) return;

        try {
            // Mobile Optimization: Reduced Scale & JPEG
            const canvas = await html2canvas(receiptRef.current, {
                scale: 2, 
                backgroundColor: '#ffffff',
                useCORS: true,
                logging: false,
                allowTaint: true
            });

            const pdf = createMultiPagePdf(canvas);
            
            const pdfBlob = pdf.output('blob');
            
            // Türkçe karakterleri tamamen ASCII'ye çevir (Android dosya sistemi uyumluluğu için)
            const charMap: {[key: string]: string} = {'Ğ':'G','ğ':'g','Ü':'U','ü':'u','Ş':'S','ş':'s','İ':'I','ı':'i','Ö':'O','ö':'o','Ç':'C','ç':'c'};
            const safeName = currentFarmer.fullName
                .replace(/[ĞğÜüŞşİıÖöÇç]/g, match => charMap[match])
                .replace(/[^a-zA-Z0-9]/g, '_')
                .replace(/_+/g, '_')
                .replace(/^_|_$/g, '');
            const pNo = currentPrescription.prescriptionNo;
            const fileName = `${safeName}_${currentPrescription.type === 'RETURN' ? 'Iade' : 'Satis'}_${pNo}.pdf`;

            if (action === 'DOWNLOAD') {
                pdf.save(fileName);
            } else {
                const file = new File([pdfBlob], fileName, { type: 'application/pdf' });
                const shareData = {
                    files: [file],
                    title: currentPrescription.type === 'RETURN' ? 'İade Faturası' : 'Zirai Satış Faturası',
                };
                try {
                    if (navigator.canShare && navigator.canShare(shareData)) {
                        await navigator.share(shareData);
                    } else {
                        throw new Error("Share API not supported");
                    }
                } catch (err) {
                    console.warn("Share failed, fallback to download", err);
                    pdf.save(fileName);
                }
            }

        } catch (error) {
            console.error("PDF Action Error:", error);
            showToast("PDF işleminde bir hata oluştu.", "error");
        } finally {
            setIsProcessingPdf(false);
        }
    };

    const filteredFarmers = farmers.filter(f => 
        turkishMatchesAny([f.fullName, f.village, f.phoneNumber], farmerSearchTerm)
    );

    const filteredInventoryItems = contextInventory.filter(inv => 
        turkishMatchesAny([inv.pesticideName, inv.barcode], pesticideSearchTerm)
    );

    const filteredPrescriptions = contextPrescriptions.filter(p => {
        const farmer = farmerMap[p.farmerId];
        const matchesSearch = turkishMatchesAny([p.prescriptionNo, farmer?.fullName, p.crop, p.cropName], prescriptionSearchTerm);
            
        const matchesFilter = filterMode === 'ALL' || 
            (filterMode === 'PROCESSED' && p.isProcessed) ||
            (filterMode === 'UNPROCESSED' && !p.isProcessed) ||
            filterMode === 'PAYMENTS';
            
        return matchesSearch && matchesFilter;
    });

    const filteredPaymentsForList = filterMode === 'PAYMENTS' ? payments.filter(p => {
        if (!prescriptionSearchTerm) return true;
        const farmer = farmerMap[p.farmerId];
        return turkishMatchesAny([farmer?.fullName, p.crop, p.note], prescriptionSearchTerm);
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()) : [];

    const trToEn = (text: string) => {
        if (!text) return '';
        return text
            .replace(/Ğ/g, 'G').replace(/ğ/g, 'g')
            .replace(/Ü/g, 'U').replace(/ü/g, 'u')
            .replace(/Ş/g, 'S').replace(/ş/g, 's')
            .replace(/İ/g, 'I').replace(/ı/g, 'i')
            .replace(/Ö/g, 'O').replace(/ö/g, 'o')
            .replace(/Ç/g, 'C').replace(/ç/g, 'c');
    };

    const pdfCurrency = (amount: number) => {
        return new Intl.NumberFormat('tr-TR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(amount);
    };

    const generatePrescriptionReportPDF = async () => {
        setIsGeneratingReport(true);
        setTimeout(async () => {
            try {
                const container = document.createElement('div');
                container.style.position = 'absolute';
                container.style.left = '-9999px';
                container.style.top = '0';
                container.style.width = '800px';
                container.style.backgroundColor = '#ffffff';
                container.style.padding = '40px';
                container.style.color = '#1c1917';
                container.style.fontFamily = 'system-ui, -apple-system, sans-serif';

                const start = new Date(reportStartDate);
                start.setHours(0, 0, 0, 0);
                const end = new Date(reportEndDate);
                end.setHours(23, 59, 59, 999);

                const filtered = contextPrescriptions.filter(p => {
                    const date = new Date(p.date || Date.now());
                    return date >= start && date <= end;
                });

                let totalSales = 0;
                let totalReturns = 0;

                let htmlContent = `
                    <div style="margin-bottom: 30px;">
                        <h1 style="font-size: 26px; font-weight: 800; margin: 0 0 8px 0; color: #3b82f6; text-transform: uppercase;">
                            ${userProfile?.companyName || "FATURA RAPORU"}
                        </h1>
                        <h2 style="font-size: 18px; font-weight: 700; margin: 0 0 4px 0; color: #1c1917;">
                            ${reportTypeSelection === 'SUMMARY' ? 'Fatura Listesi (Özet)' : 'Fatura Listesi (Detaylı)'}
                        </h2>
                        <p style="font-size: 13px; margin: 0; color: #78716c;">
                            Tarih Aralığı: ${format(start, 'dd.MM.yyyy')} - ${format(end, 'dd.MM.yyyy')} &nbsp;&bull;&nbsp; Oluşturulma: ${format(new Date(), 'dd.MM.yyyy HH:mm')}
                        </p>
                    </div>
                `;

                if (reportTypeSelection === 'SUMMARY') {
                    htmlContent += `
                        <table style="width: 100%; border-collapse: collapse; font-size: 11px; text-align: left; margin-bottom: 40px;">
                            <thead>
                                <tr style="background-color: #3b82f6; color: white;">
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb; border-top-left-radius: 6px;">Tarih</th>
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb;">Müşteri</th>
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb;">Fatura No</th>
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb;">Tür</th>
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb;">Vade</th>
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb; border-top-right-radius: 6px; text-align: right;">Tutar</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;

                    if (filtered.length === 0) {
                        htmlContent += `<tr><td colspan="6" style="padding: 15px; text-align: center; color: #78716c;">Seçili tarihte kayıt yok.</td></tr>`;
                    } else {
                        filtered.forEach((p, i) => {
                            const farmer = contextFarmers.find(f => f.id === p.farmerId);
                            const netAmount = p.totalAmount || 0;
                            
                            if (p.type === 'RETURN') totalReturns += netAmount;
                            else totalSales += netAmount;

                            const bg = i % 2 === 0 ? '#fafaf9' : '#ffffff';
                            const typeColor = p.type === 'RETURN' ? '#ef4444' : '#10b981';
                            
                            htmlContent += `
                                <tr style="background-color: ${bg}; border-bottom: 1px solid #e7e5e4;">
                                    <td style="padding: 10px;">${format(new Date(p.date || Date.now()), 'dd.MM.yyyy')}</td>
                                    <td style="padding: 10px; font-weight: 600;">${farmer?.fullName || '-'}</td>
                                    <td style="padding: 10px; font-family: monospace;">${p.prescriptionNo || '-'}</td>
                                    <td style="padding: 10px; color: ${typeColor}; font-weight: bold;">${p.type === 'RETURN' ? 'İade' : 'Satış'}</td>
                                    <td style="padding: 10px;">${p.dueDate ? format(new Date(p.dueDate), 'dd.MM.yyyy') : '-'}</td>
                                    <td style="padding: 10px; text-align: right; font-family: monospace; font-size: 12px; font-weight: 600;">${formatCurrency(netAmount, userProfile?.currency || 'TRY')}</td>
                                </tr>
                            `;
                        });
                    }
                    htmlContent += `</tbody></table>`;
                } else {
                    htmlContent += `
                        <table style="width: 100%; border-collapse: collapse; font-size: 11px; text-align: left; margin-bottom: 40px;">
                            <thead>
                                <tr style="background-color: #3b82f6; color: white;">
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb; border-top-left-radius: 6px; width: 40%;">Müşteri / Ürün Adı</th>
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb; text-align: center;">Miktar</th>
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb; text-align: right;">Birim Fiyat</th>
                                    <th style="padding: 10px; border-bottom: 2px solid #2563eb; border-top-right-radius: 6px; text-align: right;">Tutar</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;

                    if (filtered.length === 0) {
                        htmlContent += `<tr><td colspan="4" style="padding: 15px; text-align: center; color: #78716c;">Seçili tarihte kayıt yok.</td></tr>`;
                    } else {
                        filtered.forEach(p => {
                            const farmer = contextFarmers.find(f => f.id === p.farmerId);
                            const netAmount = p.totalAmount || 0;
                            
                            if (p.type === 'RETURN') totalReturns += netAmount;
                            else totalSales += netAmount;

                            const vDate = p.dueDate ? ` | Vade: ${format(new Date(p.dueDate), 'dd.MM.yyyy')}` : '';
                            const typeStr = p.type === 'RETURN' ? 'İade' : 'Satış';

                            htmlContent += `
                                <tr style="background-color: #f1f5f9; border-top: 2px solid #cbd5e1; border-bottom: 1px solid #cbd5e1;">
                                    <td colspan="3" style="padding: 10px; font-weight: bold; color: #0f172a;">
                                        ${format(new Date(p.date || Date.now()), 'dd.MM.yyyy')} | ${farmer?.fullName || '-'} | Fatura No: ${p.prescriptionNo || '-'} | Tür: ${typeStr}${vDate}
                                    </td>
                                    <td style="padding: 10px; text-align: right; font-weight: bold; font-family: monospace; font-size: 12px; color: #0f172a;">
                                        ${formatCurrency(netAmount, userProfile?.currency || 'TRY')}
                                    </td>
                                </tr>
                            `;

                            p.items.forEach(item => {
                                htmlContent += `
                                    <tr style="border-bottom: 1px solid #f1f5f9;">
                                        <td style="padding: 8px 10px 8px 20px;">${item.pesticideName}</td>
                                        <td style="padding: 8px 10px; text-align: center;">${item.quantity || '-'}</td>
                                        <td style="padding: 8px 10px; text-align: right; font-family: monospace;">${item.unitPrice ? formatCurrency(item.unitPrice, userProfile?.currency || 'TRY') : '-'}</td>
                                        <td style="padding: 8px 10px; text-align: right; font-family: monospace; font-weight: 600;">${item.totalPrice ? formatCurrency(item.totalPrice, userProfile?.currency || 'TRY') : '-'}</td>
                                    </tr>
                                `;
                            });

                            if (p.discountAmount && p.discountAmount > 0) {
                                htmlContent += `
                                    <tr style="border-bottom: 1px solid #f1f5f9; background-color: #fef2f2;">
                                        <td style="padding: 8px 10px 8px 20px; font-weight: bold; color: #dc2626;">İskonto (İndirim)</td>
                                        <td style="padding: 8px 10px;"></td>
                                        <td style="padding: 8px 10px;"></td>
                                        <td style="padding: 8px 10px; text-align: right; font-family: monospace; font-weight: bold; color: #dc2626;">-${formatCurrency(p.discountAmount, userProfile?.currency || 'TRY')}</td>
                                    </tr>
                                `;
                            }
                        });
                    }
                    htmlContent += `</tbody></table>`;
                }

                htmlContent += `
                    <div style="page-break-inside: avoid; width: 300px; margin-left: auto;">
                        <h3 style="font-size: 14px; font-weight: 800; margin: 0 0 10px 0; color: #1c1917; text-transform: uppercase;">Özet</h3>
                        <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                            <tbody>
                                <tr style="border-bottom: 1px solid #e7e5e4;">
                                    <td style="padding: 8px; color: #57534e;">Toplam Satış Tutarı</td>
                                    <td style="padding: 8px; text-align: right; font-family: monospace; font-weight: bold;">${formatCurrency(totalSales, userProfile?.currency || 'TRY')}</td>
                                </tr>
                                <tr style="border-bottom: 1px solid #e7e5e4;">
                                    <td style="padding: 8px; color: #57534e;">Toplam İade Tutarı</td>
                                    <td style="padding: 8px; text-align: right; font-family: monospace; font-weight: bold; color: #ef4444;">${formatCurrency(totalReturns, userProfile?.currency || 'TRY')}</td>
                                </tr>
                                <tr style="background-color: #10b981; color: white;">
                                    <td style="padding: 10px; border-bottom-left-radius: 6px; font-weight: bold;">NET TOPLAM</td>
                                    <td style="padding: 10px; border-bottom-right-radius: 6px; text-align: right; font-family: monospace; font-weight: bold; font-size: 14px;">${formatCurrency(totalSales - totalReturns, userProfile?.currency || 'TRY')}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                `;

                container.innerHTML = htmlContent;
                document.body.appendChild(container);

                const canvas = await html2canvas(container, {
                    scale: 2,
                    backgroundColor: '#ffffff',
                    logging: false
                });

                document.body.removeChild(container);
                
                const pdf = createMultiPagePdf(canvas);
                pdf.save(`Fatura_Raporu_${format(new Date(), 'yyyyMMdd_HHmm')}.pdf`);
                
                setIsGeneratingReport(false);
                setIsReportModalOpen(false);
                showToast("PDF başarıyla oluşturuldu.", "success");
            } catch (error: any) {
                console.error("Report PDF Error:", error?.message || error);
                setIsGeneratingReport(false);
                showToast("PDF oluşturulurken bir hata oluştu.", "error");
            }
        }, 100);
    };

    if (viewMode === 'LIST') {
        return (
            <div className="relative h-full min-h-[80vh]">
                <div className="p-4 max-w-3xl mx-auto pb-24">
                    <header className="mb-4 flex justify-between items-center sticky top-0 bg-stone-950/80 backdrop-blur z-20 py-2">
                        <div>
                            <h2 className="text-2xl font-bold text-stone-100">{t('prescription.title', { label: prescriptionLabel })}</h2>
                            <p className="text-sm text-stone-500">{t('prescription.subtitle', { label: prescriptionLabel.toLowerCase() })}</p>
                            {userProfile.lastSyncTime && (
                                <p className="text-[10px] text-emerald-500/80 mt-0.5 flex items-center">
                                    <Check size={10} className="mr-1" />
                                    {t('prescription.last_sync')}: {new Date(userProfile.lastSyncTime).toLocaleTimeString(userProfile.language === 'tr' ? 'tr-TR' : userProfile.language === 'ar' ? 'ar-SA' : 'en-US', {hour: '2-digit', minute:'2-digit'})}
                                </p>
                            )}
                        </div>
                        <button 
                            onClick={() => setIsReportModalOpen(true)}
                            className="px-3 py-1.5 bg-stone-900 text-stone-400 rounded-xl border border-white/5 hover:text-emerald-400 hover:bg-stone-800 transition-all active:scale-95 flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider"
                            title="Rapor Oluştur"
                        >
                            <FileText size={14} />
                            Rapor
                        </button>
                    </header>

                    <div className="bg-stone-900 rounded-2xl shadow-sm border border-white/5 flex items-center p-1 mb-6 sticky top-20 z-10 backdrop-blur-md">
                        <Search className="text-stone-500 ml-3" size={18} />
                        <input 
                            type="text" 
                            placeholder={t('prescription.search_placeholder', { farmer: farmerLabel, label: prescriptionLabel.toLowerCase() })} 
                            className="w-full p-2.5 bg-transparent outline-none font-medium text-stone-200 placeholder-stone-600 text-sm"
                            value={prescriptionSearchTerm}
                            onChange={e => setPrescriptionSearchTerm(e.target.value)}
                        />
                        {prescriptionSearchTerm && (
                            <button onClick={() => setPrescriptionSearchTerm('')} className="p-2 text-stone-500 hover:text-stone-300">
                                <X size={16} />
                            </button>
                        )}
                    </div>

                    {/* Filter Buttons */}
                    <div className="flex p-1 bg-stone-900/80 backdrop-blur-xl rounded-2xl border border-white/5 mb-8 w-fit shadow-inner">
                        <button 
                            onClick={() => setFilterMode('ALL')}
                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                filterMode === 'ALL' 
                                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20 scale-[1.02]' 
                                : 'text-stone-500 hover:text-stone-300'
                            }`}
                        >
                            {t('prescription.filter_all')}
                        </button>
                        <button 
                            onClick={() => setFilterMode('UNPROCESSED')}
                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                                filterMode === 'UNPROCESSED' 
                                ? 'bg-rose-600 text-white shadow-lg shadow-rose-900/20 scale-[1.02]' 
                                : 'text-stone-500 hover:text-stone-300'
                            }`}
                        >
                            <div className={`w-1.5 h-1.5 rounded-full ${filterMode === 'UNPROCESSED' ? 'bg-white animate-pulse' : 'bg-rose-500'}`}></div>
                            {t('prescription.filter_unprocessed')}
                        </button>
                        <button 
                            onClick={() => setFilterMode('PROCESSED')}
                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                                filterMode === 'PROCESSED' 
                                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20 scale-[1.02]' 
                                : 'text-stone-500 hover:text-stone-300'
                            }`}
                        >
                            <div className={`w-1.5 h-1.5 rounded-full ${filterMode === 'PROCESSED' ? 'bg-white' : 'bg-blue-500'}`}></div>
                            {t('prescription.filter_processed')}
                        </button>
                        <button 
                            onClick={() => setFilterMode('PAYMENTS')}
                            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                                filterMode === 'PAYMENTS' 
                                ? 'bg-amber-600 text-white shadow-lg shadow-amber-900/20 scale-[1.02]' 
                                : 'text-stone-500 hover:text-stone-300'
                            }`}
                        >
                            <div className={`w-1.5 h-1.5 rounded-full ${filterMode === 'PAYMENTS' ? 'bg-white' : 'bg-amber-500'}`}></div>
                            Tahsilatlar
                        </button>
                    </div>

                    <div className="space-y-3">
                        {isLoading ? (
                            <ListSkeleton count={5} />
                        ) : filteredPrescriptions.length === 0 ? (
                            <EmptyState
                                icon={FileText}
                                title={prescriptionSearchTerm ? t('prescription.empty_search', { label: prescriptionLabel.toLowerCase() }) : t('prescription.empty_list', { label: prescriptionLabel.toLowerCase() })}
                                description={!prescriptionSearchTerm ? t('prescription.empty_hint', { label: prescriptionLabel.toLowerCase() }) : ''}
                                actionLabel={canCreatePrescription && !prescriptionSearchTerm ? `Yeni ${prescriptionLabel} Oluştur` : undefined}
                                onAction={canCreatePrescription && !prescriptionSearchTerm ? () => changeViewMode('FORM') : undefined}
                                actionIcon={Plus}
                            />
                        ) : filterMode === 'PAYMENTS' ? (
                            filteredPaymentsForList.map(p => {
                                const farmer = farmerMap[p.farmerId];
                                const dateObj = new Date(p.date);
                                const isCheckOrTedye = p.method === 'CHECK' || p.method === 'TEDYE';
                                return (
                                    <div 
                                        key={p.id}
                                        className="bg-stone-900/80 backdrop-blur-xl p-2.5 rounded-2xl shadow-xl border border-white/10 hover:border-emerald-500/30 transition-all relative overflow-hidden group active:scale-[0.98]"
                                    >
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex items-center space-x-3">
                                                <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold border shadow-inner shrink-0 bg-emerald-900/20 text-emerald-500 border-emerald-500/20">
                                                    <CreditCard size={16} />
                                                </div>
                                                <div className="min-w-0">
                                                    <div className="flex items-center gap-1.5">
                                                        <h3 className="font-black text-stone-100 text-sm leading-tight truncate tracking-tight">{farmer?.fullName || 'Bilinmeyen Çiftçi'}</h3>
                                                    </div>
                                                    <div className="flex items-center gap-2 mt-0.5">
                                                        <span className="text-[8px] text-stone-400 font-bold flex items-center bg-stone-800/50 px-1.5 py-0.5 rounded">
                                                            <User size={8} className="mr-1" />
                                                            {p.createdById ? (teamMembers.find(m => m.id === p.createdById)?.fullName || 'Yönetici') : 'Yönetici'}
                                                        </span>
                                                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all items-center">
                                                            <button onClick={(e) => { e.stopPropagation(); handleEditPayment(p); }} className="p-1 text-stone-500 hover:text-emerald-500">
                                                                <Edit2 size={12}/>
                                                            </button>
                                                            <button onClick={(e) => { e.stopPropagation(); handleDeletePayment(p.id); }} className="p-1 text-stone-500 hover:text-rose-500 transition-all">
                                                                <Trash2 size={12}/>
                                                            </button>
                                                        </div>
                                                        <button 
                                                            onClick={(e) => { e.stopPropagation(); handleSendReceiptButton(p); }}
                                                            className="px-1.5 py-0.5 text-[8px] font-black uppercase text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 rounded hover:bg-emerald-500/20 transition-all shadow-sm flex items-center justify-center cursor-pointer"
                                                        >
                                                            MAKBUZ
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="flex flex-col items-end gap-1.5 shrink-0 ml-2">
                                                <div className="flex items-center gap-1.5">
                                                    <span className={`text-[9px] font-black font-mono px-1.5 py-0.5 rounded border shadow-sm bg-emerald-950/50 text-emerald-400 border-emerald-500/20`}>
                                                        {formatCurrency(p.amount, userProfile?.currency || 'TRY')}
                                                    </span>
                                                    <span className="text-[8px] font-black text-stone-400 flex items-center bg-stone-950/50 px-1.5 py-0.5 rounded border border-white/5 shadow-sm uppercase tracking-widest">
                                                        <Calendar size={8} className="mr-1" />
                                                        {dateObj.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' })}
                                                    </span>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[8px] font-black text-stone-400 uppercase tracking-widest">
                                                        {p.method === 'CASH' ? 'Nakit' : p.method === 'CARD' ? 'Kredi Kartı' : p.method === 'CHECK' ? 'Çek' : p.method === 'TEDYE' ? 'Tediye' : 'Diğer'}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })
                        ) : (
                            filteredPrescriptions.map(p => {
                                const farmer = farmerMap[p.farmerId];
                                const dateObj = new Date(p.date);

                                return (
                                    <div 
                                        key={p.id} 
                                        onClick={() => handleViewDetail(p)}
                                        className="bg-stone-900/80 backdrop-blur-xl p-2.5 rounded-2xl shadow-xl border border-white/10 hover:border-emerald-500/30 transition-all relative overflow-hidden group cursor-pointer active:scale-[0.98]"
                                    >
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex items-center space-x-3">
                                                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold border shadow-inner shrink-0 ${p.type === 'RETURN' ? 'bg-amber-900/20 text-amber-500 border-amber-500/20' : 'bg-blue-900/20 text-blue-400 border-blue-500/20'}`}>
                                                    {p.type === 'RETURN' ? <ArrowLeft size={16} /> : <FileText size={16} />}
                                                </div>
                                                <div className="min-w-0">
                                                    <div className="flex items-center gap-1.5">
                                                        <h3 className="font-black text-stone-100 text-sm leading-tight truncate tracking-tight">{farmer?.fullName || t('prescription.unknown_farmer', { farmer: farmerLabel })}</h3>
                                                        {p.type === 'RETURN' && (
                                                            <span className="text-[7px] font-black uppercase tracking-widest bg-amber-500/20 text-amber-500 px-1.5 py-0.5 rounded border border-amber-500/30">İADE</span>
                                                        )}
                                                        {p.priceType === 'CASH' && (
                                                            <span className="text-[7px] font-black uppercase tracking-widest bg-emerald-500/20 text-emerald-500 px-1.5 py-0.5 rounded border border-emerald-500/30">PEŞİN</span>
                                                        )}
                                                    </div>
                                                    <div className="flex items-center gap-2 mt-0.5">
                                                        <p className="text-[8px] text-stone-500 font-black uppercase tracking-widest">{p.prescriptionNo}</p>
                                                        <span className="text-[8px] text-stone-400 font-bold flex items-center bg-stone-800/50 px-1.5 py-0.5 rounded">
                                                            <User size={8} className="mr-1" />
                                                            {p.createdById ? (teamMembers.find(m => m.id === p.createdById)?.fullName || t('prescription.manager')) : t('prescription.manager')}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="flex flex-col items-end gap-1.5 shrink-0 ml-2">
                                                <div className="flex items-center gap-1.5">
                                                    <button 
                                                        onClick={(e) => { e.stopPropagation(); setShowProfitId(p.id); }}
                                                        className="w-7 h-7 rounded-lg flex items-center justify-center bg-emerald-600/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-600/20 transition-all active:scale-90"
                                                        title="Kar/Zarar Analizi"
                                                    >
                                                        <TrendingUp size={14} />
                                                    </button>
                                                    {p.totalAmount !== undefined && p.totalAmount !== null && Math.abs(p.totalAmount) > 0 && (
                                                        <span className={`text-[9px] font-black font-mono px-1.5 py-0.5 rounded border shadow-sm ${p.type === 'RETURN' ? 'bg-amber-950/50 text-amber-400 border-amber-500/20' : 'bg-emerald-950/50 text-emerald-400 border-emerald-500/20'}`}>
                                                            {p.type === 'RETURN' ? '-' : ''}{formatCurrency(Math.abs(p.totalAmount), userProfile?.currency || 'TRY')}
                                                        </span>
                                                    )}
                                                    <span className="text-[8px] font-black text-stone-400 flex items-center bg-stone-950/50 px-1.5 py-0.5 rounded border border-white/5 shadow-sm uppercase tracking-widest">
                                                        <Calendar size={8} className="mr-1" />
                                                        {dateObj.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' })}
                                                    </span>
                                                </div>
                                                <button 
                                                        type="button"
                                                        onClick={(e) => toggleProcessed(e, p)}
                                                        className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all border-2 active:scale-90 relative z-30 shadow-lg ${
                                                            p.isProcessed 
                                                            ? 'bg-blue-600/10 border-blue-500/30 text-blue-400' 
                                                            : 'bg-rose-600/10 border-rose-500/30 text-rose-400'
                                                        }`}
                                                    >
                                                        {p.isProcessed ? <Check size={14} strokeWidth={3} /> : <X size={14} strokeWidth={3} />}
                                                    </button>
                                            </div>
                                        </div>
                                        <div className="pl-11 mt-1">
                                            <div className="flex flex-wrap gap-1">
                                                {p.items.slice(0, 3).map((item, idx) => (
                                                    <span key={idx} className="text-[7px] font-black uppercase tracking-widest bg-stone-950/50 text-stone-500 px-1.5 py-0.5 rounded border border-white/5">
                                                        {item.pesticideName} {item.quantity && `(x${item.quantity.toString().replace(/^-/, '')})`}
                                                    </span>
                                                ))}
                                                {p.items.length > 3 && (
                                                    <span className="text-[7px] font-black uppercase tracking-widest bg-stone-950/50 text-stone-600 px-1.5 py-0.5 rounded border border-white/5">
                                                        +{p.items.length - 3}
                                                    </span>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })
                        )}
                    </div>
                </div>

                {canCreatePrescription && (
                    <div className="fixed bottom-32 right-6 md:bottom-10 md:right-10 z-50 flex flex-col gap-2 shadow-2xl">
                        <button 
                            onClick={() => {
                                setIsPaymentModalOpen(true);
                                setSelectedPaymentFarmerId('');
                                setPaymentAmount('');
                                setPaymentNote('');
                                setPaymentDate(new Date().toISOString().split('T')[0]);
                                setPaymentMethod('CASH');
                                setEditingPayment(null);
                            }}
                            className="bg-emerald-800 text-emerald-100 px-6 py-3 rounded-full shadow-lg shadow-emerald-900/20 hover:bg-emerald-700 transition-all transform hover:scale-105 flex items-center justify-center gap-2 font-bold text-sm border border-emerald-900"
                        >
                            <CreditCard size={18} /> Tahsilat Faturası
                        </button>
                        <button 
                            onClick={() => { resetForm('RETURN'); changeViewMode('FORM'); }}
                            className="bg-amber-500 text-stone-900 px-6 py-3 rounded-full shadow-lg shadow-amber-500/20 hover:bg-amber-400 transition-all transform hover:scale-105 flex items-center justify-center gap-2 font-bold text-sm border border-stone-900"
                        >
                            <ArrowLeft size={18} /> İade Faturası
                        </button>
                        <button 
                            onClick={() => { resetForm('SALE'); changeViewMode('FORM'); }}
                            className="bg-emerald-600 text-white px-6 py-4 rounded-full shadow-lg shadow-emerald-900/50 hover:bg-emerald-500 transition-all transform hover:scale-105 flex items-center justify-center gap-2 font-bold text-sm"
                        >
                            <Plus size={24} /> Satış Faturası
                        </button>
                    </div>
                )}

                {showProfitId && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
                        <div className="bg-stone-900 border border-white/10 w-full max-w-[280px] rounded-3xl p-4 shadow-2xl animate-in zoom-in-95 duration-300">
                            <div className="flex justify-between items-center mb-4">
                                <h2 className="text-base font-black text-stone-100 flex items-center gap-2">
                                    <TrendingUp className="text-emerald-500" size={18} />
                                    Kar/Zarar
                                </h2>
                                <button onClick={() => setShowProfitId(null)} className="p-1.5 bg-stone-800 rounded-full text-stone-500 hover:text-white transition-colors">
                                    <X size={14} />
                                </button>
                            </div>

                            {(() => {
                                const p = contextPrescriptions.find(presc => presc.id === showProfitId);
                                if (!p) return null;

                                const totalSales = p.totalAmount || 0;
                                const itemsWithCost = p.items.map(item => {
                                    const qty = parseFloat(item.quantity?.toString().replace(',', '.') || '0') || 0;
                                    let cost = item.buyingPrice;
                                    if (cost === undefined) {
                                        const invItem = contextInventory.find(inv => inv.pesticideId === item.pesticideId);
                                        cost = invItem?.buyingPrice || 0;
                                    }
                                    return {
                                        ...item,
                                        qty,
                                        cost,
                                        totalCost: qty * cost,
                                        totalSale: item.totalPrice || 0
                                    };
                                });

                                const totalCost = itemsWithCost.reduce((acc, item) => acc + item.totalCost, 0);
                                const profit = totalSales - totalCost;
                                const profitMargin = totalSales > 0 ? (profit / totalSales) * 100 : 0;

                                return (
                                    <div className="space-y-4">
                                        <div className="grid grid-cols-1 gap-2">
                                            <div className="bg-stone-950 p-3 rounded-xl border border-white/5">
                                                <p className="text-[9px] font-black text-stone-500 uppercase tracking-widest mb-0.5">Satış</p>
                                                <p className="text-base font-black text-stone-100 font-mono">{formatCurrency(totalSales, userProfile?.currency || 'TRY')}</p>
                                            </div>
                                            <div className="bg-stone-950 p-3 rounded-xl border border-white/5">
                                                <p className="text-[9px] font-black text-stone-500 uppercase tracking-widest mb-0.5">Maliyet</p>
                                                <p className="text-base font-black text-stone-400 font-mono">{formatCurrency(totalCost, userProfile?.currency || 'TRY')}</p>
                                            </div>
                                            <div className={`p-3 rounded-xl border ${profit >= 0 ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-rose-500/10 border-rose-500/20'}`}>
                                                <div className="flex justify-between items-start mb-0.5">
                                                    <p className={`text-[9px] font-black uppercase tracking-widest ${profit >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                                        {profit >= 0 ? 'Net Kar' : 'Net Zarar'}
                                                    </p>
                                                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full ${profit >= 0 ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>
                                                        %{profitMargin.toFixed(1)}
                                                    </span>
                                                </div>
                                                <p className={`text-lg font-black font-mono ${profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                                    {formatCurrency(Math.abs(profit), userProfile?.currency || 'TRY')}
                                                </p>
                                            </div>
                                        </div>

                                        <div className="space-y-1.5 max-h-[150px] overflow-y-auto pr-1 no-scrollbar">
                                            {itemsWithCost.map((item, idx) => (
                                                <div key={idx} className="bg-stone-950/50 p-2 rounded-lg border border-white/5 flex justify-between items-center">
                                                    <div className="min-w-0 flex-1">
                                                        <p className="text-[9px] font-bold text-stone-300 truncate">{item.pesticideName}</p>
                                                        <p className="text-[8px] text-stone-500">{item.qty} x {formatCurrency(item.cost, userProfile?.currency || 'TRY')}</p>
                                                    </div>
                                                    <div className="text-right ml-2">
                                                        <p className={`text-[9px] font-black font-mono ${item.totalSale - item.totalCost >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                                            {formatCurrency(item.totalSale - item.totalCost, userProfile?.currency || 'TRY')}
                                                        </p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>

                                        <button 
                                            onClick={() => setShowProfitId(null)}
                                            className="w-full py-3 bg-stone-800 hover:bg-stone-700 text-white rounded-xl font-bold text-xs transition-all active:scale-95"
                                        >
                                            Kapat
                                        </button>
                                    </div>
                                );
                            })()}
                        </div>
                    </div>
                )}

                <ConfirmationModal 
                    isOpen={isDeleteModalOpen}
                    onClose={() => { setIsDeleteModalOpen(false); setPrescriptionToDelete(null); }}
                    onConfirm={confirmDelete}
                    title={`${prescriptionLabel} Silinecek`}
                    message={t('prescription.delete_confirm', { label: prescriptionLabel.toLowerCase() }) || `Bu ${prescriptionLabel.toLowerCase()}yi silmek istediğinize emin misiniz?`}
                />

                {isReportModalOpen && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-in fade-in duration-200">
                        <div className="bg-stone-900 border border-white/10 w-full max-w-sm rounded-[2rem] p-6 shadow-2xl animate-in zoom-in-95 duration-200">
                            <div className="flex justify-between items-center mb-6">
                                <h2 className="text-lg font-black text-stone-100 flex items-center gap-2">
                                    <Calendar className="text-emerald-500" size={20} />
                                    Tarih Aralığı Seçin
                                </h2>
                                <button onClick={() => setIsReportModalOpen(false)} className="p-2 bg-stone-800 rounded-full text-stone-500 hover:text-white transition-colors">
                                    <X size={16} />
                                </button>
                            </div>

                            <div className="space-y-4">
                                <div>
                                    <label className="text-[10px] font-black text-stone-500 uppercase ml-1 mb-1 block">Rapor Türü</label>
                                    <div className="flex gap-2">
                                        <button 
                                            onClick={() => setReportTypeSelection('SUMMARY')}
                                            className={`flex-1 py-3 px-2 rounded-xl text-xs font-bold transition-all border ${reportTypeSelection === 'SUMMARY' ? 'bg-emerald-600/20 border-emerald-500/50 text-emerald-400' : 'bg-stone-950 border-white/5 text-stone-400 hover:bg-stone-800'}`}
                                        >
                                            Sadece Fatura (Özet)
                                        </button>
                                        <button 
                                            onClick={() => setReportTypeSelection('DETAILED')}
                                            className={`flex-1 py-3 px-2 rounded-xl text-xs font-bold transition-all border ${reportTypeSelection === 'DETAILED' ? 'bg-emerald-600/20 border-emerald-500/50 text-emerald-400' : 'bg-stone-950 border-white/5 text-stone-400 hover:bg-stone-800'}`}
                                        >
                                            Detaylı Rapor
                                        </button>
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-3">
                                    <div>
                                        <label className="text-[10px] font-black text-stone-500 uppercase ml-1 mb-1 block">Başlangıç</label>
                                        <input 
                                            type="date" 
                                            className="w-full bg-stone-950 text-white rounded-xl p-3 border border-white/5 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none text-sm font-medium"
                                            value={reportStartDate}
                                            onChange={e => setReportStartDate(e.target.value)}
                                        />
                                    </div>
                                    <div>
                                        <label className="text-[10px] font-black text-stone-500 uppercase ml-1 mb-1 block">Bitiş</label>
                                        <input 
                                            type="date" 
                                            className="w-full bg-stone-950 text-white rounded-xl p-3 border border-white/5 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none text-sm font-medium"
                                            value={reportEndDate}
                                            onChange={e => setReportEndDate(e.target.value)}
                                        />
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <button 
                                        className="flex-1 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg text-[10px] font-bold transition-colors"
                                        onClick={() => {
                                            const today = new Date();
                                            setReportStartDate(format(new Date(today.getFullYear(), today.getMonth(), 1), 'yyyy-MM-dd'));
                                            setReportEndDate(format(today, 'yyyy-MM-dd'));
                                        }}
                                    >
                                        Bu Ay
                                    </button>
                                    <button 
                                        className="flex-1 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg text-[10px] font-bold transition-colors"
                                        onClick={() => {
                                            const today = new Date();
                                            setReportStartDate(format(new Date(today.getFullYear(), 0, 1), 'yyyy-MM-dd'));
                                            setReportEndDate(format(today, 'yyyy-MM-dd'));
                                        }}
                                    >
                                        Bu Yıl
                                    </button>
                                    <button 
                                        className="flex-1 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg text-[10px] font-bold transition-colors"
                                        onClick={() => {
                                            setReportStartDate('2020-01-01');
                                            setReportEndDate(format(new Date(), 'yyyy-MM-dd'));
                                        }}
                                    >
                                        Tümü
                                    </button>
                                </div>
                                <button 
                                    onClick={generatePrescriptionReportPDF}
                                    disabled={isGeneratingReport}
                                    className="w-full mt-4 py-3.5 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center hover:bg-emerald-500 active:scale-95 transition-all shadow-lg shadow-emerald-900/20 disabled:opacity-50"
                                >
                                    {isGeneratingReport ? (
                                        <><Loader2 size={18} className="mr-2 animate-spin" /> Hazırlanıyor...</>
                                    ) : (
                                        <><Download size={18} className="mr-2" /> PDF Oluştur</>
                                    )}
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        );
    }

    if (viewMode === 'DETAIL' && detailPrescription) {
        return (
            <div className="p-4 max-w-2xl mx-auto pb-24 animate-in slide-in-from-right duration-200 min-h-[80vh]">
                <div className="flex items-center justify-between mb-6">
                    <button onClick={() => { setDetailPrescription(null); changeViewMode('LIST'); }} className="text-stone-400 hover:text-stone-200 flex items-center px-2 py-1 rounded-lg hover:bg-stone-900 transition-colors">
                        <ArrowLeft size={20} className="mr-1" /> Listeye Dön
                    </button>
                    <div className="flex space-x-2">
                        <div className="flex items-center space-x-1 bg-stone-900 rounded-full border border-white/10 p-1">
                            <button 
                                type="button"
                                onClick={(e) => toggleProcessed(e, detailPrescription)}
                                className={`px-4 py-1.5 rounded-full text-[10px] font-bold transition-all flex items-center gap-2 ${
                                    detailPrescription.isProcessed 
                                    ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30' 
                                    : 'bg-rose-600/20 text-rose-400 border border-rose-500/30'
                                }`}
                            >
                                {detailPrescription.isProcessed ? <Check size={14} /> : <X size={14} />}
                                {detailPrescription.isProcessed ? t('prescription.processed') : t('prescription.unprocessed')}
                            </button>
                        </div>
                        <button 
                            onClick={() => setShowProfitId(detailPrescription.id)} 
                            className="p-2 bg-stone-800 text-emerald-400 rounded-full border border-white/5 hover:bg-stone-700 transition-all"
                            title="Kar/Zarar Analizi"
                        >
                            <TrendingUp size={18} />
                        </button>
                        {canEditPrescription && (
                            <button 
                                onClick={(e) => handleEdit(e, detailPrescription)} 
                                className="p-2 bg-stone-800 text-stone-300 rounded-full border border-white/5 hover:bg-stone-700 hover:text-emerald-400 transition-all"
                                title="Düzenle"
                            >
                                <Edit2 size={18} />
                            </button>
                        )}
                        {canEditPrescription && (
                            <button 
                                onClick={(e) => handleDelete(e, detailPrescription.id)}
                                className="p-2 bg-stone-800 text-stone-300 rounded-full border border-white/5 hover:bg-red-900/40 hover:text-red-400 transition-all"
                                title="Sil"
                            >
                                <Trash2 size={18} />
                            </button>
                        )}
                    </div>
                </div>

                {/* Receipt View Reuse */}
                <div className="relative mb-8 drop-shadow-[0_10px_20px_rgba(0,0,0,0.1)]">
                    {/* Main Receipt Body */}
                    <div ref={receiptRef} className="bg-[#fdfdfc] px-8 pt-10 pb-6 rounded-t-xl text-left relative overflow-hidden text-stone-800">
                        {/* Subtle noise/texture overlay for paper effect */}
                        <div className="absolute inset-0 opacity-[0.03] pointer-events-none mix-blend-multiply" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.85%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}></div>

                        {/* Top Thermal Edge Band */}
                        <div className={`absolute top-0 left-0 w-full h-1.5 ${detailPrescription.type === 'RETURN' ? 'bg-amber-500' : 'bg-stone-800'}`}></div>

                        <div className="flex justify-between mb-8 relative z-10">
                            <div>
                                <h3 className="font-bold text-2xl text-stone-900 tracking-tight">
                                    {detailPrescription.type === 'RETURN' ? 'Zirai İade Faturası' : 'Zirai Satış Faturası'}
                                </h3>
                                <div className="mt-2 inline-flex items-center gap-1.5 bg-stone-900 text-white font-mono text-xs font-black px-3 py-1 rounded-md tracking-wider shadow-xs">
                                    FATURA NO: {detailPrescription.prescriptionNo}
                                </div>
                                <p className="text-[10px] text-stone-500 font-bold mt-1.5 flex items-center">
                                    <User size={10} className="mr-1" />
                                    {detailPrescription.createdById ? (teamMembers.find(m => m.id === detailPrescription.createdById)?.fullName || 'Yönetici') : 'Yönetici'}
                                </p>
                                {(() => {
                                    const fIds = detailPrescription.fieldIds || (detailPrescription.fieldId ? [detailPrescription.fieldId] : []);
                                    if (fIds.length === 0) return null;
                                    const fieldNames = fIds.map(id => selectedFarmer?.fields?.find(f => f.id === id)?.name).filter(Boolean);
                                    if (fieldNames.length === 0) return null;
                                    return (
                                        <p className="text-[10px] text-emerald-600 font-bold mt-1">
                                            {fieldNames.length > 1 ? 'Araziler: ' : 'Arazi: '}{fieldNames.join(', ')}
                                        </p>
                                    );
                                })()}
                            </div>
                            <div className="text-right">
                                <p className="font-bold text-emerald-700 text-xl">{selectedFarmer?.fullName}</p>
                                <p className="text-xs text-stone-500">{selectedFarmer?.village}</p>
                                <p className="text-[10px] text-stone-400 mt-1">{new Date(detailPrescription.date).toLocaleDateString('tr-TR', { dateStyle: 'long' })}</p>
                                {detailPrescription.priceType === 'TERM' && (
                                    <div className="mt-2">
                                        <span className="text-[9px] font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full uppercase tracking-tighter">
                                            Vade: {detailPrescription.dueDate ? new Date(detailPrescription.dueDate).toLocaleDateString('tr-TR') : 'Belirtilmedi'}
                                        </span>
                                    </div>
                                )}
                            </div>
                        </div>
                        
                        <div className="min-h-[250px] relative z-10">
                            {detailPrescription.totalAmount !== undefined && detailPrescription.totalAmount !== null && Math.abs(detailPrescription.totalAmount) > 0 ? (
                                <table className="w-full text-sm">
                                    <thead className="bg-stone-200 text-stone-900 uppercase text-[10px] font-black tracking-wider border-b-2 border-stone-300">
                                        <tr>
                                            <th className="py-2.5 px-2 text-left w-[40%]">Ürün Adı</th>
                                            <th className="py-2.5 px-2 text-center w-[18%]">Adet</th>
                                            <th className="py-2.5 px-2 text-right w-[20%]">Birim Fiyat</th>
                                            <th className="py-2.5 px-2 text-right w-[22%]">Toplam</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-stone-200">
                                        {detailPrescription.items.map((item, idx) => (
                                            <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-stone-50/50'}>
                                                <td className="py-3 px-2">
                                                    <div className="font-black text-stone-900 text-sm">{item.pesticideName}</div>
                                                    <div className="text-[10px] text-stone-500 font-mono mt-0.5">Doz: {item.dosage}</div>
                                                </td>
                                                <td className="py-3 px-2 text-center">
                                                    <span className="inline-block bg-amber-100 text-amber-950 font-black font-mono text-sm px-2.5 py-1 rounded-md border border-amber-300/80 shadow-2xs">
                                                        {item.quantity ? item.quantity.toString().replace(/^-/, '') : '-'}
                                                    </span>
                                                </td>
                                                <td className="py-3 px-2 text-right font-mono font-bold text-stone-800 text-sm">
                                                    {item.unitPrice ? formatCurrency(item.unitPrice, userProfile?.currency || 'TRY') : '-'}
                                                </td>
                                                <td className="py-3 px-2 text-right font-mono font-black text-stone-950 text-base">
                                                    {item.totalPrice ? formatCurrency(Math.abs(item.totalPrice), userProfile?.currency || 'TRY') : '-'}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                    <tfoot>
                                        {detailPrescription.discountAmount && detailPrescription.discountAmount > 0 && (
                                            <tr>
                                                <td colSpan={4} className="pt-4 pb-2">
                                                    <div className="border-t-2 border-dashed border-stone-300 pt-4 flex justify-between items-center text-stone-500">
                                                        <span className="font-bold uppercase text-[10px] tracking-widest">
                                                            Ara Toplam
                                                        </span>
                                                        <span className="font-black font-mono text-lg tracking-tight line-through">
                                                            {formatCurrency(Math.abs((detailPrescription.totalAmount || 0) + (detailPrescription.discountAmount || 0)), userProfile?.currency || 'TRY')}
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                        )}
                                        {detailPrescription.discountAmount && detailPrescription.discountAmount > 0 && (
                                            <tr>
                                                <td colSpan={4} className="pb-4">
                                                    <div className="flex justify-between items-center text-rose-500">
                                                        <span className="font-bold uppercase text-[10px] tracking-widest">
                                                            İskonto (İndirim)
                                                        </span>
                                                        <span className="font-black font-mono text-lg tracking-tight">
                                                            -{formatCurrency(Math.abs(detailPrescription.discountAmount || 0), userProfile?.currency || 'TRY')}
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                        )}
                                        <tr>
                                            <td colSpan={4} className={detailPrescription.discountAmount && detailPrescription.discountAmount > 0 ? "pt-2" : "pt-4"}>
                                                <div className={`${detailPrescription.discountAmount && detailPrescription.discountAmount > 0 ? 'border-t border-stone-200' : 'border-t-2 border-dashed border-stone-300'} pt-4 flex justify-between items-center`}>
                                                    <span className={`font-bold uppercase text-[10px] tracking-widest ${detailPrescription.discountAmount && detailPrescription.discountAmount > 0 ? 'text-emerald-700' : 'text-stone-400'}`}>
                                                        {detailPrescription.discountAmount && detailPrescription.discountAmount > 0 ? 'İNDİRİMLİ TUTAR' : (detailPrescription.priceType === 'CASH' ? 'PEŞİN ' : 'VADELİ ') + (detailPrescription.type === 'RETURN' ? 'İADE TOPLAMI' : 'SATIŞ TOPLAMI')}
                                                    </span>
                                                    <span className={`font-black font-mono text-2xl tracking-tight ${detailPrescription.discountAmount && detailPrescription.discountAmount > 0 ? 'text-emerald-700' : 'text-emerald-600'}`}>
                                                        {formatCurrency(Math.abs(detailPrescription.totalAmount || 0), userProfile?.currency || 'TRY')}
                                                    </span>
                                                </div>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            ) : (
                                <table className="w-full text-sm">
                                    <thead className="text-stone-400 uppercase text-[9px] font-black tracking-widest border-b-2 border-stone-200">
                                        <tr>
                                            <th className="pb-3 text-left">Ürün / İlaç Adı</th>
                                            <th className="pb-3 text-right">Uygulama Dozajı</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-stone-100">
                                        {detailPrescription.items.map((item, idx) => (
                                            <tr key={idx} className="group">
                                                <td className="py-4 font-bold text-stone-800">
                                                    {item.pesticideName}
                                                    {item.quantity && (
                                                        <span className="ml-2 text-stone-500 font-bold text-xs bg-stone-100 px-2 py-0.5 rounded-full">
                                                            {item.quantity.toString().replace(/^-/, '')} Adet
                                                        </span>
                                                    )}
                                                </td>
                                                <td className="py-4 text-right font-mono font-bold text-emerald-600">{item.dosage}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            )}
                        </div>

                        <div className="mt-8 pt-4 flex justify-between items-end relative z-10 border-t border-stone-200">
                            <div className="text-[10px] text-stone-400/80 font-mono leading-relaxed">
                                Bu belge Mühendis Kayıt Sistemi<br/>
                                tarafından oluşturulmuştur.<br/>
                                <strong>v3.1.2</strong>
                            </div>
                            <div className="text-right flex flex-col items-end">
                                <RealisticStamp 
                                    profile={userProfile} 
                                    engineerName={detailPrescription.engineerName} 
                                    size="sm"
                                />
                            </div>
                        </div>
                    </div>
                    {/* Jagged / Perforated Bottom Edge */}
                    <div className="w-full h-3 overflow-hidden block z-10 relative -mt-[1px]">
                        <svg viewBox="0 0 1200 30" preserveAspectRatio="none" className="w-full h-full block" style={{ fill: '#fdfdfc' }}>
                            <path d="M0,0 L0,15 L15,30 L30,15 L45,30 L60,15 L75,30 L90,15 L105,30 L120,15 L135,30 L150,15 L165,30 L180,15 L195,30 L210,15 L225,30 L240,15 L255,30 L270,15 L285,30 L300,15 L315,30 L330,15 L345,30 L360,15 L375,30 L390,15 L405,30 L420,15 L435,30 L450,15 L465,30 L480,15 L495,30 L510,15 L525,30 L540,15 L555,30 L570,15 L585,30 L600,15 L615,30 L630,15 L645,30 L660,15 L675,30 L690,15 L705,30 L720,15 L735,30 L750,15 L765,30 L780,15 L795,30 L810,15 L825,30 L840,15 L855,30 L870,15 L885,30 L900,15 L915,30 L930,15 L945,30 L960,15 L975,30 L990,15 L1005,30 L1020,15 L1035,30 L1050,15 L1065,30 L1080,15 L1095,30 L1110,15 L1125,30 L1140,15 L1155,30 L1170,15 L1185,30 L1200,15 L1200,0 Z"></path>
                        </svg>
                    </div>
                </div>

                {/* SPLIT ACTION BUTTONS */}
                <div className="flex gap-2">
                    <button 
                        onClick={() => handlePdfAction('SHARE', detailPrescription, selectedFarmer || undefined)} 
                        disabled={isProcessingPdf}
                        className="flex-1 py-4 rounded-2xl bg-emerald-600 text-white font-black text-sm shadow-xl shadow-emerald-900/30 hover:bg-emerald-500 flex items-center justify-center disabled:opacity-70 active:scale-95 transition-all"
                    >
                        {isProcessingPdf ? <Loader2 size={20} className="mr-2 animate-spin"/> : <Share2 size={20} className="mr-2"/>}
                        WhatsApp PDF
                    </button>
                    
                    <button 
                        onClick={() => selectedFarmer && handleWhatsAppText(detailPrescription, selectedFarmer)}
                        className="flex-1 py-4 rounded-2xl bg-[#25D366] text-white font-black text-sm shadow-xl hover:bg-[#20bd5a] flex items-center justify-center active:scale-95 transition-all"
                    >
                        <MessageCircle size={20} className="mr-2"/>
                        WP Özet
                    </button>

                    <button 
                        onClick={() => handlePdfAction('DOWNLOAD', detailPrescription, selectedFarmer || undefined)} 
                        disabled={isProcessingPdf}
                        className="px-6 py-4 rounded-2xl bg-stone-800 text-stone-300 font-black text-sm border border-white/5 hover:bg-stone-700 flex items-center justify-center disabled:opacity-70 active:scale-95 transition-all"
                    >
                        {isProcessingPdf ? <Loader2 size={20} className="animate-spin"/> : <Download size={20} />}
                    </button>
                </div>

                <ConfirmationModal 
                    isOpen={isDeleteModalOpen}
                    onClose={() => { setIsDeleteModalOpen(false); setPrescriptionToDelete(null); }}
                    onConfirm={confirmDelete}
                    title={`${prescriptionLabel} Silinecek`}
                    message={t('prescription.delete_confirm', { label: prescriptionLabel.toLowerCase() }) || `Bu ${prescriptionLabel.toLowerCase()}yi silmek istediğinize emin misiniz?`}
                />

                {showProfitId && (
                    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
                        <div className="bg-stone-900 border border-white/10 w-full max-w-[280px] rounded-3xl p-4 shadow-2xl animate-in zoom-in-95 duration-300">
                            <div className="flex justify-between items-center mb-4">
                                <h2 className="text-base font-black text-stone-100 flex items-center gap-2">
                                    <TrendingUp className="text-emerald-500" size={18} />
                                    Kar/Zarar
                                </h2>
                                <button onClick={() => setShowProfitId(null)} className="p-1.5 bg-stone-800 rounded-full text-stone-500 hover:text-white transition-colors">
                                    <X size={14} />
                                </button>
                            </div>

                            {(() => {
                                const p = contextPrescriptions.find(presc => presc.id === showProfitId);
                                if (!p) return null;

                                const totalSales = p.totalAmount || 0;
                                const itemsWithCost = p.items.map(item => {
                                    const qty = parseFloat(item.quantity?.toString().replace(',', '.') || '0') || 0;
                                    let cost = item.buyingPrice;
                                    if (cost === undefined) {
                                        const invItem = contextInventory.find(inv => inv.pesticideId === item.pesticideId);
                                        cost = invItem?.buyingPrice || 0;
                                    }
                                    return {
                                        ...item,
                                        qty,
                                        cost,
                                        totalCost: qty * cost,
                                        totalSale: item.totalPrice || 0
                                    };
                                });

                                const totalCost = itemsWithCost.reduce((acc, item) => acc + item.totalCost, 0);
                                const profit = totalSales - totalCost;
                                const profitMargin = totalSales > 0 ? (profit / totalSales) * 100 : 0;

                                return (
                                    <div className="space-y-4">
                                        <div className="grid grid-cols-1 gap-2">
                                            <div className="bg-stone-950 p-3 rounded-xl border border-white/5">
                                                <p className="text-[9px] font-black text-stone-500 uppercase tracking-widest mb-0.5">Satış</p>
                                                <p className="text-base font-black text-stone-100 font-mono">{formatCurrency(totalSales, userProfile?.currency || 'TRY')}</p>
                                            </div>
                                            <div className="bg-stone-950 p-3 rounded-xl border border-white/5">
                                                <p className="text-[9px] font-black text-stone-500 uppercase tracking-widest mb-0.5">Maliyet</p>
                                                <p className="text-base font-black text-stone-400 font-mono">{formatCurrency(totalCost, userProfile?.currency || 'TRY')}</p>
                                            </div>
                                            <div className={`p-3 rounded-xl border ${profit >= 0 ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-rose-500/10 border-rose-500/20'}`}>
                                                <div className="flex justify-between items-start mb-0.5">
                                                    <p className={`text-[9px] font-black uppercase tracking-widest ${profit >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                                        {profit >= 0 ? 'Net Kar' : 'Net Zarar'}
                                                    </p>
                                                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full ${profit >= 0 ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>
                                                        %{profitMargin.toFixed(1)}
                                                    </span>
                                                </div>
                                                <p className={`text-lg font-black font-mono ${profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                                    {formatCurrency(Math.abs(profit), userProfile?.currency || 'TRY')}
                                                </p>
                                            </div>
                                        </div>

                                        <div className="space-y-1.5 max-h-[150px] overflow-y-auto pr-1 no-scrollbar">
                                            {itemsWithCost.map((item, idx) => (
                                                <div key={idx} className="bg-stone-950/50 p-2 rounded-lg border border-white/5 flex justify-between items-center">
                                                    <div className="min-w-0 flex-1">
                                                        <p className="text-[9px] font-bold text-stone-300 truncate">{item.pesticideName}</p>
                                                        <p className="text-[8px] text-stone-500">{item.qty} x {formatCurrency(item.cost, userProfile?.currency || 'TRY')}</p>
                                                    </div>
                                                    <div className="text-right ml-2">
                                                        <p className={`text-[9px] font-black font-mono ${item.totalSale - item.totalCost >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                                            {formatCurrency(item.totalSale - item.totalCost, userProfile?.currency || 'TRY')}
                                                        </p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>

                                        <button 
                                            onClick={() => setShowProfitId(null)}
                                            className="w-full py-3 bg-stone-800 hover:bg-stone-700 text-white rounded-xl font-bold text-xs transition-all active:scale-95"
                                        >
                                            Kapat
                                        </button>
                                    </div>
                                );
                            })()}
                        </div>
                    </div>
                )}
            </div>
        );
    }

    return (
        <div className="p-4 max-w-3xl mx-auto pb-24 animate-in slide-in-from-right duration-200">
            <div className="flex items-center mb-6">
                 <button onClick={handleBackFromForm} className="mr-4 text-stone-400 hover:text-stone-200 flex items-center">
                    <X size={20} className="mr-1" /> İptal
                 </button>
                 <div className="flex-1 h-2 bg-stone-800 rounded-full overflow-hidden mx-4">
                     <div className={`h-full bg-emerald-600 transition-all duration-300 ${step === 1 ? 'w-1/5' : (step === 2 ? 'w-2/5' : (step === 3 ? 'w-3/5' : (step === 4 ? 'w-4/5' : 'w-full')))}`}></div>
                 </div>
                 <span className="font-bold text-emerald-500 text-sm whitespace-nowrap">Adım {step}/5</span>
            </div>

            {step === 1 && (
                <div className="pb-24">
                    <div className="flex items-center justify-center mb-4">
                        <h2 className="text-2xl font-bold text-stone-100 text-center">
                            {editingId ? `${currentPrescriptionLabel} Düzenle: ${farmerLabel}` : `${currentPrescriptionLabel} Oluştur: ${farmerLabel} Seçimi`}
                        </h2>
                    </div>
                    
                    <div className="bg-stone-900 rounded-2xl shadow-sm border border-white/5 flex items-center p-1 mb-4">
                        <Search className="text-stone-500 ml-3" size={18} />
                        <input 
                            type="text" 
                            placeholder={`${farmerLabel} adı veya köy ile ara...`} 
                            className="w-full p-2.5 bg-transparent outline-none font-medium text-stone-200 placeholder-stone-600 text-sm"
                            value={farmerSearchTerm}
                            onChange={e => setFarmerSearchTerm(e.target.value)}
                        />
                        {farmerSearchTerm && (
                            <button onClick={() => setFarmerSearchTerm('')} className="p-2 text-stone-500 hover:text-stone-300">
                                <X size={16} />
                            </button>
                        )}
                    </div>

                    <div className="space-y-4">
                        <div className="space-y-2">
                            <label className="text-[10px] font-bold text-stone-500 uppercase tracking-widest ml-1 text-center block w-full">{farmerLabel} Listesi</label>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[450px] overflow-y-auto pr-2 no-scrollbar">
                                {filteredFarmers.map(f => (
                                    <button 
                                        key={f.id} 
                                        onClick={() => { setSelectedFarmer(f); setSelectedFieldId(''); changeStep(2); }}
                                        className={`w-full text-left p-4 rounded-2xl border flex justify-between items-center group transition-all ${
                                            selectedFarmer?.id === f.id
                                            ? 'bg-emerald-900/20 border-emerald-500 shadow-lg shadow-emerald-900/10'
                                            : 'bg-stone-900 border-white/5 hover:border-emerald-500/50 hover:bg-stone-800/50'
                                        }`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${selectedFarmer?.id === f.id ? 'bg-emerald-600 text-white' : 'bg-stone-800 text-stone-500 group-hover:bg-emerald-900/30 group-hover:text-emerald-500'}`}>
                                                <User size={18} />
                                            </div>
                                            <div>
                                                <span className="font-bold text-stone-100 block text-sm group-hover:text-emerald-400">{f.fullName}</span>
                                                <span className="text-[10px] text-stone-500 flex items-center mt-1"><MapPin size={10} className="mr-1"/> {f.village}</span>
                                            </div>
                                        </div>
                                        <ChevronRight size={18} className={`${selectedFarmer?.id === f.id ? 'text-emerald-500' : 'text-stone-700'}`} />
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {step === 2 && (
                <div className="pb-24 slide-in-from-right animate-in">
                    <div className="flex flex-col items-center justify-center mb-6 text-center">
                        <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2 border border-emerald-500/20">
                            <Sprout size={26} />
                        </div>
                        <h2 className="text-2xl font-black text-stone-100">
                            {selectedFarmer?.fullName}
                        </h2>
                        <div className="flex items-center gap-1.5 mt-1">
                            <span className="text-[11px] font-black uppercase tracking-wider text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                                Zorunlu Alan: Mahsul (Ürün) Seçimi
                            </span>
                        </div>
                        <p className="text-xs text-stone-400 mt-2 max-w-md">
                            Satışı yapılan mahsulü seçiniz. Bu seçim, cari hesap raporunda <strong>ürün bazlı filtreleme</strong> ve <strong>ürün bazlı ödeme</strong> takibini kusursuz yapmanızı sağlar.
                        </p>
                    </div>

                    <div className="space-y-5 max-w-xl mx-auto">
                        {!selectedFarmer ? (
                            <div className="p-12 border-2 border-dashed border-stone-800 rounded-3xl text-center text-stone-600 flex flex-col items-center gap-3">
                                <User size={40} className="opacity-20" />
                                <p className="text-sm font-medium">Lütfen önce çiftçi seçiniz</p>
                                <button onClick={() => changeStep(1)} className="text-emerald-500 text-xs font-bold underline">Geri Dön</button>
                            </div>
                        ) : (
                            <>
                                {/* Selected Crop Active Badge */}
                                {selectedCrop ? (
                                    <div className="bg-emerald-950/40 border-2 border-emerald-500 rounded-2xl p-4 flex items-center justify-between shadow-lg shadow-emerald-950/40 animate-in zoom-in-95">
                                        <div className="flex items-center gap-3">
                                            <div className="w-12 h-12 rounded-xl bg-emerald-500 text-stone-950 flex items-center justify-center font-black shadow-md">
                                                <Check size={24} strokeWidth={3} />
                                            </div>
                                            <div>
                                                <p className="text-[10px] font-black uppercase tracking-widest text-emerald-400">Seçilen Satış Mahsulü</p>
                                                <h3 className="text-xl font-black text-white">{selectedCrop}</h3>
                                            </div>
                                        </div>
                                        <button
                                            type="button"
                                            onClick={() => setSelectedCrop('')}
                                            className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-rose-400 border border-white/5 rounded-xl text-xs font-bold transition-all active:scale-95"
                                        >
                                            Değiştir
                                        </button>
                                    </div>
                                ) : (
                                    <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-3.5 flex items-center gap-3">
                                        <AlertCircle size={20} className="text-amber-400 shrink-0" />
                                        <p className="text-xs font-medium text-amber-300">
                                            Devam etmek için aşağıdaki listeden veya aramadan satışı yapılan mahsulü seçiniz.
                                        </p>
                                    </div>
                                )}

                                {/* Search & Custom Crop Input */}
                                <div className="bg-stone-900 rounded-2xl shadow-sm border border-white/5 flex items-center p-1.5">
                                    <Search className="text-stone-500 ml-3" size={18} />
                                    <input 
                                        type="text" 
                                        placeholder="Mahsul veya ürün ara (örn: Pamuk, Buğday, Domates)..." 
                                        className="w-full p-2.5 bg-transparent outline-none font-medium text-stone-200 placeholder-stone-600 text-sm"
                                        value={cropSearchTerm}
                                        onChange={e => setCropSearchTerm(e.target.value)}
                                    />
                                    {cropSearchTerm && (
                                        <button 
                                            onClick={() => setCropSearchTerm('')} 
                                            className="p-2 text-stone-500 hover:text-stone-300"
                                        >
                                            <X size={16} />
                                        </button>
                                    )}
                                </div>

                                {/* Custom Crop Button if searched name is not in list */}
                                {cropSearchTerm.trim() && (
                                    <button
                                        type="button"
                                        onClick={() => {
                                            const val = cropSearchTerm.trim();
                                            setSelectedCrop(val);
                                            const match = contextPlants.find(p => p.name.toLowerCase() === val.toLowerCase());
                                            if (match) setSelectedPlantId(match.id);
                                            setCropSearchTerm('');
                                            hapticFeedback('medium');
                                        }}
                                        className="w-full p-3 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95"
                                    >
                                        <Plus size={16} />
                                        <span>&ldquo;{cropSearchTerm.trim()}&rdquo; olarak seç</span>
                                    </button>
                                )}

                                {/* Farmer's existing crops (if any) */}
                                {farmerCrops.length > 0 && !cropSearchTerm && (
                                    <div>
                                        <label className="text-[10px] font-black text-emerald-400 uppercase tracking-widest block mb-2">
                                            Çiftçinin Mevcut Mahsulleri
                                        </label>
                                        <div className="grid grid-cols-2 gap-2">
                                            {farmerCrops.map((crop: string) => (
                                                <button
                                                    key={`farmer-crop-${crop}`}
                                                    type="button"
                                                    onClick={() => {
                                                        setSelectedCrop(crop);
                                                        const match = contextPlants.find(p => p.name.toLowerCase() === crop.toLowerCase());
                                                        if (match) setSelectedPlantId(match.id);
                                                        hapticFeedback('light');
                                                    }}
                                                    className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all active:scale-95 ${
                                                        selectedCrop === crop
                                                            ? 'bg-emerald-900/30 border-emerald-500 text-white shadow-md'
                                                            : 'bg-stone-900/80 border-white/5 text-stone-300 hover:border-emerald-500/30 hover:bg-stone-800'
                                                    }`}
                                                >
                                                    <div className="flex items-center gap-2.5">
                                                        <Wheat size={18} className="text-amber-400" />
                                                        <span className="font-bold text-sm">{crop}</span>
                                                    </div>
                                                    {selectedCrop === crop && <Check size={16} className="text-emerald-400" />}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {/* All Crop Badges / Grid */}
                                <div>
                                    <div className="flex items-center justify-between mb-2">
                                        <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest">
                                            Tüm Mahsul & Ürün Listesi
                                        </label>
                                        <span className="text-[10px] text-stone-500 font-medium">
                                            {filteredCropsList.length} Ürün
                                        </span>
                                    </div>

                                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-[340px] overflow-y-auto pr-1 no-scrollbar">
                                        {filteredCropsList.map((crop: string) => {
                                            const isSelected = selectedCrop === crop;
                                            return (
                                                <button
                                                    key={crop}
                                                    type="button"
                                                    onClick={() => {
                                                        setSelectedCrop(crop);
                                                        const match = contextPlants.find(p => p.name.toLowerCase() === crop.toLowerCase());
                                                        if (match) setSelectedPlantId(match.id);
                                                        hapticFeedback('light');
                                                    }}
                                                    className={`p-3 rounded-2xl border text-left flex items-center justify-between transition-all active:scale-95 ${
                                                        isSelected
                                                            ? 'bg-emerald-500 text-stone-950 border-emerald-400 shadow-lg shadow-emerald-950 font-black'
                                                            : 'bg-stone-900 border-white/5 text-stone-300 hover:border-white/20 hover:bg-stone-800'
                                                    }`}
                                                >
                                                    <span className="text-xs truncate">{crop}</span>
                                                    {isSelected ? (
                                                        <Check size={16} strokeWidth={3} className="shrink-0 ml-1 text-stone-950" />
                                                    ) : (
                                                        <Sprout size={14} className="shrink-0 ml-1 text-stone-600" />
                                                    )}
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                    
                    <div className="fixed bottom-20 left-0 w-full p-4 md:static md:p-0 md:mt-12 z-30 bg-gradient-to-t from-stone-950 via-stone-950 to-transparent pb-6">
                        <div className="max-w-xl mx-auto flex gap-3">
                            <button 
                                onClick={() => changeStep(1)} 
                                className="flex-1 py-4 bg-stone-900 text-stone-400 rounded-2xl font-bold flex items-center justify-center transition-all border border-white/5 hover:text-white"
                            >
                                <ArrowLeft size={20} className="mr-2"/> Çiftçi Seçimi
                            </button>
                            <button 
                                disabled={!selectedCrop || !selectedCrop.trim()}
                                onClick={() => changeStep(3)} 
                                className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl font-bold flex items-center justify-center shadow-lg shadow-emerald-500/20 disabled:opacity-30 disabled:grayscale active:scale-95 transition-all border border-emerald-500/20"
                            >
                                {selectedCrop ? (
                                    <>
                                        <span>İlaç Seçimine Geç ({selectedCrop})</span>
                                        <ChevronRight size={20} className="ml-2"/>
                                    </>
                                ) : (
                                    <span>Lütfen Mahsul Seçiniz (Zorunlu)</span>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {step === 3 && (
                <div className="pb-24">
                    <h2 className="text-2xl font-bold mb-4 text-stone-100 text-center">
                        {editingId ? `${currentPrescriptionLabel} Düzenle: İlaçlar` : 'İlaç Seç'}
                    </h2>

                    <div className="mb-6 flex gap-2">
                        <button
                            onClick={() => setIsScanning(true)}
                            className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-stone-950 font-black rounded-xl p-3 flex flex-col items-center justify-center gap-2 shadow-lg shadow-emerald-900/20 active:scale-95 transition-all group"
                        >
                            <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-950 group-hover:scale-110 transition-transform">
                                <Barcode size={24} />
                            </div>
                            <span>Kamerayla Hızlı Ekle (POS)</span>
                        </button>
                    </div>
                    
                    <div className="bg-stone-900 rounded-2xl shadow-sm border border-white/5 flex items-center p-1 mb-6">
                        <Search className="text-stone-500 ml-3" size={18} />
                        <input 
                            type="text" 
                            placeholder="İlaç adı veya etken madde ara..." 
                            className="w-full p-2.5 bg-transparent outline-none font-medium text-stone-200 placeholder-stone-600 text-sm"
                            value={pesticideSearchTerm}
                            onChange={e => setPesticideSearchTerm(e.target.value)}
                        />
                        <button 
                            onClick={() => setShowRecommendations(true)}
                            className={`p-2.5 rounded-xl ml-1 transition-colors relative mr-1 hover:scale-105 active:scale-95 ${recommendedIds.length > 0 ? 'bg-amber-500/20 text-amber-500 border border-amber-500/30' : 'bg-stone-800 text-stone-300 hover:bg-stone-700'}`}
                            title="Ürün Tavsiyeleri"
                        >
                            <Lightbulb size={18} />
                            {recommendedIds.length > 0 && (
                                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-500 rounded-full border border-stone-900"></span>
                            )}
                        </button>
                        <button 
                            onClick={() => setIsScanning(true)}
                            className="p-2.5 bg-stone-800 text-stone-300 rounded-xl mr-1 hover:bg-stone-700 transition-colors"
                            title="Barkod Okut"
                        >
                            <Barcode size={18} />
                        </button>
                        {pesticideSearchTerm && (
                            <button onClick={() => setPesticideSearchTerm('')} className="p-2 text-stone-500 hover:text-stone-300">
                                <X size={16} />
                            </button>
                        )}
                    </div>

                    <div className="mb-8">
                        <label className="text-xs font-bold text-stone-500 mb-3 block uppercase tracking-widest">Depodan Seç</label>
                        <div className="grid grid-cols-1 gap-2 max-h-[300px] overflow-y-auto pr-2 no-scrollbar">
                            {filteredInventoryItems.length > 0 ? (
                                filteredInventoryItems.map(inv => {
                                    const p = pesticides.find(pest => pest.id === inv.pesticideId) || {
                                        id: inv.pesticideId,
                                        name: inv.pesticideName,
                                        activeIngredient: 'Bilinmiyor',
                                        defaultDosage: '100ml/100L',
                                        category: inv.category,
                                        description: 'Depo ürünü'
                                    } as Pesticide;
                                    
                                    const isSelected = selectedItems.some(i => i.pesticide.id === p.id);
                                    return (
                                        <div 
                                            key={inv.id}
                                            className={`w-full text-left p-2.5 rounded-xl border transition-all flex justify-between items-center ${
                                                isSelected 
                                                ? 'bg-stone-800/50 border-emerald-900/30' 
                                                : 'bg-stone-900 border-white/5 hover:border-emerald-500/30 hover:bg-stone-800'
                                            }`}
                                        >
                                            <div 
                                                className="flex items-center space-x-3 flex-1 min-w-0 cursor-pointer"
                                                onClick={() => !isSelected && addItem(p)}
                                            >
                                                <div className="p-2 bg-stone-800 rounded-lg text-stone-400 group-hover:text-emerald-400 shrink-0">
                                                    <Package size={16} />
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <span className={`font-bold block text-sm truncate ${isSelected ? 'text-stone-500' : 'text-stone-200'}`}>{inv.pesticideName}</span>
                                                    <span className="text-[10px] text-stone-500 font-mono block truncate">Stok: {inv.quantity} {inv.unit} | Fiyat: {formatCurrency(inv.sellingPrice, userProfile?.currency || 'TRY')}</span>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-1 shrink-0 ml-2">
                                                <button
                                                    onClick={(e) => toggleRecommendation(p.id, e)}
                                                    className={`p-2.5 rounded-lg transition-colors active:scale-90 ${recommendedIds.includes(p.id) ? 'text-amber-500 bg-amber-500/10 hover:bg-amber-500/20' : 'text-stone-600 hover:text-amber-400 hover:bg-stone-700/50'}`}
                                                    title={recommendedIds.includes(p.id) ? "Tavsiyelerden Çıkar" : "Tavsiyelere Ekle"}
                                                >
                                                    <Star size={18} fill={recommendedIds.includes(p.id) ? "currentColor" : "none"} />
                                                </button>
                                                <button
                                                    onClick={() => !isSelected && addItem(p)}
                                                    disabled={isSelected}
                                                    className={`p-2.5 rounded-lg transition-colors min-w-[44px] flex items-center justify-center ${isSelected ? 'text-emerald-500 bg-emerald-500/10 opacity-50 cursor-not-allowed' : 'text-stone-200 bg-stone-800 hover:bg-emerald-600'}`}
                                                >
                                                    {isSelected ? <Check size={18} /> : <Plus size={18} />}
                                                </button>
                                            </div>
                                        </div>
                                    );
                                })
                            ) : (
                                <div className="text-center py-6 text-stone-600 border border-dashed border-stone-800 rounded-xl">
                                    <p className="text-xs">Depoda uygun ilaç bulunamadı.</p>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="fixed bottom-20 left-0 w-full p-4 md:static md:p-0 md:mt-8 z-30 bg-gradient-to-t from-stone-950 via-stone-950 to-transparent pb-6">
                        <div className="max-w-3xl mx-auto">
                             {selectedItems.length > 0 && (
                                 <div className="mb-4 bg-stone-900/80 backdrop-blur-md border border-white/5 rounded-xl p-2 overflow-x-auto no-scrollbar flex items-center gap-2 animate-in slide-in-from-bottom-4 duration-300">
                                     <span className="text-[8px] font-black text-stone-500 uppercase tracking-widest ml-1 shrink-0">Seçilenler:</span>
                                     {selectedItems.map((item, i) => (
                                         <div key={i} className="bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-2 py-1 rounded-lg border border-emerald-500/20 whitespace-nowrap flex items-center gap-1">
                                             {item.pesticide.name}
                                             <button onClick={() => removeItem(item.pesticide.id)} className="hover:text-rose-400"><X size={10} /></button>
                                             <button onClick={() => setIsScanning(true)} className="hover:text-emerald-400"><Barcode size={10} /></button>
                                         </div>
                                     ))}
                                 </div>
                             )}
                             <button 
                                disabled={selectedItems.length === 0}
                                onClick={() => changeStep(4)}
                                className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-emerald-900/40 disabled:opacity-50 hover:bg-emerald-700 active:scale-95 transition-all flex items-center justify-center border border-emerald-500/20"
                             >
                                İlaç Detaylarını Gir <Check size={20} className="ml-2" />
                             </button>
                        </div>
                    </div>

                    {showRecommendations && (
                        <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-4">
                            <div className="absolute inset-0 bg-stone-950/80 backdrop-blur-sm" onClick={() => setShowRecommendations(false)}></div>
                            <div className="bg-stone-900 border border-stone-800 w-full max-w-md rounded-3xl shadow-2xl relative z-10 overflow-hidden animate-in slide-in-from-bottom-10 sm:zoom-in-95 duration-200 flex flex-col max-h-[80vh]">
                                <div className="p-4 border-b border-stone-800 bg-amber-500/5 flex items-center justify-between shrink-0">
                                    <div className="flex items-center gap-2 text-amber-500">
                                        <Lightbulb size={20} />
                                        <h3 className="font-bold text-stone-100">Ürün Tavsiyeleri & Notlar</h3>
                                    </div>
                                    <button onClick={() => setShowRecommendations(false)} className="text-stone-400 hover:text-white p-1 rounded-full"><X size={20}/></button>
                                </div>
                                <div className="p-4 overflow-y-auto flex-1 space-y-2 no-scrollbar">
                                    {recommendedIds.length === 0 ? (
                                        <div className="text-center py-10 opacity-50 px-4">
                                            <Star size={32} className="mx-auto mb-4 text-stone-500" />
                                            <p className="text-sm text-stone-400 font-medium">Henüz notlarına eklediğin bir ürün yok.</p>
                                            <p className="text-xs text-stone-500 mt-2">Depodan seçerken yıldız (⭐) butonuna basarak unutmamak için ürün ekleyebilirsin.</p>
                                        </div>
                                    ) : (
                                        recommendedIds.map(rid => {
                                           const pInfo = pesticides.find(p => p.id === rid); 
                                           if (!pInfo) return null;
                                           const invItem = contextInventory.find(inv => inv.pesticideId === rid);
                                           const isSelected = selectedItems.some(i => i.pesticide.id === rid);

                                            return (
                                                <div key={rid} className="w-full text-left p-3 rounded-xl bg-stone-800/30 border border-stone-800 flex justify-between items-center group">
                                                    <div className="flex-1 min-w-0 pr-2">
                                                        <span className="font-bold text-stone-200 block text-sm truncate">{pInfo.name}</span>
                                                        {invItem ? (
                                                            <span className="text-[10px] text-emerald-500 font-mono block truncate">Stokta Var: {invItem.quantity} {invItem.unit}</span>
                                                        ) : (
                                                            <span className="text-[10px] text-rose-500 font-mono block truncate">Depoda Yok</span>
                                                        )}
                                                    </div>
                                                    <div className="flex items-center gap-2 shrink-0">
                                                        <button 
                                                            onClick={() => toggleRecommendation(rid)}
                                                            className="p-2 text-stone-500 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-colors"
                                                            title="Notlardan Sil"
                                                        >
                                                            <Trash2 size={16} />
                                                        </button>
                                                        {invItem && (
                                                            <button
                                                                onClick={() => {
                                                                    if (!isSelected) {
                                                                        addItem(pInfo);
                                                                    } else {
                                                                        removeItem(pInfo.id);
                                                                    }
                                                                }}
                                                                className={`px-3 py-2 rounded-lg text-xs font-bold transition-colors ${isSelected ? 'bg-rose-500/10 text-rose-500 hover:bg-rose-500/20' : 'bg-emerald-600 text-white hover:bg-emerald-500'}`}
                                                            >
                                                                {isSelected ? 'Çıkar' : 'Ekle'}
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            )
                                        })
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {step === 4 && (
                <div>
                     <h2 className="text-2xl font-bold mb-4 text-stone-100 text-center">
                        İlaç Detayları
                    </h2>
                    <div className="space-y-3 pb-40">
                        {/* Horizontal Controls Row */}
                        <div className="flex items-center gap-1.5">
                            {/* Invoice No */}
                            <div className="flex-1 flex items-center space-x-1.5 bg-stone-900 px-2 py-2 rounded-xl border border-white/5 shadow-inner">
                                <span className="text-[8px] text-stone-500 font-black uppercase tracking-tighter whitespace-nowrap">NO:</span>
                                <input 
                                    type="text" 
                                    value={customPrescriptionNo}
                                    onChange={(e) => setCustomPrescriptionNo(e.target.value)}
                                    placeholder="OTO"
                                    className="bg-transparent border-none text-[10px] text-stone-100 w-full focus:ring-0 p-0 placeholder:text-stone-700 outline-none font-black"
                                />
                            </div>

                            {/* Payment Type Toggle */}
                            <div className="flex-1 flex items-center bg-stone-900 rounded-xl border border-white/5 p-0.5">
                                <button
                                    onClick={() => handlePriceTypeChange('CASH')}
                                    className={`flex-1 py-1.5 text-[8px] font-black rounded-lg transition-all ${prescriptionPriceType === 'CASH' ? 'bg-emerald-600 text-white shadow-lg' : 'text-stone-500'}`}
                                >
                                    PEŞİN
                                </button>
                                <button
                                    onClick={() => handlePriceTypeChange('TERM')}
                                    className={`flex-1 py-1.5 text-[8px] font-black rounded-lg transition-all ${prescriptionPriceType === 'TERM' ? 'bg-stone-700 text-white shadow-lg' : 'text-stone-500'}`}
                                >
                                    VADE
                                </button>
                            </div>
                            
                             {/* Account Selection for CASH or Due Date for TERM */}
                            {prescriptionPriceType === 'CASH' ? (
                                <div className="flex-1 flex items-center space-x-1.5 bg-stone-900 px-2 py-2 rounded-xl border border-emerald-500/30 shadow-inner">
                                    <Landmark size={10} className="text-emerald-400 shrink-0" />
                                    <div className="flex-1 min-w-0">
                                        <p className="text-[7px] font-black text-emerald-400 uppercase tracking-tighter leading-none mb-0.5">HESAP / KASA</p>
                                        <select
                                            value={prescriptionAccountId || (accounts.find(a => a.type === 'CASH')?.id || accounts[0]?.id || '')}
                                            onChange={(e) => setPrescriptionAccountId(e.target.value)}
                                            className="bg-transparent border-none text-[9px] text-stone-100 font-black w-full focus:ring-0 p-0 outline-none cursor-pointer"
                                        >
                                            {accounts.map(acc => (
                                                <option key={acc.id} value={acc.id} className="bg-stone-900 text-stone-100">
                                                    {acc.name} ({new Intl.NumberFormat('tr-TR', { style: 'currency', currency: userProfile?.currency || 'TRY' }).format(acc.balance)})
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex-1 flex items-center space-x-1.5 bg-stone-900 px-2 py-2 rounded-xl border border-white/5 shadow-inner transition-all duration-300">
                                    <Calendar size={10} className="text-amber-500 shrink-0" />
                                    <div className="flex-1 min-w-0">
                                        <p className="text-[7px] font-black text-stone-500 uppercase tracking-tighter leading-none mb-0.5">VADE</p>
                                        <div className="text-[9px] text-stone-200 font-black truncate relative">
                                            <input
                                                type="date"
                                                value={prescriptionDueDate}
                                                onChange={(e) => {
                                                    setPrescriptionDueDate(e.target.value);
                                                    setIsManualDueDate(true);
                                                }}
                                                className="bg-transparent border-none text-[9px] text-stone-200 font-black w-full focus:ring-0 p-0 outline-none relative z-10"
                                                style={{ colorScheme: 'dark' }}
                                            />
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>

                        {selectedItems.map((item, idx) => (
                            <div key={idx} className="bg-stone-900/80 backdrop-blur-sm p-4 rounded-2xl shadow-xl border border-white/5 relative overflow-hidden group animate-in fade-in slide-in-from-bottom-2 duration-300">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 -mr-12 -mt-12 rounded-full blur-2xl group-hover:bg-emerald-500/10 transition-colors" />
                                
                                <div className="flex items-start justify-between gap-4 relative z-10">
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-4">
                                            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
                                            <h4 className="font-black text-stone-100 text-xs tracking-tight truncate">{item.pesticide.name}</h4>
                                        </div>

                                        <div className="grid grid-cols-2 gap-3">
                                            <div className="space-y-1.5">
                                                <label className="text-[9px] font-black text-stone-500 uppercase tracking-widest pl-1">ADET / MİKTAR</label>
                                                <div className="bg-stone-950 border border-white/5 rounded-xl overflow-hidden focus-within:border-emerald-500/40 transition-all">
                                                    <input 
                                                        type="text" 
                                                        value={item.quantity}
                                                        onChange={(e) => updateQuantity(item.pesticide.id, e.target.value)}
                                                        className="w-full p-2.5 bg-transparent font-black outline-none text-stone-200 text-xs text-center"
                                                        placeholder="0"
                                                    />
                                                </div>
                                            </div>

                                            <div className="space-y-1.5">
                                                <label className="text-[9px] font-black text-stone-500 uppercase tracking-widest pl-1">BİRİM FİYAT</label>
                                                <div className="bg-stone-950 border border-white/5 rounded-xl overflow-hidden focus-within:border-amber-500/40 transition-all">
                                                    <input 
                                                        type="text" 
                                                        value={item.unitPrice || ''}
                                                        onChange={(e) => updatePrice(item.pesticide.id, e.target.value)}
                                                        className="w-full p-2.5 bg-transparent font-black outline-none text-stone-200 text-xs text-center"
                                                        placeholder="0.00"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex flex-col items-end justify-between h-[100px]">
                                        <button 
                                            onClick={() => removeItem(item.pesticide.id)} 
                                            className="p-2.5 bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white rounded-xl transition-all active:scale-95 shadow-sm"
                                        >
                                            <Trash2 size={16}/>
                                        </button>
                                        <div className="text-right">
                                            <p className="text-[8px] font-black text-stone-500 uppercase tracking-widest leading-none mb-1">ARA TOPLAM</p>
                                            <span className="text-base font-black text-emerald-400 font-mono tracking-tighter block leading-none">
                                                {formatCurrency(item.totalPrice || 0, userProfile?.currency || 'TRY')}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                        {selectedItems.length === 0 && (
                            <div className="text-center py-12 border-2 border-dashed border-stone-800 rounded-2xl text-stone-600 bg-stone-900/20">
                                <FlaskConical size={32} className="mx-auto mb-3 opacity-20" />
                                <p className="text-sm">Hiç ilaç seçilmedi.</p>
                            </div>
                        )}
                    </div>

                    <div className="fixed bottom-20 left-0 w-full p-4 md:static md:p-0 md:mt-8 z-30 bg-gradient-to-t from-stone-950 via-stone-950 to-transparent pb-6">
                        <div className="max-w-3xl mx-auto">
                             <button 
                                disabled={selectedItems.length === 0}
                                onClick={() => changeStep(5)}
                                className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-emerald-900/40 disabled:opacity-50 hover:bg-emerald-700 active:scale-95 transition-all flex items-center justify-center border border-emerald-500/20"
                             >
                                Devam Et <Check size={20} className="ml-2" />
                             </button>
                        </div>
                    </div>
                </div>
            )}

            {step === 5 && (
                <div className="pb-24">
                    <h2 className="text-2xl font-bold mb-6 text-stone-100 text-center">Önizleme ve Onay</h2>
                    <div className="bg-stone-900 p-6 rounded-xl shadow-sm border border-white/5 mb-6">
                         <div className="flex items-center justify-between mb-4 pb-4 border-b border-white/5">
                             <div>
                                 <p className="text-sm text-stone-500">{farmerLabel}</p>
                                 <p className="font-bold text-lg text-stone-200">{selectedFarmer?.fullName}</p>
                             </div>
                             <div className="text-right">
                                 <p className="text-sm text-stone-500">Tarih</p>
                                 <p className="font-medium text-stone-300">{new Date().toLocaleDateString()}</p>
                             </div>
                         </div>
                         {selectedCrop && (
                             <div className="mb-4 flex items-center justify-between bg-emerald-500/10 border border-emerald-500/20 px-3.5 py-2.5 rounded-xl">
                                 <div className="flex items-center gap-2">
                                     <Sprout size={16} className="text-emerald-400" />
                                     <span className="text-xs text-stone-400 font-medium">Mahsul (Ürün):</span>
                                     <span className="text-xs font-black text-emerald-400">{selectedCrop}</span>
                                 </div>
                                 <span className="text-[10px] font-bold text-emerald-500/80 bg-emerald-500/20 px-2 py-0.5 rounded-md">Ürün Bazlı Takip</span>
                             </div>
                         )}
                         <div className="space-y-2">
                             {selectedItems.map((item, idx) => (
                                 <div key={idx} className="flex justify-between py-2 border-b border-white/5 last:border-0">
                                     <div>
                                         <span className="font-medium text-stone-400 block">{item.pesticide.name}</span>
                                         {item.quantity && <span className="text-xs text-stone-500 font-bold bg-stone-950 px-2 py-0.5 rounded-full inline-block mt-1">{item.quantity.toString().replace(/^-/, '')} Adet</span>}
                                     </div>
                                     <div className="text-right">
                                         <span className="font-bold text-stone-200 block">{item.dosage}</span>
                                         <div className="flex flex-col items-end mt-1">
                                             {item.totalPrice && item.totalPrice > 0 ? (
                                                 <span className="text-xs text-emerald-400 font-mono block">
                                                     {formatCurrency(item.totalPrice, userProfile?.currency || 'TRY')}
                                                 </span>
                                             ) : null}
                                         </div>
                                     </div>
                                 </div>
                             ))}
                             
                             {/* Toplam Tutar Gösterimi */}
                             {selectedItems.some(i => i.totalPrice && i.totalPrice > 0) && (() => {
                                 const initialTotal = selectedItems.reduce((acc, item) => acc + (item.totalPrice || 0), 0);
                                 const discountValue = parseFloat(prescriptionDiscount.replace(',', '.')) || 0;
                                 const finalTotal = Math.max(0, initialTotal - discountValue);

                                 return (
                                     <div className="pt-4 border-t border-white/10 mt-4 space-y-3">
                                         <div className="flex justify-between items-center">
                                             <div>
                                                 <span className="font-bold text-stone-300 block">TOPLAM TUTAR</span>
                                                 <span className={`text-[10px] font-black px-2 py-0.5 rounded-full mt-1 inline-block ${prescriptionPriceType === 'CASH' ? 'bg-emerald-900/40 text-emerald-400' : 'bg-stone-800 text-stone-500'}`}>
                                                     {prescriptionPriceType === 'CASH' ? 'PEŞİN ' : 'VADELİ '} {prescriptionType === 'RETURN' ? 'İADE' : 'SATIŞ'}
                                                 </span>
                                             </div>
                                             <span className={`font-bold font-mono ${discountValue > 0 ? 'text-stone-500 text-sm line-through' : 'text-emerald-400 text-lg'}`}>
                                                 {formatCurrency(initialTotal, userProfile?.currency || 'TRY')}
                                             </span>
                                         </div>
                                         
                                         <div className="flex justify-between items-center bg-stone-950 p-3 rounded-xl border border-stone-800">
                                             <span className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">İskonto Tutarı Gir</span>
                                             <input
                                                type="number"
                                                value={prescriptionDiscount}
                                                onChange={(e) => setPrescriptionDiscount(e.target.value)}
                                                className="w-28 bg-stone-900 border border-stone-800 rounded-lg p-2 text-right font-mono font-bold text-rose-400 outline-none focus:border-rose-500 transition-colors"
                                                placeholder="0.00"
                                             />
                                         </div>

                                         {discountValue > 0 && (
                                            <div className="flex justify-between items-center pt-2">
                                                 <span className="font-black text-emerald-400 block text-lg tracking-tight">İNDİRİMLİ TUTAR</span>
                                                 <span className="font-black text-emerald-400 text-2xl font-mono">
                                                     {formatCurrency(finalTotal, userProfile?.currency || 'TRY')}
                                                 </span>
                                            </div>
                                         )}
                                     </div>
                                 );
                             })()}
                         </div>
                    </div>
                    <div className="fixed bottom-20 left-0 w-full p-4 md:static md:p-0 md:mt-8 z-30 bg-gradient-to-t from-stone-950 via-stone-950 to-transparent pb-6">
                        <div className="max-w-3xl mx-auto">
                            <button 
                                onClick={handleSave}
                                disabled={isSavingPrescription}
                                className="w-full bg-emerald-600 disabled:opacity-50 disabled:grayscale text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-emerald-700 flex items-center justify-center transition-all border border-emerald-500/20 active:scale-95"
                            >
                                {isSavingPrescription ? (
                                    <>
                                        <Loader2 className="animate-spin mr-2" size={24} /> Kaydediliyor...
                                    </>
                                ) : (
                                    <>
                                        <FileOutput className="mr-2" /> {editingId ? `${currentPrescriptionLabel} Güncelle` : `${currentPrescriptionLabel} Oluştur`}
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            )}
            {isScanning && (
                <BarcodeScanner 
                    onScan={handleScan} 
                    onClose={() => setIsScanning(false)} 
                    continuous={true}
                />
            )}

            {showProfitId && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
                    <div className="bg-stone-900 border border-white/10 w-full max-w-sm rounded-[2.5rem] p-6 shadow-2xl animate-in zoom-in-95 duration-300">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-xl font-black text-stone-100 flex items-center gap-3">
                                <TrendingUp className="text-emerald-500" />
                                Kar/Zarar Analizi
                            </h2>
                            <button onClick={() => setShowProfitId(null)} className="p-2 bg-stone-800 rounded-full text-stone-500 hover:text-white transition-colors">
                                <X size={16} />
                            </button>
                        </div>

                        {(() => {
                            const p = contextPrescriptions.find(presc => presc.id === showProfitId);
                            if (!p) return null;

                            const totalSales = p.totalAmount || 0;
                            const itemsWithCost = p.items.map(item => {
                                const qty = parseFloat(item.quantity?.toString().replace(',', '.') || '0') || 0;
                                let cost = item.buyingPrice;
                                if (cost === undefined) {
                                    const invItem = contextInventory.find(inv => inv.pesticideId === item.pesticideId);
                                    cost = invItem?.buyingPrice || 0;
                                }
                                return {
                                    ...item,
                                    qty,
                                    cost,
                                    totalCost: qty * cost,
                                    totalSale: item.totalPrice || 0
                                };
                            });

                            const totalCost = itemsWithCost.reduce((acc, item) => acc + item.totalCost, 0);
                            const profit = totalSales - totalCost;
                            const profitMargin = totalSales > 0 ? (profit / totalSales) * 100 : 0;

                            return (
                                <div className="space-y-6">
                                    <div className="grid grid-cols-1 gap-3">
                                        <div className="bg-stone-950 p-4 rounded-2xl border border-white/5">
                                            <p className="text-[10px] font-black text-stone-500 uppercase tracking-widest mb-1">Toplam Satış</p>
                                            <p className="text-xl font-black text-stone-100 font-mono">{formatCurrency(totalSales, userProfile?.currency || 'TRY')}</p>
                                        </div>
                                        <div className="bg-stone-950 p-4 rounded-2xl border border-white/5">
                                            <p className="text-[10px] font-black text-stone-500 uppercase tracking-widest mb-1">Toplam Maliyet</p>
                                            <p className="text-xl font-black text-stone-400 font-mono">{formatCurrency(totalCost, userProfile?.currency || 'TRY')}</p>
                                        </div>
                                        <div className={`p-4 rounded-2xl border ${profit >= 0 ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-rose-500/10 border-rose-500/20'}`}>
                                            <div className="flex justify-between items-start mb-1">
                                                <p className={`text-[10px] font-black uppercase tracking-widest ${profit >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                                    {profit >= 0 ? 'Net Kar' : 'Net Zarar'}
                                                </p>
                                                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${profit >= 0 ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>
                                                    %{profitMargin.toFixed(1)}
                                                </span>
                                            </div>
                                            <p className={`text-2xl font-black font-mono ${profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                                {formatCurrency(Math.abs(profit), userProfile?.currency || 'TRY')}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2 no-scrollbar">
                                        <p className="text-[10px] font-black text-stone-600 uppercase tracking-widest ml-1">Ürün Bazlı Detay</p>
                                        {itemsWithCost.map((item, idx) => (
                                            <div key={idx} className="bg-stone-950/50 p-3 rounded-xl border border-white/5 flex justify-between items-center">
                                                <div className="min-w-0 flex-1">
                                                    <p className="text-[10px] font-bold text-stone-300 truncate">{item.pesticideName}</p>
                                                    <p className="text-[9px] text-stone-500">{item.qty} Adet x {formatCurrency(item.cost, userProfile?.currency || 'TRY')} (Maliyet)</p>
                                                </div>
                                                <div className="text-right ml-3">
                                                    <p className={`text-[10px] font-black font-mono ${item.totalSale - item.totalCost >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                                        {formatCurrency(item.totalSale - item.totalCost, userProfile?.currency || 'TRY')}
                                                    </p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>

                                    <button 
                                        onClick={() => setShowProfitId(null)}
                                        className="w-full py-4 bg-stone-800 hover:bg-stone-700 text-white rounded-2xl font-bold text-sm transition-all active:scale-95"
                                    >
                                        Kapat
                                    </button>
                                </div>
                            );
                        })()}
                    </div>
                </div>
            )}

            {/* Payment Modal */}
            {isPaymentModalOpen && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
                    <div className="bg-stone-900 rounded-3xl w-full max-w-md p-5 shadow-2xl relative border border-white/10 animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
                        <button 
                            onClick={() => {
                                setIsPaymentModalOpen(false);
                                setEditingPayment(null);
                                setPaymentAmount('');
                            }} 
                            className="absolute top-3 right-3 p-1.5 bg-stone-800 rounded-full text-stone-400 hover:text-stone-200 z-10"
                        >
                            <X size={16} />
                        </button>
                        <div className="text-center mb-6 shrink-0">
                            <div className="w-12 h-12 bg-emerald-900/30 text-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-3">
                                <Wallet size={24} />
                            </div>
                            <h2 className="text-base font-bold text-stone-100">Tahsilat Faturası</h2>
                            <p className="text-xs text-stone-400 mt-1">Çiftçiden ödeme tahsil et</p>
                        </div>
                        
                        <div className="space-y-4 overflow-y-auto pr-2 pb-4 no-scrollbar">
                            <div>
                                <label className="block text-stone-400 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-1">Çiftçi Seçimi <span className="text-rose-500">*</span></label>
                                <select 
                                    className="w-full bg-stone-950 text-white px-4 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500/50 border border-white/5 font-medium appearance-none"
                                    value={selectedPaymentFarmerId}
                                    onChange={(e) => setSelectedPaymentFarmerId(e.target.value)}
                                >
                                    <option value="" disabled>Çiftçi Seçin...</option>
                                    {contextFarmers.map(f => (
                                        <option key={f.id} value={f.id}>{f.fullName}</option>
                                    ))}
                                </select>
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                                <div className="col-span-2 sm:col-span-1">
                                    <label className="block text-stone-400 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-1">Tutar ({getCurrencySymbol(userProfile?.currency || 'TRY')}) <span className="text-rose-500">*</span></label>
                                    <input 
                                        type="number" 
                                        value={paymentAmount}
                                        onChange={(e) => setPaymentAmount(e.target.value)}
                                        placeholder="0.00"
                                        className="w-full bg-stone-950 text-emerald-400 px-4 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500/50 border border-white/5 font-mono text-lg font-black"
                                    />
                                </div>
                                <div className="col-span-2 sm:col-span-1">
                                    <label className="block text-stone-400 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-1">Kasa/Banka</label>
                                    <select 
                                        className="w-full bg-stone-950 text-white px-4 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500/50 border border-white/5 font-medium appearance-none"
                                        value={selectedAccountId}
                                        onChange={(e) => setSelectedAccountId(e.target.value)}
                                    >
                                        <option value="">Seçiniz (Opsiyonel)</option>
                                        {accounts.map(a => (
                                            <option key={a.id} value={a.id}>{a.name}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                            
                            <div>
                                <label className="block text-stone-400 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-1">Ödeme Yöntemi <span className="text-rose-500">*</span></label>
                                <div className="grid grid-cols-3 gap-2">
                                    {[
                                        { id: 'CASH', label: 'Nakit' },
                                        { id: 'CHECK', label: 'Çek' },
                                        { id: 'TEDYE', label: 'Tediye' }
                                    ].map(method => (
                                        <button 
                                            key={method.id}
                                            onClick={() => setPaymentMethod(method.id as any)}
                                            className={`py-3 rounded-xl text-[9px] font-black uppercase tracking-widest border transition-all ${paymentMethod === method.id ? 'bg-emerald-600 border-emerald-500 text-white' : 'bg-stone-950 border-stone-800 text-stone-500'}`}
                                        >
                                            {method.label}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div>
                                <label className="block text-stone-400 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-1">
                                    {(paymentMethod === 'CHECK' || paymentMethod === 'TEDYE') ? 'Vade Tarihi' : 'İşlem Tarihi'}
                                </label>
                                <input 
                                    type="date"
                                    value={paymentDate}
                                    onChange={(e) => setPaymentDate(e.target.value)}
                                    className="w-full bg-stone-950 text-white px-4 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500/50 border border-white/5 font-medium"
                                />
                            </div>

                            <div>
                                <label className="block text-stone-400 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-1">Açıklama (Opsiyonel)</label>
                                <textarea 
                                    value={paymentNote}
                                    onChange={(e) => setPaymentNote(e.target.value)}
                                    placeholder="Makbuz notu..."
                                    className="w-full bg-stone-950 text-white px-4 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500/50 border border-white/5 font-medium resize-none h-20"
                                />
                            </div>
                        </div>

                        <div className="pt-4 mt-2 border-t border-white/5 shrink-0 flex gap-3">
                            <button 
                                onClick={() => {
                                    setIsPaymentModalOpen(false);
                                    setEditingPayment(null);
                                    setPaymentAmount('');
                                }}
                                className="flex-1 py-3.5 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-2xl font-bold text-sm transition-all"
                            >
                                İptal
                            </button>
                            <button 
                                disabled={isSavingPayment || !paymentAmount || !selectedPaymentFarmerId}
                                onClick={async () => {
                                    setIsSavingPayment(true);
                                    try {
                                        const parsedAmount = parseFloat(paymentAmount.replace(/,/g, ''));
                                        if (isNaN(parsedAmount) || parsedAmount <= 0) {
                                            showToast('Geçerli bir tutar giriniz', 'error');
                                            setIsSavingPayment(false);
                                            return;
                                        }

                                        const targetAccountId = selectedAccountId || accounts.find(a => a.type === 'CASH')?.id || accounts[0]?.id;

                                        if (editingPayment) {
                                            await updatePayment({
                                                ...editingPayment,
                                                amount: parsedAmount,
                                                note: paymentNote,
                                                method: paymentMethod,
                                                dueDate: (paymentMethod === 'CHECK' || paymentMethod === 'TEDYE') ? paymentDate : undefined,
                                                accountId: targetAccountId || undefined,
                                                farmerId: selectedPaymentFarmerId
                                            });
                                            showToast('Tahsilat güncellendi', 'success');
                                        } else {
                                            await addPayment({
                                                farmerId: selectedPaymentFarmerId,
                                                amount: parsedAmount,
                                                date: new Date().toISOString(),
                                                method: paymentMethod,
                                                dueDate: (paymentMethod === 'CHECK' || paymentMethod === 'TEDYE') ? paymentDate : undefined,
                                                note: paymentNote,
                                                accountId: targetAccountId || undefined,
                                                createdById: activeTeamMember?.id
                                            });
                                            showToast('Tahsilat kaydedildi', 'success');
                                        }

                                        hapticFeedback('success');
                                        setIsPaymentModalOpen(false);
                                        setPaymentAmount('');
                                        setPaymentNote('');
                                        setSelectedPaymentFarmerId('');
                                        setEditingPayment(null);
                                    } catch (e) {
                                        showToast('Tahsilat kaydedilemedi', 'error');
                                    } finally {
                                        setIsSavingPayment(false);
                                    }
                                }}
                                className={`flex-1 py-3.5 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                                    isSavingPayment || !paymentAmount || !selectedPaymentFarmerId
                                    ? 'bg-emerald-900/50 text-emerald-700 cursor-not-allowed' 
                                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/20 active:scale-95'
                                }`}
                            >
                                {isSavingPayment ? <Loader2 size={18} className="animate-spin" /> : <><Check size={18} /> Kaydet</>}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <ConfirmationModal
                isOpen={confirmModal.isOpen}
                onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                onConfirm={confirmModal.onConfirm}
                title={confirmModal.title}
                message={confirmModal.message}
                variant={confirmModal.variant}
            />
        </div>
    );
};
