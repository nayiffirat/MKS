import { createMultiPagePdf } from '../utils/pdfHelper';

import React, { useState, useRef } from 'react';
import { 
    ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, 
    CartesianGrid, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell 
} from 'recharts';
import { 
    Download, Users, Ruler, Sprout, MapPin, Loader2, ArrowUpRight, ArrowDownRight,
    FileText, X, Calendar, Activity, Zap, ClipboardCheck, 
    AlertTriangle, TrendingUp, History, Scale, BookOpen, 
    ChevronRight, PieChart as PieIcon, BarChart3, LineChart as LineIcon, Truck, DollarSign, Package
} from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { dbService } from '../services/db';
import { useAppViewModel } from '../context/AppContext';
import { Prescription } from '../types';
import { formatCurrency } from '../utils/currency';
import { IncomeExpenseChartReport } from './IncomeExpenseChartReport';

    type StatTab = 'OVERVIEW' | 'PROFIT_LOSS' | 'PESTICIDES' | 'VISITS' | 'CONSUMPTION' | 'SALES' | 'DEBTS' | 'RECEIVABLES' | 'INVENTORY' | 'LAND';

    interface StatisticsProps {
        onNavigate?: (view: any) => void;
        initialTab?: StatTab;
    }

    export const StatisticsScreen: React.FC<StatisticsProps> = ({ onNavigate, initialTab }) => {
    const { 
        stats, 
        farmers, 
        reminders, 
        notifications, 
        inventory, 
        suppliers, 
        userProfile,
        farmerLabel,
        farmerPluralLabel,
        prescriptionLabel,
        plants,
        showToast
    } = useAppViewModel();
    const [activeTab, setActiveTab] = useState<StatTab>(initialTab || 'OVERVIEW');
    const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
    const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
    const [visitLogs, setVisitLogs] = useState<any[]>([]);
    const reportRef = useRef<HTMLDivElement>(null);

    const COLORS = [
        '#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#f43f5e', '#06b6d4',
        '#14b8a6', '#f97316', '#a855f7', '#6366f1', '#2dd4bf', '#fbbf24', '#f87171', '#c084fc'
    ];

    React.useEffect(() => {
        const loadData = async () => {
            const pDataRaw = await dbService.getAllPrescriptions();
            const vDataRaw = await dbService.getAllVisits();
            
            // Filter out deleted items
            const pData = pDataRaw.filter(p => !p.deletedAt);
            const vData = vDataRaw.filter(v => !v.deletedAt);
            
            setPrescriptions(pData);
            setVisitLogs(vData);
        };
        loadData();
    }, []);

    const visitLogsWithNames = React.useMemo(() => {
        return visitLogs.map(v => {
            const farmer = farmers.find(f => f.id === v.farmerId);
            return {
                ...v,
                farmerName: farmer ? farmer.fullName : 'Bilinmeyen Üretici'
            };
        }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [visitLogs, farmers]);

    const prescriptionsWithNames = React.useMemo(() => {
        return prescriptions.map(p => {
            const farmer = farmers.find(f => f.id === p.farmerId);
            return {
                ...p,
                farmerName: farmer ? farmer.fullName : 'Bilinmeyen Üretici'
            };
        }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [prescriptions, farmers]);

    // Calculate Sales Data
    const salesData = React.useMemo(() => {
        const monthlySales: Record<string, number> = {};
        const productSales: Record<string, number> = {};
        let totalRevenue = 0;
        let totalCost = 0;

        // Buying price map for profit calculation
        const buyingPriceMap = inventory.reduce((acc, item) => {
            acc[item.pesticideId] = item.buyingPrice;
            return acc;
        }, {} as Record<string, number>);

        prescriptions.forEach(p => {
            // Only count processed ones for profit/loss consistency with Inventory screen
            if (!p.isInventoryProcessed) return;

            const date = new Date(p.date);
            const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            
            // Fatura toplam tutarı varsa kullan, yoksa kalemleri topla
            let prescriptionTotal = p.totalAmount || 0;
            
            // Eğer totalAmount yoksa ve items içinde totalPrice varsa onları topla (geriye dönük uyumluluk)
            if (!prescriptionTotal && p.items) {
                prescriptionTotal = p.items.reduce((acc, item) => acc + (item.totalPrice || 0), 0);
            }

            const isReturn = p.type === 'RETURN' || prescriptionTotal < 0;
            const amountAbs = Math.abs(prescriptionTotal);

            if (isReturn) {
                monthlySales[monthKey] = (monthlySales[monthKey] || 0) - amountAbs;
                totalRevenue -= amountAbs;
            } else {
                monthlySales[monthKey] = (monthlySales[monthKey] || 0) + amountAbs;
                totalRevenue += amountAbs;
            }

            // Ürün bazlı satışlar ve maliyet
            if (p.items) {
                p.items.forEach(item => {
                    const qty = parseFloat(item.quantity?.replace(',', '.') || '0');
                    if (qty > 0) {
                        const cost = buyingPriceMap[item.pesticideId] || 0;
                        if (isReturn) {
                            totalCost -= qty * cost;
                            if (item.totalPrice) {
                                productSales[item.pesticideName] = (productSales[item.pesticideName] || 0) - item.totalPrice;
                            }
                        } else {
                            totalCost += qty * cost;
                            if (item.totalPrice) {
                                productSales[item.pesticideName] = (productSales[item.pesticideName] || 0) + item.totalPrice;
                            }
                        }
                    }
                });
            }
        });

        const totalProfit = totalRevenue - totalCost;
        const margin = totalCost > 0 ? (totalProfit / totalCost) * 100 : 0;

        const monthlyChartData = Object.entries(monthlySales)
            .map(([date, amount]) => ({ date, amount }))
            .sort((a, b) => a.date.localeCompare(b.date));

        const productChartData = Object.entries(productSales)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 10); // Top 10 products

        return {
            totalRevenue,
            totalCost,
            totalProfit,
            margin,
            monthlyChartData,
            productChartData
        };
    }, [prescriptions, inventory]);

    const plantReceivableData = React.useMemo(() => {
        const plantDebts: Record<string, number> = {};
        
        prescriptions.forEach(p => {
            if (p.priceType === 'TERM' && p.type === 'SALE') {
                const farmer = farmers.find(f => f.id === p.farmerId);
                // We only count if farmer still has balance (this is a simplification)
                // But a better way is to see which plants have more "pending" (non-paid) invoices
                if (farmer && (farmer.balance || 0) < 0) {
                   const plant = plants.find(pl => pl.id === p.plantId);
                   const name = plant?.name || 'Diğer / Belirsiz';
                   plantDebts[name] = (plantDebts[name] || 0) + (p.totalAmount || 0);
                }
            }
        });

        return Object.entries(plantDebts)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value);
    }, [prescriptions, farmers, plants]);

    const supplierDebtData = React.useMemo(() => {
        const debts = suppliers
            .filter((s: any) => s.balance < 0)
            .map((s: any) => ({
                name: s.name,
                debt: Math.abs(s.balance)
            }))
            .sort((a: any, b: any) => b.debt - a.debt);
        
        const totalSupplierDebt = debts.reduce((acc: number, curr: any) => acc + curr.debt, 0);
        
        return {
            debts,
            totalSupplierDebt
        };
    }, [suppliers]);

    const farmerReceivableData = React.useMemo(() => {
        const receivables = farmers
            .filter((f: any) => (f.balance || 0) < 0)
            .map((f: any) => ({
                name: f.fullName,
                amount: Math.abs(f.balance || 0)
            }))
            .sort((a: any, b: any) => b.amount - a.amount);
        
        const totalFarmerReceivables = receivables.reduce((acc: number, curr: any) => acc + curr.amount, 0);
        
        return {
            receivables,
            totalFarmerReceivables
        };
    }, [farmers]);

    const handleDownloadPDF = async () => {
        if (!reportRef.current) return;
        setIsGeneratingPdf(true);
        try {
            // Ensure the report is visible for capturing
            const originalStyle = reportRef.current.style.cssText;
            reportRef.current.style.position = 'absolute';
            reportRef.current.style.left = '0';
            reportRef.current.style.top = '0';
            reportRef.current.style.opacity = '1';
            reportRef.current.style.zIndex = '-1';

            const canvas = await html2canvas(reportRef.current, {
                scale: 2,
                backgroundColor: '#0c0a09',
                logging: false,
                useCORS: true,
                allowTaint: true,
                windowWidth: 1200
            });

            // Restore original style
            reportRef.current.style.cssText = originalStyle;

            const pdf = createMultiPagePdf(canvas);

            pdf.save(`MKS_Detayli_Analiz_Raporu_${new Date().toISOString().split('T')[0]}.pdf`);
        } catch (e) {
            console.error("PDF Generation Error:", e);
            showToast("Rapor oluşturulurken bir hata oluştu.", "error");
        } finally {
            setIsGeneratingPdf(false);
        }
    };

    // Calculate Village Distribution
    const villageData = React.useMemo(() => {
        const distribution: Record<string, number> = {};
        farmers.forEach(f => {
            const village = f.village || 'Merkez';
            distribution[village] = (distribution[village] || 0) + 1;
        });
        return Object.entries(distribution)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value);
    }, [farmers]);

    // Calculate Task Completion Rate
    const taskStats = React.useMemo(() => {
        const total = reminders.length;
        const completed = reminders.filter(r => r.isCompleted).length;
        const pending = total - completed;
        const rate = total > 0 ? Math.round((completed / total) * 100) : 0;
        return {
            rate,
            total,
            completed,
            pending,
            data: [
                { name: 'Tamamlanan', value: completed, color: '#10b981' },
                { name: 'Bekleyen', value: pending, color: '#f59e0b' }
            ]
        };
    }, [reminders]);

    const averageFieldSize = React.useMemo(() => {
        return stats.totalFarmers > 0 ? (stats.totalArea / stats.totalFarmers).toFixed(1) : '0';
    }, [stats.totalArea, stats.totalFarmers]);

    const cropDiversity = stats.cropDistribution.length;

    // Calculate Pesticide Consumption (Count based)
    const consumptionData = React.useMemo(() => {
        const counts: Record<string, number> = {};
        prescriptions.forEach(p => {
            const isReturn = p.type === 'RETURN' || (p.totalAmount || 0) < 0;
            p.items.forEach(item => {
                const name = item.pesticideName;
                // Eğer quantity varsa onu sayıya çevirip ekle, yoksa 1 say
                let qty = 1;
                if (item.quantity) {
                    const match = String(item.quantity).replace(',', '.').match(/[\d.]+/);
                    if (match) qty = parseFloat(match[0]);
                }
                if (isReturn) {
                    counts[name] = (counts[name] || 0) - qty;
                } else {
                    counts[name] = (counts[name] || 0) + qty;
                }
            });
        });

        return Object.entries(counts)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value);
    }, [prescriptions]);

    // Calculate Profit/Loss Data (Realized)
    const profitLossData = React.useMemo(() => {
        const processed = prescriptions.filter(p => p.isInventoryProcessed);
        
        let totalSoldCost = 0;
        let totalSoldRevenue = 0;

        const buyingPriceMap = inventory.reduce((acc, item) => {
            acc[item.pesticideId] = item.buyingPrice;
            return acc;
        }, {} as Record<string, number>);

        processed.forEach(p => {
            const isReturn = p.type === 'RETURN' || (p.totalAmount || 0) < 0;
            p.items.forEach(item => {
                const qty = parseFloat(item.quantity?.replace(',', '.') || '0');
                if (qty > 0) {
                    const cost = buyingPriceMap[item.pesticideId] || 0;
                    const revenue = item.unitPrice || 0;
                    
                    if (isReturn) {
                        totalSoldCost -= qty * cost;
                        totalSoldRevenue -= qty * revenue;
                    } else {
                        totalSoldCost += qty * cost;
                        totalSoldRevenue += qty * revenue;
                    }
                }
            });
        });

        const totalProfit = totalSoldRevenue - totalSoldCost - stats.totalExpenses;
        const margin = totalSoldCost > 0 ? (totalProfit / (totalSoldCost + stats.totalExpenses)) * 100 : 0;

        return {
            totalSoldCost,
            totalSoldRevenue,
            totalProfit,
            margin,
            processedCount: processed.length,
            totalExpenses: stats.totalExpenses
        };
    }, [inventory, prescriptions, stats.totalExpenses]);

    const renderTabContent = () => {
        switch (activeTab) {
            case 'OVERVIEW':
                return (
                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
                        {/* Summary Cards */}
                        <div className="grid grid-cols-2 gap-3">
                            <QuickStatCard 
                                title={`Toplam ${farmerLabel}`} 
                                value={stats.totalFarmers} 
                                icon={Users} 
                                color="blue" 
                                trend="+12%"
                            />
                            <QuickStatCard 
                                title="Depo Kar/Zarar" 
                                value={formatCurrency(profitLossData.totalProfit, userProfile?.currency || 'TRY')} 
                                icon={TrendingUp} 
                                color={profitLossData.totalProfit >= 0 ? "emerald" : "rose"} 
                                trend={profitLossData.margin ? `%${profitLossData.margin.toFixed(1)} Marj` : undefined}
                            />
                            <QuickStatCard 
                                title="Aktif Görevler" 
                                value={stats.activeReminders} 
                                icon={ClipboardCheck} 
                                color="amber" 
                            />
                            <QuickStatCard 
                                title="Kritik Uyarılar" 
                                value={notifications.filter(n => n.type === 'WARNING').length} 
                                icon={AlertTriangle} 
                                color="red" 
                            />
                        </div>

                        {/* Detailed Metrics Grid */}
                        <div className="grid grid-cols-3 gap-2">
                            <div className="bg-stone-900/40 border border-white/5 rounded-2xl p-3 flex flex-col items-center justify-center text-center">
                                <Scale size={14} className="text-stone-500 mb-1" />
                                <p className="text-xs font-black text-stone-100">{averageFieldSize}</p>
                                <p className="text-[7px] font-bold text-stone-500 uppercase tracking-tighter">Ort. Arazi (da)</p>
                            </div>
                            <div className="bg-stone-900/40 border border-white/5 rounded-2xl p-3 flex flex-col items-center justify-center text-center">
                                <Sprout size={14} className="text-stone-500 mb-1" />
                                <p className="text-xs font-black text-stone-100">{cropDiversity}</p>
                                <p className="text-[7px] font-bold text-stone-500 uppercase tracking-tighter">Ürün Çeşitliliği</p>
                            </div>
                            <div className="bg-stone-900/40 border border-white/5 rounded-2xl p-3 flex flex-col items-center justify-center text-center">
                                <TrendingUp size={14} className="text-stone-500 mb-1" />
                                <p className="text-xs font-black text-stone-100">%{taskStats.rate}</p>
                                <p className="text-[7px] font-bold text-stone-500 uppercase tracking-tighter">Görev Başarısı</p>
                            </div>
                        </div>

                        {/* Village Distribution Chart */}
                        <div className="bg-stone-900/60 border border-white/5 rounded-[2rem] p-5">
                            <div className="flex items-center justify-between mb-6">
                                <div className="flex items-center gap-2">
                                    <MapPin size={16} className="text-stone-500" />
                                    <h3 className="text-xs font-black text-stone-300 uppercase tracking-widest">Bölgesel Dağılım</h3>
                                </div>
                            </div>
                            <div className="h-48 w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={villageData.slice(0, 5)}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                                        <XAxis 
                                            dataKey="name" 
                                            axisLine={false} 
                                            tickLine={false} 
                                            tick={{ fill: '#737373', fontSize: 10, fontWeight: 700 }} 
                                        />
                                        <YAxis hide />
                                        <Tooltip 
                                            contentStyle={{ backgroundColor: '#1c1917', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '10px' }}
                                            itemStyle={{ color: '#10b981' }}
                                        />
                                        <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]} barSize={30} />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Crop Distribution Summary */}
                        <div className="bg-stone-900/60 border border-white/5 rounded-[2rem] p-5">
                            <div className="flex items-center justify-between mb-6">
                                <div className="flex items-center gap-2">
                                    <Sprout size={16} className="text-stone-500" />
                                    <h3 className="text-xs font-black text-stone-300 uppercase tracking-widest">Ürün Dağılımı</h3>
                                </div>
                            </div>
                            <div className="space-y-3">
                                {stats.cropDistribution.slice(0, 4).map((item, idx) => (
                                    <div key={idx} className="space-y-1">
                                        <div className="flex justify-between text-[10px] font-bold">
                                            <span className="text-stone-400">{item.crop}</span>
                                            <span className="text-emerald-500">{item.area} da</span>
                                        </div>
                                        <div className="h-1.5 w-full bg-stone-950 rounded-full overflow-hidden">
                                            <div 
                                                className="h-full bg-emerald-500 rounded-full" 
                                                style={{ width: `${(item.area / stats.totalArea) * 100}%` }}
                                            />
                                        </div>
                                    </div>
                                ))}
                                {stats.cropDistribution.length > 4 && (
                                    <button 
                                        onClick={() => setActiveTab('LAND')}
                                        className="w-full text-center text-[9px] font-black text-stone-500 uppercase tracking-widest pt-2 hover:text-emerald-500 transition-colors"
                                    >
                                        Tümünü Gör
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                );
            case 'PROFIT_LOSS':
                return (
                    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        {/* Interactive Gelir-Gider Analiz Grafik Modülü */}
                        <IncomeExpenseChartReport />

                        {/* Stats Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="bg-stone-900 border border-white/5 p-5 rounded-2xl shadow-sm">
                                <div className="flex items-center gap-3 mb-3">
                                    <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center text-red-400">
                                        <ArrowDownRight size={20} />
                                    </div>
                                    <span className="text-stone-500 text-[10px] font-bold uppercase tracking-wider">Satılan Ürün Maliyeti</span>
                                </div>
                                <div className="text-2xl font-black text-stone-100">{formatCurrency(profitLossData.totalSoldCost, userProfile?.currency || 'TRY')}</div>
                                <p className="text-[10px] text-stone-600 mt-2 font-medium">{profitLossData.processedCount} adet işlenmiş fatura baz alınmıştır.</p>
                            </div>

                            <div className="bg-stone-900 border border-white/5 p-5 rounded-2xl shadow-sm">
                                <div className="flex items-center gap-3 mb-3">
                                    <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400">
                                        <ArrowUpRight size={20} />
                                    </div>
                                    <span className="text-stone-500 text-[10px] font-bold uppercase tracking-wider">Satış Geliri</span>
                                </div>
                                <div className="text-2xl font-black text-stone-100">{formatCurrency(profitLossData.totalSoldRevenue, userProfile?.currency || 'TRY')}</div>
                                <p className="text-[10px] text-stone-600 mt-2 font-medium">{prescriptionLabel}lerdeki birim fiyatlar üzerinden hesaplanmıştır.</p>
                            </div>

                            <div className="bg-stone-900 border border-white/5 p-5 rounded-2xl shadow-sm relative overflow-hidden">
                                <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 rounded-full blur-3xl opacity-20 ${profitLossData.totalProfit >= 0 ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                                <div className="flex items-center gap-3 mb-3">
                                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${profitLossData.totalProfit >= 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                                        <DollarSign size={20} />
                                    </div>
                                    <span className="text-stone-500 text-[10px] font-bold uppercase tracking-wider">Net Kar / Zarar</span>
                                </div>
                                <div className={`text-2xl font-black ${profitLossData.totalProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                    {formatCurrency(profitLossData.totalProfit, userProfile?.currency || 'TRY')}
                                </div>
                                <div className="flex items-center gap-2 mt-2">
                                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${profitLossData.totalProfit >= 0 ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
                                        %{profitLossData.margin.toFixed(1)} Marj
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* Detailed Info Card */}
                        <div className="bg-stone-900 border border-white/5 p-8 rounded-3xl shadow-sm">
                            <div className="flex items-center gap-4 mb-8">
                                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                                    <TrendingUp size={24} />
                                </div>
                                <div>
                                    <h3 className="text-xl font-black text-stone-100 tracking-tight">Finansal Özet</h3>
                                    <p className="text-stone-500 text-xs font-bold uppercase tracking-widest">Gerçekleşen Satış Analizi</p>
                                </div>
                            </div>

                            <div className="space-y-6">
                                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                                    <span className="text-stone-400 font-medium">Kasadaki Para</span>
                                    <span className="text-stone-100 font-black">{formatCurrency(stats.cashBalance || 0, userProfile?.currency || 'TRY')}</span>
                                </div>
                                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                                    <span className="text-stone-400 font-medium">Hesaptaki Para</span>
                                    <span className="text-stone-100 font-black">{formatCurrency(stats.bankBalance || 0, userProfile?.currency || 'TRY')}</span>
                                </div>
                                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                                    <span className="text-stone-400 font-medium">Toplam Satış Geliri</span>
                                    <span className="text-stone-100 font-black">{formatCurrency(profitLossData.totalSoldRevenue, userProfile?.currency || 'TRY')}</span>
                                </div>
                                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                                    <span className="text-stone-400 font-medium">Toplam Ürün Maliyeti</span>
                                    <span className="text-stone-100 font-black text-red-400">-{formatCurrency(profitLossData.totalSoldCost, userProfile?.currency || 'TRY')}</span>
                                </div>
                                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                                    <span className="text-stone-400 font-medium">İşletme Giderleri</span>
                                    <span className="text-stone-100 font-black text-red-400">-{formatCurrency(profitLossData.totalExpenses, userProfile?.currency || 'TRY')}</span>
                                </div>
                                <div className="flex justify-between items-center pt-2">
                                    <span className="text-stone-100 font-black text-lg">Toplam Net Kar</span>
                                    <span className={`text-2xl font-black ${profitLossData.totalProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                        {formatCurrency(profitLossData.totalProfit + (stats.cashBalance || 0) + (stats.bankBalance || 0), userProfile?.currency || 'TRY')}
                                    </span>
                                </div>
                            </div>

                            <div className="mt-10 p-4 bg-stone-950/50 rounded-2xl border border-white/5 flex items-start gap-3">
                                <AlertTriangle className="text-amber-500 shrink-0" size={18} />
                                <p className="text-xs text-stone-500 leading-relaxed">
                                    Bu veriler, "İşlenmiş" olarak işaretlenen ve stoktan düşülen faturalardaki ürünlerin, deponuzdaki güncel alış fiyatları ile faturadaki satış fiyatları karşılaştırılarak hesaplanmıştır.
                                </p>
                            </div>
                        </div>
                    </div>
                );
            case 'LAND':
                return (
                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
                        <div className="bg-stone-900/60 border border-white/5 rounded-[2rem] p-5">
                            <div className="flex items-center justify-between mb-6">
                                <div className="flex items-center gap-2">
                                    <Sprout size={16} className="text-emerald-500" />
                                    <h3 className="text-xs font-black text-stone-300 uppercase tracking-widest">Ürün Dağılımı (da)</h3>
                                </div>
                                <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                                    {stats.totalArea} da Toplam
                                </span>
                            </div>
                            
                            <div className="h-64 w-full flex items-center justify-center">
                                <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie
                                            data={stats.cropDistribution}
                                            cx="50%"
                                            cy="50%"
                                            innerRadius={60}
                                            outerRadius={80}
                                            paddingAngle={5}
                                            dataKey="area"
                                            nameKey="crop"
                                        >
                                            {stats.cropDistribution.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="rgba(0,0,0,0.2)" />
                                            ))}
                                        </Pie>
                                        <Tooltip 
                                            contentStyle={{ backgroundColor: '#1c1917', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '10px' }}
                                        />
                                    </PieChart>
                                </ResponsiveContainer>
                            </div>

                            <div className="grid grid-cols-2 gap-2 mt-4">
                                {stats.cropDistribution.map((item, idx) => (
                                    <div key={idx} className="flex items-center gap-2 p-2 bg-stone-950/50 rounded-xl border border-white/5">
                                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-[10px] font-bold text-stone-300 truncate">{item.crop}</p>
                                            <p className="text-[9px] text-stone-500">{item.area} da</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                );
            case 'CONSUMPTION':
                return (
                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
                        <div className="bg-stone-900/60 border border-white/5 rounded-[2rem] p-5">
                            <div className="flex items-center justify-between mb-6">
                                <div className="flex items-center gap-2">
                                    <Zap size={16} className="text-amber-500" />
                                    <h3 className="text-xs font-black text-stone-300 uppercase tracking-widest">İlaç Sarfiyatı (Adet)</h3>
                                </div>
                                <span className="text-[10px] font-black text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                                    {consumptionData.reduce((acc, curr) => acc + curr.value, 0)} Toplam Adet
                                </span>
                            </div>
                            
                            <div className="h-64 w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={consumptionData.slice(0, 8)} layout="vertical">
                                        <CartesianGrid strokeDasharray="3 3" stroke="#262626" horizontal={false} />
                                        <XAxis type="number" hide />
                                        <YAxis 
                                            dataKey="name" 
                                            type="category" 
                                            width={100}
                                            axisLine={false}
                                            tickLine={false}
                                            tick={{ fill: '#737373', fontSize: 9, fontWeight: 700 }}
                                        />
                                        <Tooltip 
                                            contentStyle={{ backgroundColor: '#1c1917', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '10px' }}
                                            cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                                        />
                                        <Bar dataKey="value" fill="#f59e0b" radius={[0, 4, 4, 0]} barSize={20} />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>

                            <div className="space-y-2 mt-4">
                                {consumptionData.map((item, idx) => (
                                    <div key={idx} className="flex items-center justify-between p-3 bg-stone-950/50 rounded-xl border border-white/5">
                                        <div className="flex items-center gap-3">
                                            <div className="w-6 h-6 rounded-lg bg-amber-500/10 flex items-center justify-center text-[10px] font-black text-amber-500 border border-amber-500/20">
                                                {idx + 1}
                                            </div>
                                            <span className="text-[10px] font-bold text-stone-300">{item.name}</span>
                                        </div>
                                        <span className="text-xs font-black text-amber-500">{item.value} Adet</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                );
            case 'SALES':
                return (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            <div className="bg-stone-900 p-5 rounded-2xl border border-white/5 shadow-sm relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/20 transition-all"></div>
                                <h3 className="text-stone-400 text-[10px] font-bold uppercase tracking-widest">Toplam Gelir</h3>
                                <p className="text-xl font-black text-emerald-400 font-mono mt-1">
                                    {formatCurrency(salesData.totalRevenue, userProfile?.currency || 'TRY')}
                                </p>
                            </div>
                            <div className="bg-stone-900 p-5 rounded-2xl border border-white/5 shadow-sm relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-red-500/10 rounded-full blur-2xl group-hover:bg-red-500/20 transition-all"></div>
                                <h3 className="text-stone-400 text-[10px] font-bold uppercase tracking-widest">Toplam Maliyet</h3>
                                <p className="text-xl font-black text-red-400 font-mono mt-1">
                                    {formatCurrency(salesData.totalCost, userProfile?.currency || 'TRY')}
                                </p>
                            </div>
                            <div className="bg-stone-900 p-5 rounded-2xl border border-white/5 shadow-sm relative overflow-hidden group">
                                <div className={`absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl transition-all ${salesData.totalProfit >= 0 ? 'bg-blue-500/10 group-hover:bg-blue-500/20' : 'bg-rose-500/10 group-hover:bg-rose-500/20'}`}></div>
                                <h3 className="text-stone-400 text-[10px] font-bold uppercase tracking-widest">Net Kar / Zarar</h3>
                                <div className="flex items-baseline gap-2">
                                    <p className={`text-xl font-black font-mono mt-1 ${salesData.totalProfit >= 0 ? 'text-blue-400' : 'text-rose-400'}`}>
                                        {formatCurrency(salesData.totalProfit, userProfile?.currency || 'TRY')}
                                    </p>
                                    <span className={`text-[10px] font-bold ${salesData.margin >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                                        %{salesData.margin.toFixed(1)}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <div className="bg-stone-900 p-6 rounded-2xl border border-white/5 shadow-sm">
                                <h3 className="text-stone-100 font-bold mb-6 flex items-center text-sm uppercase tracking-wider">
                                    <Activity size={16} className="mr-2 text-emerald-500"/> Aylık Satış Grafiği
                                </h3>
                                <div className="h-[300px] w-full">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={salesData.monthlyChartData}>
                                            <defs>
                                                <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                                                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                                                </linearGradient>
                                            </defs>
                                            <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} opacity={0.3} />
                                            <XAxis 
                                                dataKey="date" 
                                                stroke="#666" 
                                                tick={{fill: '#666', fontSize: 10}} 
                                                tickLine={false}
                                                axisLine={false}
                                            />
                                            <YAxis 
                                                stroke="#666" 
                                                tick={{fill: '#666', fontSize: 10}} 
                                                tickLine={false}
                                                axisLine={false}
                                                tickFormatter={(value) => `${value / 1000}k`}
                                            />
                                            <Tooltip 
                                                contentStyle={{backgroundColor: '#1c1917', borderColor: '#333', borderRadius: '12px', color: '#fff', boxShadow: '0 10px 30px -10px rgba(0,0,0,0.5)'}}
                                                itemStyle={{color: '#10b981', fontWeight: 'bold', fontFamily: 'monospace'}}
                                                formatter={(value: number) => [formatCurrency(value, userProfile?.currency || 'TRY'), 'Tutar']}
                                                labelStyle={{color: '#9ca3af', fontSize: '12px', marginBottom: '4px', fontWeight: 'bold'}}
                                            />
                                            <Area 
                                                type="monotone" 
                                                dataKey="amount" 
                                                stroke="#10b981" 
                                                strokeWidth={3}
                                                fillOpacity={1} 
                                                fill="url(#colorSales)" 
                                            />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>

                            <div className="bg-stone-900 p-6 rounded-2xl border border-white/5 shadow-sm">
                                <h3 className="text-stone-100 font-bold mb-6 flex items-center text-sm uppercase tracking-wider">
                                    <PieIcon size={16} className="mr-2 text-blue-500"/> En Çok Gelir Getiren Ürünler
                                </h3>
                                <div className="h-[300px] w-full">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart layout="vertical" data={salesData.productChartData}>
                                            <CartesianGrid strokeDasharray="3 3" stroke="#333" horizontal={true} vertical={false} opacity={0.3} />
                                            <XAxis type="number" hide />
                                            <YAxis 
                                                dataKey="name" 
                                                type="category" 
                                                width={100}
                                                tick={{fill: '#9ca3af', fontSize: 10, fontWeight: 500}}
                                                tickLine={false}
                                                axisLine={false}
                                            />
                                            <Tooltip 
                                                cursor={{fill: '#ffffff05'}}
                                                contentStyle={{backgroundColor: '#1c1917', borderColor: '#333', borderRadius: '12px', color: '#fff', boxShadow: '0 10px 30px -10px rgba(0,0,0,0.5)'}}
                                                formatter={(value: number) => [formatCurrency(value, userProfile?.currency || 'TRY'), 'Tutar']}
                                                itemStyle={{color: '#3b82f6', fontWeight: 'bold', fontFamily: 'monospace'}}
                                                labelStyle={{color: '#9ca3af', fontSize: '12px', marginBottom: '4px', fontWeight: 'bold'}}
                                            />
                                            <Bar dataKey="value" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={20}>
                                                {salesData.productChartData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                                ))}
                                            </Bar>
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </div>
                    </div>
                );
            case 'DEBTS':
                return (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 space-y-6">
                        <div className="bg-stone-900 p-6 rounded-2xl border border-white/5 shadow-sm relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/10 rounded-full blur-3xl group-hover:bg-rose-500/20 transition-all"></div>
                            <div className="relative z-10">
                                <h3 className="text-stone-400 text-[10px] font-bold uppercase tracking-widest mb-1">Toplam Tedarikçi Borcu</h3>
                                <p className="text-3xl font-black text-rose-400 font-mono">
                                    {formatCurrency(Math.round(supplierDebtData.totalSupplierDebt), userProfile?.currency || 'TRY')}
                                </p>
                                <p className="text-[10px] text-stone-500 mt-2 font-medium">Toplam {supplierDebtData.debts.length} tedarikçiye borç bulunmaktadır.</p>
                            </div>
                        </div>

                        <div className="bg-stone-900 rounded-2xl border border-white/5 overflow-hidden">
                            <div className="p-4 border-b border-white/5 bg-stone-950/30">
                                <h3 className="text-xs font-black text-stone-300 uppercase tracking-widest">Tedarikçi Bazlı Borç Dağılımı</h3>
                            </div>
                            <div className="divide-y divide-white/5">
                                {supplierDebtData.debts.length === 0 ? (
                                    <div className="p-10 text-center">
                                        <p className="text-stone-500 text-xs font-medium">Şu an kayıtlı bir borç bulunmamaktadır.</p>
                                    </div>
                                ) : (
                                    supplierDebtData.debts.map((s: any, i: number) => (
                                        <div key={i} className="p-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-lg bg-stone-800 flex items-center justify-center text-rose-500 font-bold text-xs">
                                                    {i + 1}
                                                </div>
                                                <span className="text-xs font-bold text-stone-200">{s.name}</span>
                                            </div>
                                            <span className="text-sm font-black text-rose-400 font-mono">
                                                {formatCurrency(Math.round(s.debt), userProfile?.currency || 'TRY')}
                                            </span>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                );
            case 'RECEIVABLES':
                return (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 space-y-6">
                        <div className="bg-stone-900 p-6 rounded-2xl border border-white/5 shadow-sm relative overflow-hidden group">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl group-hover:bg-emerald-500/20 transition-all"></div>
                            <div className="relative z-10">
                                <h3 className="text-stone-400 text-[10px] font-bold uppercase tracking-widest mb-1">Toplam Üretici Alacağı</h3>
                                <p className="text-3xl font-black text-emerald-400 font-mono">
                                    {formatCurrency(Math.round(farmerReceivableData.totalFarmerReceivables), userProfile?.currency || 'TRY')}
                                </p>
                                <p className="text-[10px] text-stone-500 mt-2 font-medium">Toplam {farmerReceivableData.receivables.length} üreticiden alacak bulunmaktadır.</p>
                            </div>
                        </div>

                        <div className="bg-stone-900 rounded-2xl border border-white/5 overflow-hidden">
                            <div className="p-4 border-b border-white/5 bg-stone-950/30">
                                <h3 className="text-xs font-black text-stone-300 uppercase tracking-widest">Bitki Bazlı Alacak Dağılımı</h3>
                            </div>
                            <div className="p-6">
                                {plantReceivableData.length === 0 ? (
                                    <div className="h-64 flex items-center justify-center text-center">
                                        <p className="text-stone-500 text-xs font-medium px-10">Bitki bazlı alacak verisi bulunamadı. Vadeli satışları kontrol edin.</p>
                                    </div>
                                ) : (
                                    <>
                                        <div className="h-64 w-full">
                                            <ResponsiveContainer width="100%" height="100%">
                                                <PieChart>
                                                    <Pie
                                                        data={plantReceivableData}
                                                        cx="50%"
                                                        cy="50%"
                                                        innerRadius={60}
                                                        outerRadius={80}
                                                        paddingAngle={5}
                                                        dataKey="value"
                                                        nameKey="name"
                                                    >
                                                        {plantReceivableData.map((entry, index) => (
                                                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                                        ))}
                                                    </Pie>
                                                    <Tooltip 
                                                        contentStyle={{ backgroundColor: '#1c1917', border: 'none', borderRadius: '12px', fontSize: '10px' }}
                                                        formatter={(value: number) => formatCurrency(value, userProfile?.currency || 'TRY')}
                                                    />
                                                </PieChart>
                                            </ResponsiveContainer>
                                        </div>
                                        <div className="grid grid-cols-2 gap-2 mt-4">
                                            {plantReceivableData.slice(0, 8).map((item, idx) => (
                                                <div key={idx} className="flex items-center justify-between p-3 bg-stone-950/50 rounded-xl border border-white/5">
                                                    <div className="flex items-center gap-2 min-w-0">
                                                        <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></div>
                                                        <span className="text-[10px] font-bold text-stone-300 truncate">{item.name}</span>
                                                    </div>
                                                    <span className="text-[10px] font-black text-emerald-500 font-mono ml-2">
                                                        {formatCurrency(item.value, userProfile?.currency || 'TRY')}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>

                        <div className="bg-stone-900 rounded-2xl border border-white/5 overflow-hidden">
                            <div className="p-4 border-b border-white/5 bg-stone-950/30">
                                <h3 className="text-xs font-black text-stone-300 uppercase tracking-widest">Üretici Bazlı Alacak Dağılımı</h3>
                            </div>
                            <div className="divide-y divide-white/5">
                                {farmerReceivableData.receivables.length === 0 ? (
                                    <div className="p-10 text-center">
                                        <p className="text-stone-500 text-xs font-medium">Şu an kayıtlı bir alacak bulunmamaktadır.</p>
                                    </div>
                                ) : (
                                    farmerReceivableData.receivables.map((f: any, i: number) => (
                                        <div key={i} className="p-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-lg bg-stone-800 flex items-center justify-center text-emerald-500 font-bold text-xs">
                                                    {i + 1}
                                                </div>
                                                <span className="text-xs font-bold text-stone-200">{f.name}</span>
                                            </div>
                                            <span className="text-sm font-black text-emerald-400 font-mono">
                                                {formatCurrency(Math.round(f.amount), userProfile?.currency || 'TRY')}
                                            </span>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                );
            case 'INVENTORY':
                return (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="bg-stone-900 p-5 rounded-2xl border border-white/5 shadow-sm relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl group-hover:bg-blue-500/20 transition-all"></div>
                                <h3 className="text-stone-400 text-[10px] font-bold uppercase tracking-widest mb-2">Toplam Stok Maliyeti</h3>
                                <div className="space-y-2">
                                    <div className="flex justify-between items-end">
                                        <span className="text-[10px] text-stone-500 uppercase tracking-widest">Vadeli</span>
                                        <span className="text-xl font-black text-stone-200 font-mono">
                                            {formatCurrency(stats.inventoryValue, userProfile?.currency || 'TRY')}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-end">
                                        <span className="text-[10px] text-stone-500 uppercase tracking-widest">Peşin</span>
                                        <span className="text-lg font-black text-stone-400 font-mono">
                                            {formatCurrency(stats.cashInventoryValue, userProfile?.currency || 'TRY')}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="bg-stone-900 p-5 rounded-2xl border border-white/5 shadow-sm relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/20 transition-all"></div>
                                <h3 className="text-stone-400 text-[10px] font-bold uppercase tracking-widest mb-2">Potansiyel Ciro</h3>
                                <div className="space-y-2">
                                    <div className="flex justify-between items-end">
                                        <span className="text-[10px] text-stone-500 uppercase tracking-widest">Vadeli</span>
                                        <span className="text-xl font-black text-emerald-400 font-mono">
                                            {formatCurrency(stats.potentialRevenue, userProfile?.currency || 'TRY')}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-end">
                                        <span className="text-[10px] text-stone-500 uppercase tracking-widest">Peşin</span>
                                        <span className="text-lg font-black text-emerald-500/70 font-mono">
                                            {formatCurrency(stats.cashPotentialRevenue, userProfile?.currency || 'TRY')}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-stone-900 p-6 rounded-2xl border border-white/5 shadow-sm">
                            <h3 className="text-stone-100 font-bold mb-6 flex items-center text-sm uppercase tracking-wider">
                                <BarChart3 size={16} className="mr-2 text-blue-500"/> Vadeli vs Peşin Karşılaştırması
                            </h3>
                            <div className="h-[300px] w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart
                                        data={[
                                            {
                                                name: 'Stok Maliyeti',
                                                'Vadeli': stats.inventoryValue,
                                                'Peşin': stats.cashInventoryValue
                                            },
                                            {
                                                name: 'Potansiyel Ciro',
                                                'Vadeli': stats.potentialRevenue,
                                                'Peşin': stats.cashPotentialRevenue
                                            }
                                        ]}
                                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                                    >
                                        <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                                        <XAxis 
                                            dataKey="name" 
                                            stroke="#57534e" 
                                            fontSize={10} 
                                            tickLine={false} 
                                            axisLine={false}
                                        />
                                        <YAxis 
                                            stroke="#57534e" 
                                            fontSize={10} 
                                            tickLine={false} 
                                            axisLine={false}
                                            tickFormatter={(value) => `${value / 1000}k`}
                                        />
                                        <Tooltip 
                                            contentStyle={{ backgroundColor: '#1c1917', border: 'none', borderRadius: '12px', fontSize: '12px' }}
                                            itemStyle={{ fontWeight: 'bold' }}
                                            formatter={(value: number) => formatCurrency(value, userProfile?.currency || 'TRY')}
                                        />
                                        <Bar dataKey="Vadeli" fill="#a8a29e" radius={[4, 4, 0, 0]} barSize={40} />
                                        <Bar dataKey="Peşin" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={40} />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="p-3 space-y-4 pb-32 animate-in fade-in duration-500 max-w-5xl mx-auto">
            <header className="flex items-center justify-between px-1">
                <div>
                    <h2 className="text-lg font-black text-stone-100 tracking-tight flex items-center gap-2">
                        <TrendingUp className="text-emerald-500" size={20} />
                        İSTATİSTİKLER
                    </h2>
                    <p className="text-stone-500 text-[9px] font-bold uppercase tracking-widest">Veri Analizi & Raporlama</p>
                </div>
                <button 
                    onClick={handleDownloadPDF}
                    disabled={isGeneratingPdf}
                    className="p-2.5 bg-emerald-600 text-white rounded-2xl shadow-lg shadow-emerald-900/20 active:scale-95 transition-all disabled:opacity-50"
                >
                    {isGeneratingPdf ? <Loader2 size={18} className="animate-spin" /> : <Download size={18} />}
                </button>
            </header>

            {/* Tab Navigation */}
            <div className="flex gap-1 p-1 bg-stone-900/50 rounded-2xl border border-white/5 overflow-x-auto no-scrollbar">
                <TabButton 
                    active={activeTab === 'OVERVIEW'} 
                    onClick={() => setActiveTab('OVERVIEW')} 
                    icon={PieIcon} 
                    label="Genel" 
                />
                <TabButton 
                    active={activeTab === 'PROFIT_LOSS'} 
                    onClick={() => setActiveTab('PROFIT_LOSS')} 
                    icon={TrendingUp} 
                    label="Kar / Zarar" 
                />
                <TabButton 
                    active={activeTab === 'CONSUMPTION'} 
                    onClick={() => setActiveTab('CONSUMPTION')} 
                    icon={Zap} 
                    label="Sarfiyat" 
                />
                <TabButton 
                    active={activeTab === 'SALES'} 
                    onClick={() => setActiveTab('SALES')} 
                    icon={TrendingUp} 
                    label="Satışlar" 
                />
                <TabButton 
                    active={activeTab === 'INVENTORY'} 
                    onClick={() => setActiveTab('INVENTORY')} 
                    icon={Package} 
                    label="Stok" 
                />
                <TabButton 
                    active={activeTab === 'DEBTS'} 
                    onClick={() => setActiveTab('DEBTS')} 
                    icon={Truck} 
                    label="Borçlar" 
                />
                <TabButton 
                    active={activeTab === 'RECEIVABLES'} 
                    onClick={() => setActiveTab('RECEIVABLES')} 
                    icon={DollarSign} 
                    label="Alacaklar" 
                />
            </div>

            {renderTabContent()}

            {/* Hidden Report View for PDF Generation */}
            <div className="fixed left-[-9999px] top-0 w-[210mm] bg-stone-950 p-10 text-stone-200 font-sans" ref={reportRef} style={{ visibility: 'hidden', pointerEvents: 'none' }}>
                <div className="border-b border-white/10 pb-6 mb-8 flex justify-between items-end">
                    <div>
                        <h1 className="text-3xl font-black text-emerald-500 mb-2 tracking-tighter">MKS DETAYLI ANALİZ RAPORU</h1>
                        <p className="text-stone-500 text-xs font-bold uppercase tracking-[0.3em]">Dijital Tarım Yönetim Sistemi</p>
                    </div>
                    <div className="text-right">
                        <p className="text-stone-400 text-[10px] font-bold uppercase">Rapor Tarihi</p>
                        <p className="text-stone-100 font-mono text-sm">{new Date().toLocaleDateString('tr-TR')}</p>
                    </div>
                </div>

                <div className="grid grid-cols-3 gap-6 mb-10">
                    <ReportStatBox label={`Toplam ${farmerLabel}`} value={stats.totalFarmers} />
                    <ReportStatBox label="Toplam Arazi" value={`${stats.totalArea} da`} />
                    <ReportStatBox label="Aktif Görevler" value={stats.activeReminders} />
                </div>

                <div className="space-y-10">
                    <section>
                        <h3 className="text-emerald-500 font-black text-xs uppercase tracking-widest mb-4 border-l-2 border-emerald-500 pl-3">Ürün Dağılım Analizi</h3>
                        <table className="w-full text-left text-xs">
                            <thead>
                                <tr className="text-stone-500 border-b border-white/5">
                                    <th className="py-3 font-bold uppercase tracking-wider">Ürün Adı</th>
                                    <th className="py-3 font-bold uppercase tracking-wider text-right">Alan (da)</th>
                                    <th className="py-3 font-bold uppercase tracking-wider text-right">Yüzde</th>
                                </tr>
                            </thead>
                            <tbody>
                                {stats.cropDistribution.map((item, i) => (
                                    <tr key={i} className="border-b border-white/5 text-stone-300">
                                        <td className="py-3 font-bold">{item.crop}</td>
                                        <td className="py-3 text-right font-mono">{item.area}</td>
                                        <td className="py-3 text-right font-mono">%{((item.area / stats.totalArea) * 100).toFixed(1)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </section>

                    <section>
                        <h3 className="text-emerald-500 font-black text-xs uppercase tracking-widest mb-4 border-l-2 border-emerald-500 pl-3">Bölgesel Dağılım</h3>
                        <div className="grid grid-cols-2 gap-4">
                            {villageData.map((v, i) => (
                                <div key={i} className="flex justify-between p-3 bg-white/5 rounded-xl border border-white/5">
                                    <span className="text-stone-300 font-bold">{v.name}</span>
                                    <span className="text-emerald-400 font-mono">{v.value} Üretici</span>
                                </div>
                            ))}
                        </div>
                    </section>

                    <section>
                        <h3 className="text-emerald-500 font-black text-xs uppercase tracking-widest mb-4 border-l-2 border-emerald-500 pl-3">İlaç Sarfiyat Analizi (Adet)</h3>
                        <table className="w-full text-left text-xs">
                            <thead>
                                <tr className="text-stone-500 border-b border-white/5">
                                    <th className="py-3 font-bold uppercase tracking-wider">İlaç Adı</th>
                                    <th className="py-3 font-bold uppercase tracking-wider text-right">Adet</th>
                                </tr>
                            </thead>
                            <tbody>
                                {consumptionData.map((item, i) => (
                                    <tr key={i} className="border-b border-white/5 text-stone-300">
                                        <td className="py-3 font-bold">{item.name}</td>
                                        <td className="py-3 text-right font-mono">{item.value}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </section>

                    <section>
                        <h3 className="text-emerald-500 font-black text-xs uppercase tracking-widest mb-4 border-l-2 border-emerald-500 pl-3">Envanter Durumu</h3>
                        <table className="w-full text-left text-[10px]">
                            <thead>
                                <tr className="text-stone-500 border-b border-white/5">
                                    <th className="py-2 font-bold uppercase tracking-wider">Ürün</th>
                                    <th className="py-2 font-bold uppercase tracking-wider text-right">Mevcut Stok</th>
                                    <th className="py-2 font-bold uppercase tracking-wider text-right">Birim</th>
                                </tr>
                            </thead>
                            <tbody>
                                {inventory.map((item, i) => (
                                    <tr key={i} className="border-b border-white/5 text-stone-300">
                                        <td className="py-2">{item.pesticideName}</td>
                                        <td className={`py-2 text-right font-mono ${item.quantity < 5 ? 'text-rose-400' : 'text-emerald-400'}`}>{item.quantity}</td>
                                        <td className="py-2 text-right">{item.unit}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </section>

                    <section>
                        <h3 className="text-emerald-500 font-black text-xs uppercase tracking-widest mb-4 border-l-2 border-emerald-500 pl-3">Satış ve Finansal Analiz</h3>
                        <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                                <p className="text-stone-500 text-[10px] font-bold uppercase mb-1">Toplam Gelir</p>
                                <p className="text-emerald-400 font-mono text-lg font-black">{formatCurrency(salesData.totalRevenue, userProfile?.currency || 'TRY')}</p>
                            </div>
                            <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                                <p className="text-stone-500 text-[10px] font-bold uppercase mb-1">Toplam Maliyet</p>
                                <p className="text-red-400 font-mono text-lg font-black">{formatCurrency(salesData.totalCost, userProfile?.currency || 'TRY')}</p>
                            </div>
                            <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                                <p className="text-stone-500 text-[10px] font-bold uppercase mb-1">Net Kar/Zarar</p>
                                <p className={`font-mono text-lg font-black ${salesData.totalProfit >= 0 ? 'text-blue-400' : 'text-rose-400'}`}>
                                    {formatCurrency(salesData.totalProfit, userProfile?.currency || 'TRY')}
                                </p>
                            </div>
                            <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                                <p className="text-stone-500 text-[10px] font-bold uppercase mb-1">Kar Marjı</p>
                                <p className="text-stone-100 font-mono text-lg font-black">%{salesData.margin.toFixed(1)}</p>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h3 className="text-emerald-500 font-black text-xs uppercase tracking-widest mb-4 border-l-2 border-emerald-500 pl-3">Borç ve Alacak Durumu</h3>
                        <div className="grid grid-cols-2 gap-6">
                            <div>
                                <h4 className="text-rose-400 font-bold text-[10px] uppercase tracking-wider mb-3">Tedarikçi Borçları</h4>
                                <table className="w-full text-left text-[10px]">
                                    <tbody>
                                        {supplierDebtData.totalSupplierDebt === 0 ? (
                                            <tr><td className="py-2 text-stone-500 italic">Kayıtlı borç yok</td></tr>
                                        ) : (
                                            supplierDebtData.debts.map((s, i) => (
                                                <tr key={i} className="border-b border-white/5 text-stone-300">
                                                    <td className="py-2">{s.name}</td>
                                                    <td className="py-2 text-right font-mono text-rose-400">{formatCurrency(s.debt, userProfile?.currency || 'TRY')}</td>
                                                </tr>
                                            ))
                                        )}
                                        <tr className="font-black text-rose-500">
                                            <td className="py-3 uppercase">Toplam</td>
                                            <td className="py-3 text-right font-mono">{formatCurrency(supplierDebtData.totalSupplierDebt, userProfile?.currency || 'TRY')}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div>
                                <h4 className="text-emerald-400 font-bold text-[10px] uppercase tracking-wider mb-3">Üretici Alacakları</h4>
                                <table className="w-full text-left text-[10px]">
                                    <tbody>
                                        {farmerReceivableData.totalFarmerReceivables === 0 ? (
                                            <tr><td className="py-2 text-stone-500 italic">Kayıtlı alacak yok</td></tr>
                                        ) : (
                                            farmerReceivableData.receivables.map((f, i) => (
                                                <tr key={i} className="border-b border-white/5 text-stone-300">
                                                    <td className="py-2">{f.name}</td>
                                                    <td className="py-2 text-right font-mono text-emerald-400">{formatCurrency(f.amount, userProfile?.currency || 'TRY')}</td>
                                                </tr>
                                            ))
                                        )}
                                        <tr className="font-black text-emerald-500">
                                            <td className="py-3 uppercase">Toplam</td>
                                            <td className="py-3 text-right font-mono">{formatCurrency(farmerReceivableData.totalFarmerReceivables, userProfile?.currency || 'TRY')}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h3 className="text-emerald-500 font-black text-xs uppercase tracking-widest mb-4 border-l-2 border-emerald-500 pl-3">Son Reçeteler ve Notlar</h3>
                        <div className="space-y-4">
                            {visitLogsWithNames.slice(0, 10).map((v, i) => (
                                <div key={i} className="p-3 bg-white/5 rounded-xl border border-white/5">
                                    <div className="flex justify-between mb-1">
                                        <span className="text-emerald-400 font-bold text-[10px]">{v.farmerName}</span>
                                        <span className="text-stone-500 text-[9px]">{new Date(v.date).toLocaleDateString('tr-TR')}</span>
                                    </div>
                                    <p className="text-stone-300 text-[10px] line-clamp-2">
                                        {v.pestFound || v.diseaseFound ? `${v.pestFound || ''} ${v.diseaseFound || ''}` : v.note}
                                    </p>
                                    {v.severity && (
                                        <div className="mt-1">
                                            <span className={`text-[8px] px-1 rounded ${
                                                v.severity === 'HIGH' ? 'bg-red-500/20 text-red-400' :
                                                v.severity === 'MEDIUM' ? 'bg-amber-500/20 text-amber-400' :
                                                'bg-emerald-500/20 text-emerald-400'
                                            }`}>
                                                Şiddet: {v.severity}
                                            </span>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </section>
                </div>

                <div className="mt-20 pt-10 border-t border-white/5 text-center">
                    <p className="text-[10px] text-stone-600 font-black uppercase tracking-[0.5em]">MKS DIGITAL AGRICULTURE • GÜVENLİ VERİ ANALİZİ</p>
                </div>
            </div>
        </div>
    );
};

const TabButton = ({ active, onClick, icon: Icon, label }: any) => (
    <button 
        onClick={onClick}
        className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl transition-all duration-300 ${
            active 
            ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20' 
            : 'text-stone-500 hover:text-stone-300'
        }`}
    >
        <Icon size={14} />
        <span className="text-[10px] font-black uppercase tracking-wider">{label}</span>
    </button>
);

const QuickStatCard = ({ title, value, icon: Icon, color, trend }: any) => {
    const colorClasses: any = {
        blue: 'text-blue-500 bg-blue-500/10 border-blue-500/20',
        emerald: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20',
        amber: 'text-amber-500 bg-amber-500/10 border-amber-500/20',
        red: 'text-red-500 bg-red-500/10 border-red-500/20',
    };

    return (
        <div className={`p-4 rounded-[1.8rem] border flex flex-col justify-between min-h-[100px] relative overflow-hidden group ${colorClasses[color]}`}>
            <div className="absolute -right-2 -top-2 opacity-5 group-hover:opacity-10 transition-opacity">
                <Icon size={64} />
            </div>
            <div className="flex justify-between items-start relative z-10">
                <div className="p-1.5 bg-white/10 rounded-lg">
                    <Icon size={14} />
                </div>
                {trend && <span className="text-[8px] font-black px-1.5 py-0.5 bg-white/10 rounded-full">{trend}</span>}
            </div>
            <div className="relative z-10">
                <p className="text-lg font-black text-stone-100 leading-none mb-1">{value}</p>
                <p className="text-[8px] font-bold uppercase tracking-widest text-stone-500">{title}</p>
            </div>
        </div>
    );
};

const ReportStatBox = ({ label, value }: any) => (
    <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
        <p className="text-stone-500 text-[10px] font-black uppercase tracking-widest mb-2">{label}</p>
        <p className="text-2xl font-black text-stone-100">{value}</p>
    </div>
);
